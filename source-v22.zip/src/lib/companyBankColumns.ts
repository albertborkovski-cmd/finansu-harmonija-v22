import type { ColConfig } from '../components/ColumnSettingsPanel';

export const BANK_DEFAULT_COLUMNS: ColConfig[] = [
  { key: 'date', label: 'Date', width: 130, visible: true },
  { key: 'bankAccount', label: 'Bank account', width: 220, visible: true },
  { key: 'counterpartyName', label: 'Counterparty name', width: 220, visible: true },
  { key: 'paymentPurpose', label: 'Purpose of payment', width: 240, visible: true },
  { key: 'amount', label: 'Amount', width: 140, visible: true },
  { key: 'currency', label: 'Currency', width: 110, visible: true },
  { key: 'status', label: 'Status', width: 150, visible: true },
  { key: 'reconciliationStatus', label: 'Reconciliation status', width: 180, visible: true },
  { key: 'accountCode', label: 'Account code', width: 140, visible: false },
  { key: 'transferNo', label: 'Transfer no.', width: 150, visible: false },
  { key: 'counterpartyCode', label: 'Counterparty code', width: 170, visible: false },
  { key: 'counterpartyIban', label: 'Counterparty IBAN', width: 230, visible: false },
  { key: 'postingType', label: 'Posting type', width: 150, visible: false },
  { key: 'bookingDate', label: 'Booking date', width: 150, visible: false },
  { key: 'exchangeRateDate', label: 'Exchange rate date', width: 180, visible: false },
  { key: 'referenceNo', label: 'Reference No.', width: 160, visible: false },
  { key: 'costCenter', label: 'Cost center', width: 150, visible: false },
  { key: 'notes', label: 'Notes', width: 220, visible: false },
  { key: 'glAccounts', label: 'GL accounts', width: 150, visible: false },
  { key: 'settledDocuments', label: 'Settled documents', width: 220, visible: false },
  { key: 'id', label: 'ID', width: 180, visible: false },
  { key: 'attachmentsCount', label: 'Attachments count', width: 170, visible: false },
];

const LEGACY_DEFAULT_KEYS = ['bankAccount', 'accountCode', 'transferNo', 'date', 'counterpartyName', 'counterpartyCode', 'postingType', 'amount', 'currency', 'exchangeRateDate', 'paymentPurpose', 'referenceNo', 'costCenter', 'notes', 'glAccounts', 'settledDocuments', 'confirmed', 'id', 'attachmentsCount'];
const validWidth = (width: unknown): width is number => typeof width === 'number' && Number.isFinite(width) && width > 0;
const resolveWidth = (column: ColConfig, width: unknown) =>
  column.key === 'bankAccount' && width === 190 ? column.width : validWidth(width) ? width : column.width;

/** Upgrade the automatically persisted old default, without resetting a user's custom layout. */
export function resolveBankColumns(saved: unknown): ColConfig[] {
  if (!Array.isArray(saved) || !saved.length) return BANK_DEFAULT_COLUMNS.map(column => ({ ...column }));
  const oldDefault = saved.length === LEGACY_DEFAULT_KEYS.length && saved.every((column, index) => column?.key === LEGACY_DEFAULT_KEYS[index] && column.visible === true);
  if (oldDefault) {
    return BANK_DEFAULT_COLUMNS.map(column => {
      const previous = saved.find(item => item.key === column.key);
      return { ...column, width: resolveWidth(column, previous?.width) };
    });
  }
  const seen = new Set<string>();
  const columns: ColConfig[] = [];
  for (const item of saved) {
    const definition = BANK_DEFAULT_COLUMNS.find(column => column.key === item?.key);
    if (!definition || seen.has(definition.key)) continue;
    seen.add(definition.key);
    columns.push({ ...definition, visible: typeof item.visible === 'boolean' ? item.visible : definition.visible, width: resolveWidth(definition, item.width) });
  }
  if (!columns.length) return BANK_DEFAULT_COLUMNS.map(column => ({ ...column }));
  return [...columns, ...BANK_DEFAULT_COLUMNS.filter(column => !seen.has(column.key)).map(column => ({ ...column, visible: false }))];
}
