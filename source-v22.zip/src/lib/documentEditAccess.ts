import { canEditMenu, canViewMenu, isSystemAdministratorRole, parseSession, systemAdministratorIdentityEmail } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization, loadLinkedDirectoryUsers, loadOrganizationUserIds, organizationAssignmentStorageKey, type SettingsAudience } from './linkedSettingsData';
import { isInactiveRecord } from './recordLifecycle';

function canAccessCompanyDocuments(company: { id: string; name: string; assigned_accountant?: string } | undefined, edit: boolean) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    if (!company || !session || !canViewMenu(session, 'documents') || (edit && !canEditMenu(session, 'documents')) || !canAccessAssignedOrganization(company, session)) return false;
    const administrator = session.roleNames.some(isSystemAdministratorRole);
    const email = session.email.trim().toLowerCase();
    const administratorIdentity = administrator ? systemAdministratorIdentityEmail(email) : null;
    const memberships = (['Internal users', 'External users'] as SettingsAudience[]).flatMap(audience =>
      loadLinkedDirectoryUsers(audience).filter(candidate => {
        const candidateEmail = candidate.email?.trim().toLowerCase() ?? '';
        return candidateEmail === email || (audience === 'Internal users' && administratorIdentity !== null
          && systemAdministratorIdentityEmail(candidateEmail) === administratorIdentity);
      }).map(user => ({ audience, user })),
    );
    // A legacy sign-in alias is not a second account. The actual directory
    // record must exist and remain active; do not bypass a block/deactivation.
    if (!memberships.length || memberships.some(({ user }) => isInactiveRecord(user)
      || (user.status && !['enabled', 'active'].includes(user.status.trim().toLowerCase())))) return false;
    if (administrator) return true;
    for (const { audience, user } of memberships) {
      if (session.roleNames.some(role => role.toLowerCase() === 'meso accountant')) return true;
      if (window.localStorage.getItem(organizationAssignmentStorageKey(company.id, audience)) !== null)
        return loadOrganizationUserIds(company.id, audience).includes(user.id);
      const organizations = (user.organizations ?? '').split(',').map(value => value.trim().toLowerCase());
      return organizations.some(value => ['all organizations', company.id.toLowerCase(), company.name.toLowerCase()].includes(value));
    }
    return false;
  } catch { return false; }
}

export const canEditCompanyDocuments = (company: { id: string; name: string; assigned_accountant?: string } | undefined) => canAccessCompanyDocuments(company, true);
export const canViewCompanyDocuments = (company: { id: string; name: string; assigned_accountant?: string } | undefined) => canAccessCompanyDocuments(company, false);
