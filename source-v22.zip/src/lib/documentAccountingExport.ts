import { documentDeliveryDestinations, selectedDocumentRecords } from './documentExport';

type SourceDocument = { id: string; company_id?: string; [key: string]: unknown };
type ExportCompany = { id: string; name: string; counterparties_settings?: string };

/** UI-test profiles only. These files deliberately do not impersonate a vendor's
 * production import schema: real mappings require an agreed import sample. */
export function documentAccountingExportProfile(destinationId: string) {
  return destinationId === 'rivile' || destinationId === 'agnum'
    ? { extension: 'xml', label: 'XML' } as const
    : { extension: 'json', label: 'JSON' } as const;
}

const documentFields = [
  'id', 'number', 'series', 'document_type', 'document_subtype', 'type', 'status',
  'document_date', 'operation_date', 'due_end_date', 'invoice_contract_date',
  'client_counterparty', 'counterparty_code', 'order_no', 'document_purpose', 'notes',
  'currency', 'amount_without_vat', 'vat', 'vat_percent', 'total_amount',
  'expense_account', 'vat_classifier', 'department_code', 'object_project',
  'cost_center', 'accountable_responsible',
] as const;
const lineFields = [
  'id', 'code', 'barcode', 'product', 'description', 'productGroup', 'unit', 'qty',
  'price', 'subtotal', 'discount', 'vat', 'vatPct', 'total', 'expense', 'vatClass',
  'department', 'object', 'center', 'series',
] as const;
function pickFields(source: Record<string, unknown>, fields: readonly string[]) {
  return Object.fromEntries(fields.map(key => {
    const value = source[key];
    return [key, typeof value === 'string' || typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value)) ? value : ''];
  }));
}
function exportLines(value: unknown) {
  return Array.isArray(value) ? value.filter(line => line && typeof line === 'object' && !Array.isArray(line)).map(line => pickFields(line, lineFields)) : [];
}
function xmlText(value: unknown) {
  return String(value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;');
}
function xmlFields(fields: Record<string, unknown>, indent: string) {
  return Object.entries(fields).map(([key, value]) => `${indent}<${key}>${xmlText(value)}</${key}>`).join('\n');
}
function safeFilename(value: string) {
  return value.replace(/[^\p{L}\p{N} _-]/gu, '').trim().replace(/\s+/g, '-') || 'Documents';
}

export function buildDocumentAccountingExport(rows: SourceDocument[], ids: string[], company: ExportCompany, destinationId: string, at = new Date().toISOString()) {
  const documents = selectedDocumentRecords(rows, ids, company.id);
  const destination = documentDeliveryDestinations(company.counterparties_settings).find(item => item.value === destinationId);
  if (!destination) throw new Error('The selected accounting system is no longer available for this company. Select it again.');
  const profile = documentAccountingExportProfile(destinationId);
  const payload = {
    schema: 'finansu-harmonija.accounting-export-preview.v1',
    mode: 'test', importReady: false,
    notice: 'Test export only. Production import mapping has not been configured.',
    destination: { id: destination.value, name: destination.label },
    company: { id: company.id, name: company.name },
    generatedAt: at,
    documents: documents.map(document => ({
      ...pickFields(document, documentFields),
      accountingAllocations: exportLines(document.summary_line_items),
      documentLines: exportLines(document.line_items),
    })),
  };
  const filename = `${safeFilename(company.name)}-${safeFilename(destination.label)}-TEST-documents-${at.slice(0, 10)}.${profile.extension}`;
  if (profile.extension === 'json') return { filename, mime: 'application/json;charset=utf-8', content: JSON.stringify(payload, null, 2) };
  const content = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<AccountingExportPreview schemaVersion="1" mode="test" importReady="false">',
    `  <Notice>${xmlText(payload.notice)}</Notice>`,
    `  <Destination id="${xmlText(destination.value)}">${xmlText(destination.label)}</Destination>`,
    `  <Company id="${xmlText(company.id)}">${xmlText(company.name)}</Company>`,
    `  <GeneratedAt>${xmlText(at)}</GeneratedAt>`,
    `  <Documents count="${payload.documents.length}">`,
    ...payload.documents.map(({ accountingAllocations, documentLines, ...header }) => [
      '    <Document>', xmlFields(header, '      '),
      `      <AccountingAllocations count="${accountingAllocations.length}">`,
      ...accountingAllocations.map(line => `        <Line>\n${xmlFields(line, '          ')}\n        </Line>`),
      '      </AccountingAllocations>',
      `      <DocumentLines count="${documentLines.length}">`,
      ...documentLines.map(line => `        <Line>\n${xmlFields(line, '          ')}\n        </Line>`),
      '      </DocumentLines>', '    </Document>',
    ].join('\n')),
    '  </Documents>', '</AccountingExportPreview>',
  ].join('\n');
  return { filename, mime: 'application/xml;charset=utf-8', content };
}
