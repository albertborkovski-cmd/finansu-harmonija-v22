import type { ColConfig } from '../components/ColumnSettingsPanel';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentWorkLog } from '../components/ocrDocumentWorkTimeStore';
import type { Company, DbDocument } from './supabase';

export type ReviewDirectoryUser = { id?: string; fullName?: string; username?: string; email?: string; status?: string };
export type WorkerAnalytics = {
  id: string; name: string; email: string;
  documents: { document: DbDocument; organization: string; seconds: number }[];
  needReview: number; approved: number; totalSeconds: number;
  teamLeadReferrals: number; assignedIssues: number;
};
export const REVIEW_ANALYTICS_COLUMNS: ColConfig[] = [
  { key: 'employee', label: 'Employee', width: 240, visible: true },
  { key: 'documents', label: 'Documents', width: 140, visible: true },
  { key: 'needReview', label: 'Need review', width: 140, visible: true },
  { key: 'approved', label: 'Approved', width: 140, visible: true },
  { key: 'teamLeadReferrals', label: 'Sent to TeamLead', width: 190, visible: true },
  { key: 'assignedIssues', label: 'Assigned document issues', width: 220, visible: true },
  { key: 'workTime', label: 'Work time', width: 150, visible: true },
];

export function reviewAnalyticsColumns(saved: readonly ColConfig[]): ColConfig[] {
  return REVIEW_ANALYTICS_COLUMNS.map(column => ({ ...column, ...saved.find(item => item.key === column.key), label: column.label }));
}

const normalize = (value?: string) => value?.trim().toLowerCase() || '';
const nameOf = (user: ReviewDirectoryUser) => user.fullName?.trim() || user.username?.trim() || user.email?.trim() || 'Unnamed user';
const needsReview = new Set(['need review', 'needs review', 'pending', 'draft', 'rejected', 'provide additional data', 'exception', 'duplicate', 'not document']);
const approved = new Set(['accepted', 'approved', 'completed', 'processed', 'transferred']);

/** Count recorded hand-offs, not current queue size. Never merge two workers by a duplicated name. */
export function buildReviewAnalytics(documents: readonly DbDocument[], companies: readonly Company[], users: readonly ReviewDirectoryUser[],
  workLog: OcrDocumentWorkLog, tasks: ReadonlyMap<string, WorkspaceTask | undefined>): WorkerAnalytics[] {
  const companyNames = new Map(companies.map(company => [company.id, company.name]));
  const byEmail = new Map(users.filter(user => user.email).map(user => [normalize(user.email), user]));
  const names = new Map<string, ReviewDirectoryUser[]>();
  for (const user of users) for (const identity of new Set([nameOf(user), user.username, user.id].filter(Boolean))) {
    const key = normalize(identity);
    names.set(key, [...(names.get(key) || []), user]);
  }
  const rows = new Map<string, WorkerAnalytics>();
  const rowFor = (email = '', name = '', known?: ReviewDirectoryUser) => {
    const matches = names.get(normalize(name)) || [];
    const user = known || byEmail.get(normalize(email)) || (!email && matches.length === 1 ? matches[0] : undefined);
    const resolvedEmail = normalize(user?.email || email);
    const key = user?.id ? `user:${user.id}` : resolvedEmail ? `email:${resolvedEmail}` : `legacy:${normalize(name) || 'unassigned'}`;
    let row = rows.get(key);
    if (!row) {
      row = { id: key, name: user ? nameOf(user) : name || email || 'Unassigned', email: resolvedEmail,
        documents: [], needReview: 0, approved: 0, totalSeconds: 0, teamLeadReferrals: 0, assignedIssues: 0 };
      rows.set(key, row);
    }
    return row;
  };
  users.forEach(user => rowFor(user.email, nameOf(user), user));
  const includeDocument = (row: WorkerAnalytics, document: DbDocument, seconds = 0) => {
    if (row.documents.some(item => item.document.id === document.id)) return;
    row.documents.push({ document, organization: companyNames.get(document.company_id || '') || '—', seconds });
    if (needsReview.has(normalize(document.status))) row.needReview++;
    if (approved.has(normalize(document.status))) row.approved++;
    row.totalSeconds += seconds;
  };
  for (const document of documents) {
    const task = tasks.get(document.id);
    const work = workLog[document.id] || workLog[`document-set-${document.id}`];
    const owner = rowFor(task?.assignedToEmail || work?.email,
      task?.assignedToName || work?.user || document.accountable_responsible || document.created_by || 'Unassigned');
    includeDocument(owner, document, work?.seconds || 0);
    const referrals = new Set<string>();
    for (const review of [...(task?.teamLeadReviewHistory || []), ...(task?.teamLeadReview ? [task.teamLeadReview] : [])]) {
      if (!review.requestedAt || (!review.requestedByEmail && !review.requestedBy)) continue;
      const worker = rowFor(review.requestedByEmail, review.requestedBy);
      const key = `${worker.id}:${review.requestedAt}`;
      if (referrals.has(key)) continue;
      referrals.add(key);
      worker.teamLeadReferrals++;
      includeDocument(worker, document);
    }
    const issueRecipients = new Set<string>();
    for (const issue of document.digitization_issues || []) {
      // A report without a worker assignment belongs to the shared queue, not its author.
      if (!issue.assignedToEmail) continue;
      const worker = rowFor(issue.assignedToEmail, issue.assignedToName);
      if (issueRecipients.has(worker.id)) continue;
      issueRecipients.add(worker.id);
      worker.assignedIssues++;
      includeDocument(worker, document);
    }
  }
  return [...rows.values()].sort((a, b) => b.needReview - a.needReview || b.documents.length - a.documents.length || a.name.localeCompare(b.name));
}
