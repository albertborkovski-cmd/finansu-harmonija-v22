import type { DbDocument } from './supabase';
import { documentIssueStatusLabel, type DocumentIssue } from './documentIssues';

export type DocumentIssueRow = {
  id: string;
  document: DbDocument;
  issue: DocumentIssue;
  cells: Record<string, string>;
};

const text = (value: unknown) => value === null || value === undefined || value === '' ? '—' : String(value);

function allocationValue(document: DbDocument, field: string, fallback: unknown) {
  const allocations = document.summary_line_items;
  if (!allocations?.length) return text(fallback);
  const values = allocations.map(line => text((line as unknown as Record<string, unknown>)[field]));
  return [...new Set(values)].join(', ');
}

export function documentIssueRows(documents: DbDocument[], organizationNames: ReadonlyMap<string, string>): DocumentIssueRow[] {
  return documents.flatMap(document => {
    const cells = {
      number: text(document.number), organization: text(organizationNames.get(document.company_id ?? '')),
      status: text(document.status), receiveDate: text(document.receive_date),
      clientCounterparty: text(document.client_counterparty), counterpartyCode: text(document.counterparty_code),
      documentType: text(document.document_type), invoice: /invoice/i.test(document.document_type) ? 'Yes' : 'No',
      documentSubtype: text(document.document_subtype), source: text(document.source),
      totalAmount: text(document.total_amount), amountWithoutVat: text(document.amount_without_vat),
      vat: text(document.vat), vatPercent: text(document.vat_percent), currency: text(document.currency),
      dueEndDate: text(document.due_end_date), fileCase: text(document.file_case), orderNo: text(document.order_no),
      type: text(document.type), documentDate: text(document.document_date), documentPurpose: text(document.document_purpose),
      invoiceContractDate: text(document.invoice_contract_date), operationDate: text(document.operation_date),
      glAccount: allocationValue(document, 'expense', document.expense_account),
      vatClassifier: allocationValue(document, 'vatClass', document.vat_classifier),
      productGroup: text([...new Set([...(document.summary_line_items ?? []), ...(document.line_items ?? [])]
        .map(line => line.productGroup?.trim()).filter(Boolean))].join(', ')),
      series: text(document.series), costCenter: allocationValue(document, 'center', document.cost_center),
      objectProject: allocationValue(document, 'object', document.object_project),
      departmentCode: allocationValue(document, 'department', document.department_code),
      accountableResponsible: text(document.accountable_responsible), validFrom: text(document.valid_form),
      note: text(document.notes), createdAt: text(document.created_at), createdBy: text(document.created_by),
    };
    return (document.digitization_issues ?? []).map(issue => ({
      id: `${document.id}:${issue.id}`, document, issue,
      cells: { ...cells, reportedIssue: issue.message, issueStatus: documentIssueStatusLabel(issue.status),
        assignedTo: text(issue.assignedToName || issue.assignedToEmail),
        reportedBy: issue.createdBy, reportedAt: issue.createdAt, resolution: text(issue.resolution || issue.correctionNote) },
    }));
  }).sort((left, right) => right.issue.createdAt.localeCompare(left.issue.createdAt));
}

export function filterDocumentIssueRows(rows: DocumentIssueRow[], query: string, activeKeys: string[], values: Record<string, string[]>) {
  const search = query.trim().toLocaleLowerCase();
  return rows.filter(row => (!search || Object.values(row.cells).some(value => value.toLocaleLowerCase().includes(search)))
    && activeKeys.every(key => !values[key]?.length || values[key].includes(row.cells[key])));
}
