import type { Company, DbDocument } from './supabase';
import { DOCUMENT_PROCESSING_STATUSES, initialInvoiceStatusOptions, documentStatusOptions } from './documentProcessingStatus';
import { DEFAULT_INVOICE_LINE_TYPES, invoiceLineTypeValues } from './invoiceLineTypes';
import { documentResponsiblePatch } from './documentResponsibleUsers';
import type { LinkedDirectoryUser } from './linkedSettingsData';
import type { WarehouseStore } from './warehouse';

/** New manual invoices cannot claim payment, processing or external transfer. */
export const INVOICE_CREATION_STATUSES = DOCUMENT_PROCESSING_STATUSES.filter(status =>
  status !== 'Paid' && status !== 'Processing' && status !== 'Transferred');
export type InvoiceCreationStatus = string;
export type InvoiceAccountingDefaultKey = 'vatClassifier' | 'department' | 'costCenter' | 'includeVatInDebt';
type InvoiceVatOption = { code: string; rate: string };

export type InvoiceLineDraft = {
  id: string; type: string; catalogId: string; code: string; name: string;
  description: string; unit: string; quantity: string; price: string; discount: string;
  vatRate: string; glAccount: string; vatClassifier: string;
  barcode?: string; productGroup?: string; department?: string; project?: string; costCenter?: string; series?: string;
  lineNote?: string; analyticalSeries?: string; mainAnalyticalAccount?: string; relatedContract?: string;
  itemCode?: string; warehouseId?: string;
  /** Unset inherits the document's responsible person; an empty value clears it on this line. */
  responsibleId?: string;
  /** Stable matching allocation when a saved invoice uses one allocation per line. */
  allocationId?: string;
  discountAmount?: string; vatAmount?: string;
  /** Unset follows Accounting defaults; an explicit row choice takes precedence. */
  includeVatInDebt?: boolean;
  /** Form-only provenance: explicit row edits must survive later default changes. */
  accountingDefaultOverrides?: Partial<Record<InvoiceAccountingDefaultKey | 'vatRate', boolean>>;
};
export type InvoiceDraft = {
  status: InvoiceCreationStatus;
  purpose: 'Purchase' | 'Sale'; kind: string;
  number: string; series: string; orderNo: string; counterpartyId: string;
  currency: string; exchangeRate: string; invoiceDate: string; operationDate: string; dueDate: string; paymentTerms: string;
  glAccount: string; vatClassifier: string; department: string; costCenter: string; project: string;
  includeVatInDebt: boolean; responsibleId: string; language: string; notes: string;
  customerManagerId?: string;
  /** The original invoice selected for this credit; linking does not post or settle it. */
  creditSourceDocumentId?: string;
  analyticalSeries?: string; mainAnalyticalAccount?: string; relatedContract?: string;
  lines: InvoiceLineDraft[];
  /** Separate accounting allocations; absent means one allocation per quantity line. */
  allocations?: InvoiceLineDraft[];
};
export type InvoiceAttachment = { name: string; size: number; type: string; url: string };
export type CreateInvoiceCommand = { requestId: string; draft: InvoiceDraft; attachments: InvoiceAttachment[]; copySourceDocumentId?: string;
  creditNoteSource?: import('./invoiceCreditNote').CreditNoteSourceCommand };
export type InvoiceTypeRecord = { code: string; fullName: string; parentCode: string; status: string };
/** Active OCR invoice types suitable for invoice creation; other documents remain in the OCR catalog. */
export function invoiceTypeOptions(records: readonly InvoiceTypeRecord[]) {
  const active = (record: InvoiceTypeRecord) => record.status.trim().toLowerCase() === 'active';
  if (!records.some(record => record.code === 'INVOICES' && !record.parentCode && active(record))) return [];
  return records.filter(record => record.parentCode === 'INVOICES' && record.code && record.code !== 'OTHER_INVOICE_DOCUMENT' && active(record))
    .map(record => ({ value: record.code, label: record.fullName || record.code }));
}
export function isCreditInvoiceKind(kind: string) {
  return ['credit_invoice', 'credit_note'].includes(kind.trim().toLowerCase().replace(/[ -]+/g, '_'));
}
export type InvoiceCreditSource = Pick<DbDocument, 'id'> & Partial<DbDocument> & { inactive?: boolean; active?: boolean; is_active?: boolean };
const creditSourceText = (value: unknown) => typeof value === 'string' ? value.trim() : '';
export function invoiceCreditSources(documents: readonly InvoiceCreditSource[], companyId: string, purpose: InvoiceDraft['purpose']) {
  if (!companyId || !['Purchase', 'Sale'].includes(purpose)) return [];
  const side = (row: InvoiceCreditSource) => {
    const purpose = creditSourceText(row.document_purpose).toLowerCase();
    return ['purchase', 'sale'].includes(purpose) ? purpose : creditSourceText(row.type).toLowerCase();
  };
  const positiveAmount = (row: InvoiceCreditSource) => {
    const value = Number(creditSourceText(row.total_amount).replace(/\s/g, '').replace(',', '.'));
    return Number.isFinite(value) && value > 0;
  };
  return documents.filter(row => row.company_id === companyId && side(row) === purpose.toLowerCase()
    && row.inactive !== true && row.active !== false && row.is_active !== false && !row.accounting_storno && !row.document_storno
    && !['inactive', 'cancelled', 'canceled', 'deleted', 'void'].includes(creditSourceText(row.status).toLowerCase())
    && /^(invoices?|sales?[\s_-]*invoices?|purchase[\s_-]*invoices?|vat[\s_-]*invoice)$/i.test(creditSourceText(row.document_type))
    && !isCreditInvoiceKind(creditSourceText(row.document_subtype)) && creditSourceText(row.number)
    && positiveAmount(row))
    .sort((a, b) => creditSourceText(b.document_date).localeCompare(creditSourceText(a.document_date)) || creditSourceText(a.number).localeCompare(creditSourceText(b.number)));
}
export function invoiceCreditCounterparty(source: InvoiceCreditSource, parties: readonly Company[]) {
  const id = creditSourceText(source.counterparty_id), code = creditSourceText(source.counterparty_code);
  return (id ? parties.find(party => party.id === id) : undefined)
    || (code ? parties.find(party => creditSourceText(party.company_code) === code) : undefined)
    || (!id && !code ? parties.find(party => creditSourceText(party.name).toLowerCase() === creditSourceText(source.client_counterparty).toLowerCase()) : undefined);
}
export function updateInvoiceClassification(draft: InvoiceDraft, patch: Partial<Pick<InvoiceDraft, 'purpose' | 'kind'>>) {
  const next = { ...draft, ...patch };
  return { ...next, creditSourceDocumentId: next.purpose !== draft.purpose || !isCreditInvoiceKind(next.kind) ? '' : draft.creditSourceDocumentId };
}
export const invoiceCounterpartiesKey = (companyId: string) => `finansu-harmonija:v18:company-counterparties:${companyId}`;
export function loadInvoiceCounterparties(companyId: string): Company[] {
  const value = JSON.parse(window.localStorage.getItem(invoiceCounterpartiesKey(companyId)) || '[]');
  if (!Array.isArray(value)) throw new Error('This company’s counterparties could not be loaded.');
  return value.filter(row => row && typeof row.id === 'string' && typeof row.name === 'string');
}
export function newInvoiceLine(id: string = crypto.randomUUID()): InvoiceLineDraft {
  return { id, type: invoiceLineTypeValues('', [])[0] || '', catalogId: '', code: '', name: '', description: '', unit: 'vnt', quantity: '1', price: '', discount: '0', vatRate: '21', glAccount: '', vatClassifier: '' };
}
export function newInvoiceDraft(date: string, currency = 'EUR'): InvoiceDraft {
  const options = initialInvoiceStatusOptions();
  return { status: options.find(option => option.value === 'Draft')?.value || options[0]?.value || '', purpose: 'Purchase', kind: 'INVOICE', number: '', series: '', orderNo: '', counterpartyId: '', currency, exchangeRate: '1', invoiceDate: date, operationDate: date, dueDate: date, paymentTerms: '0', glAccount: '', vatClassifier: '', department: '', costCenter: '', project: '', includeVatInDebt: true, responsibleId: '', language: 'EN', notes: '', lines: [newInvoiceLine()] };
}

/** Materialize the current defaults on a new Quantity or Summary row. */
export function appendInvoiceLine(draft: InvoiceDraft, mode: 'quantity' | 'summary', vatOptions: readonly InvoiceVatOption[], id = crypto.randomUUID()): InvoiceDraft {
  const vat = vatOptions.find(option => option.code === draft.vatClassifier);
  const line: InvoiceLineDraft = { ...newInvoiceLine(id), price: mode === 'summary' ? '0' : '',
    vatClassifier: draft.vatClassifier, vatRate: vat?.rate.replace('%', '').trim() || '21',
    department: draft.department, costCenter: draft.costCenter, includeVatInDebt: draft.includeVatInDebt,
    accountingDefaultOverrides: { vatClassifier: false, vatRate: false, department: false, costCenter: false, includeVatInDebt: false } };
  return mode === 'summary' ? { ...draft, allocations: [...(draft.allocations || draft.lines), line] }
    : { ...draft, lines: [...draft.lines, line] };
}

/** Update untouched inherited values only; never replace a row-level choice, including blank/false. */
export function updateInvoiceAccountingDefaults(draft: InvoiceDraft, patch: Partial<Pick<InvoiceDraft, InvoiceAccountingDefaultKey>>, vatOptions: readonly InvoiceVatOption[]): InvoiceDraft {
  const next = { ...draft, ...patch };
  const keys = Object.keys(patch) as InvoiceAccountingDefaultKey[];
  const update = (line: InvoiceLineDraft): InvoiceLineDraft => {
    const changes: Partial<InvoiceLineDraft> = {};
    const overrides = { ...line.accountingDefaultOverrides };
    for (const key of keys) {
      const followsDefault = overrides[key] !== true && (overrides[key] === false || line[key] === undefined
        || line[key] === draft[key] || key === 'vatClassifier' && !line.vatClassifier);
      if (!followsDefault) continue;
      if (key === 'includeVatInDebt') changes.includeVatInDebt = next.includeVatInDebt;
      else changes[key] = next[key];
      overrides[key] = false;
      if (key === 'vatClassifier' && overrides.vatRate !== true) {
        const rate = vatOptions.find(option => option.code === next.vatClassifier)?.rate.replace('%', '').trim() || '21';
        changes.vatRate = rate;
        if (rate !== line.vatRate) changes.vatAmount = undefined;
        overrides.vatRate = false;
      }
    }
    return Object.keys(changes).length ? { ...line, ...changes, accountingDefaultOverrides: overrides } : line;
  };
  return { ...next, lines: draft.lines.map(update), ...(draft.allocations ? { allocations: draft.allocations.map(update) } : {}) };
}

export function invoiceLineVatClassifier(line: InvoiceLineDraft, defaultValue: string) {
  return line.accountingDefaultOverrides?.vatClassifier ? line.vatClassifier : line.vatClassifier || defaultValue;
}
export function invoiceDueDate(date: string, days: string) {
  if (!validDate(date) || !/^\d+$/.test(days)) return '';
  const result = new Date(`${date}T12:00:00Z`);
  result.setUTCDate(result.getUTCDate() + Number(days));
  return result.toISOString().slice(0, 10);
}
function validDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}
function numeric(value: string) {
  const text = String(value ?? '').trim().replace(',', '.');
  return /^\d+(?:\.\d+)?$/.test(text) ? Number(text) : NaN;
}
const money = (amount: number) => Math.round((amount + Number.EPSILON) * 100);
export function invoiceLineAmounts(line: InvoiceLineDraft) {
  const qty = numeric(line.quantity), price = numeric(line.price), discount = numeric(line.discount), rate = numeric(line.vatRate);
  const discountAmount = line.discountAmount === undefined ? undefined : numeric(line.discountAmount);
  const vatAmount = line.vatAmount === undefined ? undefined : numeric(line.vatAmount);
  const valid = [qty, price, discount, rate].every(Number.isFinite) && qty > 0 && price >= 0 && discount >= 0 && discount <= 100 && rate >= 0 && rate <= 100
    && (discountAmount === undefined || Number.isFinite(discountAmount) && discountAmount >= 0 && money(discountAmount) <= money(qty * price))
    && (vatAmount === undefined || Number.isFinite(vatAmount) && vatAmount >= 0);
  const gross = valid ? money(qty * price) : 0;
  const net = valid ? discountAmount === undefined ? money(qty * price * (1 - discount / 100)) : gross - money(discountAmount) : 0;
  const vat = valid ? vatAmount === undefined ? Math.round((net * rate / 100) + Number.EPSILON) : money(vatAmount) : 0;
  return { valid: valid && [gross, net, vat, net + vat].every(Number.isSafeInteger), gross, discount: gross - net, net, vat, total: net + vat };
}

/** Display-only prices derive from the same cent-rounded line amounts.
 * VAT-inclusive unit price is before discount; discounted unit price excludes VAT. */
export function invoiceLinePricing(line: InvoiceLineDraft) {
  const amounts = invoiceLineAmounts(line);
  if (!amounts.valid) return null;
  return {
    discountPercent: line.discountAmount === undefined ? numeric(line.discount) : amounts.gross ? amounts.discount / amounts.gross * 100 : 0,
    unitPriceInclVat: numeric(line.price) * (1 + numeric(line.vatRate) / 100),
    discountedUnitPrice: amounts.net / 100 / numeric(line.quantity),
    amountAfterDiscountExclVat: amounts.net / 100,
  };
}

export function updateInvoiceLine(line: InvoiceLineDraft, patch: Partial<InvoiceLineDraft>): InvoiceLineDraft {
  const recalculatesVat = ['quantity', 'price', 'discount', 'discountAmount', 'vatRate'].some(key => key in patch);
  const discountChange = 'discountAmount' in patch && patch.discountAmount !== undefined ? { discount: '0' }
    : 'discount' in patch ? { discountAmount: undefined } : {};
  const keys = (['vatClassifier', 'vatRate', 'department', 'costCenter', 'includeVatInDebt'] as const).filter(key => key in patch);
  const overrides = { ...line.accountingDefaultOverrides };
  for (const key of keys) overrides[key] = patch[key] !== undefined;
  return { ...line, ...discountChange, ...(recalculatesVat ? { vatAmount: undefined } : {}), ...patch,
    ...(keys.length ? { accountingDefaultOverrides: overrides } : {}) };
}

export function invoiceAllocationError(draft: InvoiceDraft): string {
  if (!draft.allocations) return '';
  if (!draft.allocations.length || draft.allocations.length > 500) return 'Add between 1 and 500 Summary lines.';
  const buckets = (rows: InvoiceLineDraft[]) => {
    const result = new Map<string, { net: number; vat: number }>();
    for (const row of rows) {
      const amounts = invoiceLineAmounts(row);
      if (!amounts.valid) return null;
      const key = String(numeric(row.vatRate));
      const current = result.get(key) || { net: 0, vat: 0 };
      result.set(key, { net: current.net + amounts.net, vat: current.vat + amounts.vat });
    }
    return result;
  };
  const quantity = buckets(draft.lines), summary = buckets(draft.allocations);
  if (!quantity || !summary) return 'Check quantity, price, discount and VAT on every line.';
  for (const key of new Set([...quantity.keys(), ...summary.keys()])) {
    const left = quantity.get(key) || { net: 0, vat: 0 }, right = summary.get(key) || { net: 0, vat: 0 };
    if (left.net !== right.net || left.vat !== right.vat) return 'Summary amounts and VAT must match Quantity lines for each VAT rate. Update the allocation or use Split.';
  }
  return '';
}

/** Split the current document totals without modifying quantities or losing cents.
 * Different VAT rates are allocated separately by the user, never blended. */
export function splitInvoiceLines(source: InvoiceLineDraft[], targets: InvoiceLineDraft[], mode: 'equal' | 'percent' | 'amount', values: Record<string, string>, options: { allowUnpricedTargets?: boolean } = {}): InvoiceLineDraft[] {
  if (!source.length || !targets.length || targets.length > 500) throw new Error('Add lines before splitting.');
  const targetIds = new Set(targets.map(row => row.id));
  const pricedSource = source.filter((row, index) => {
    // A newly added Quantity destination has quantity 1 and no price yet.
    // Split supplies its price; it must not become an incomplete source amount.
    // Summary allocations still require every original Quantity line to be priced.
    const unpricedTarget = options.allowUnpricedTargets && targetIds.has(row.id) && !row.price.trim();
    const checked = unpricedTarget ? { ...row, price: '0' } : row;
    if (!invoiceLineAmounts(checked).valid) {
      const qty = numeric(checked.quantity), price = numeric(checked.price), discount = numeric(checked.discount), rate = numeric(checked.vatRate);
      const prefix = `Quantity line ${index + 1}: `;
      if (!Number.isFinite(qty) || qty <= 0) throw new Error(`${prefix}enter a Quantity greater than zero.`);
      if (!Number.isFinite(price) || price < 0) throw new Error(`${prefix}enter a valid Price (zero or greater).`);
      if (!Number.isFinite(discount) || discount < 0 || discount > 100) throw new Error(`${prefix}Discount % must be between 0 and 100.`);
      if (!Number.isFinite(rate) || rate < 0 || rate > 100) throw new Error(`${prefix}VAT % must be between 0 and 100.`);
      if (checked.discountAmount !== undefined && (!Number.isFinite(numeric(checked.discountAmount)) || numeric(checked.discountAmount) < 0 || money(numeric(checked.discountAmount)) > money(qty * price))) throw new Error(`${prefix}Discount amount must be between zero and the line amount.`);
      if (checked.vatAmount !== undefined && (!Number.isFinite(numeric(checked.vatAmount)) || numeric(checked.vatAmount) < 0)) throw new Error(`${prefix}enter a valid VAT amount (zero or greater).`);
      throw new Error(`${prefix}the amount is too large to split safely.`);
    }
    if (unpricedTarget && row.vatAmount !== undefined && numeric(row.vatAmount) > 0) throw new Error(`Quantity line ${index + 1}: enter a Price before splitting a line with a VAT amount.`);
    return !unpricedTarget;
  });
  if (!pricedSource.length) throw new Error('Enter a Price on at least one Quantity line before splitting.');
  if (new Set(pricedSource.map(row => numeric(row.vatRate))).size !== 1) throw new Error('Different VAT rates must be allocated separately in Summary.');
  const totals = pricedSource.reduce((sum, row) => { const amount = invoiceLineAmounts(row); return { net: sum.net + amount.net, vat: sum.vat + amount.vat }; }, { net: 0, vat: 0 });
  if (![totals.net, totals.vat, totals.net + totals.vat].every(Number.isSafeInteger)) throw new Error('The invoice total is too large to split safely.');
  const weights = targets.map(row => mode === 'equal' ? 1 : numeric(values[row.id]));
  if (weights.some(value => !Number.isFinite(value) || value < 0)) throw new Error('Enter a valid non-negative value for every line.');
  const totalWeight = weights.reduce((sum, value) => sum + value, 0);
  if (mode === 'percent' && Math.abs(totalWeight - 100) > 0.000001) throw new Error('Split percentages must total 100%.');
  if (mode === 'amount' && weights.reduce((sum, value) => sum + money(value), 0) !== totals.net) throw new Error('Split amounts must equal the invoice amount excluding VAT.');
  if (!totalWeight && totals.net) throw new Error('The split total must be greater than zero.');
  let weight = 0, previousNet = 0, previousVat = 0;
  return targets.map((row, index) => {
    weight += totalWeight ? weights[index] / totalWeight : 1 / targets.length;
    const cumulativeNet = mode === 'amount' ? previousNet + money(weights[index]) : index === targets.length - 1 ? totals.net : Math.round(totals.net * weight);
    const cumulativeVat = index === targets.length - 1 ? totals.vat : Math.round(totals.vat * weight);
    const net = cumulativeNet - previousNet, vat = cumulativeVat - previousVat;
    previousNet = cumulativeNet; previousVat = cumulativeVat;
    return { ...row, quantity: '1', price: (net / 100).toFixed(2), discount: '0', discountAmount: undefined, vatRate: pricedSource[0].vatRate, vatAmount: (vat / 100).toFixed(2) };
  });
}
export function invoiceTotals(draft: InvoiceDraft) {
  const sign = isCreditInvoiceKind(draft.kind) ? -1 : 1;
  return draft.lines.reduce((sum, line) => {
    const value = invoiceLineAmounts(line);
    return { gross: sum.gross + sign * value.gross, discount: sum.discount + sign * value.discount, net: sum.net + sign * value.net, vat: sum.vat + sign * value.vat, total: sum.total + sign * value.total };
  }, { gross: 0, discount: 0, net: 0, vat: 0, total: 0 });
}

export function invoiceLineIncludesVatInDebt(line: InvoiceLineDraft, defaultValue: boolean) {
  return line.includeVatInDebt ?? defaultValue;
}

/** Separate Summary allocations define the accounting debt, without changing
 * the invoice's net amount, VAT or gross total from the Quantity lines. */
export function invoiceAmountDue(draft: InvoiceDraft) {
  const sign = isCreditInvoiceKind(draft.kind) ? -1 : 1;
  return (draft.allocations || draft.lines).reduce((sum, line) => {
    const amounts = invoiceLineAmounts(line);
    return sum + sign * (amounts.net + (invoiceLineIncludesVatInDebt(line, draft.includeVatInDebt) ? amounts.vat : 0));
  }, 0);
}

export function invoiceTotalsPresentation(draft: InvoiceDraft, baseCurrency: string) {
  const totals = invoiceTotals(draft);
  const rows = [{ label: 'Subtotal excl. VAT', amount: totals.gross },
    ...(totals.discount !== 0 ? [{ label: 'Discount', amount: -totals.discount }] : []),
    { label: 'VAT amount', amount: totals.vat }];
  const rate = numeric(draft.exchangeRate);
  // Round the absolute amount before restoring the sign so credit notes are symmetric.
  const converted = Math.sign(totals.total) * Math.round(Math.abs(totals.total) * rate);
  return { rows, amountDue: invoiceAmountDue(draft), accounting: draft.currency === baseCurrency ? null : {
    currency: baseCurrency, total: Number.isFinite(rate) && rate > 0 && Number.isSafeInteger(converted) ? converted : null,
  } };
}

/** Only configured document-level dimensions; no duplicates of Basic information or Accounting defaults. */
export function invoiceDocumentAnalytics(companyId: string, lookups: readonly { type: string; value: string; inactive?: boolean; active?: boolean; status?: string }[], draft: InvoiceDraft) {
  return ([
    { key: 'project', label: 'Object / Project', type: 'object_project' },
    { key: 'analyticalSeries', label: 'Analytical series', type: 'analytical_series' },
    { key: 'mainAnalyticalAccount', label: 'Main analytical account', type: 'main_analytical_account' },
    { key: 'relatedContract', label: 'Related contract', type: 'related_contract' },
  ] as const).flatMap(field => {
    const values = [...new Set(lookups.filter(row => row.type === `${field.type}::company::${companyId}` && typeof row.value === 'string' && !row.inactive && row.active !== false && row.status?.toLowerCase() !== 'inactive').map(row => row.value.trim()).filter(Boolean))];
    const selected = draft[field.key] || '';
    if (selected && !values.includes(selected)) values.push(selected);
    return values.length ? [{ ...field, options: [{ value: '', label: '—' }, ...values.map(value => ({ value, label: value }))] }] : [];
  });
}

export function prepareInvoiceDocument(command: CreateInvoiceCommand, context: { company: Company; counterparty: Company; invoiceTypes: readonly InvoiceTypeRecord[]; lineTypes?: readonly string[]; allowed: boolean; actor: string; now: string; responsible: { accountable_responsible: string; accountable_responsible_id: string }; responsibleUsers?: LinkedDirectoryUser[]; warehouse?: WarehouseStore | null; documents?: readonly InvoiceCreditSource[]; existingDocument?: Record<string, unknown> }) {
  if (!context.allowed) throw new Error('You need View and Create access to this company’s documents.');
  if (!/^[\w-]{8,80}$/.test(command.requestId)) throw new Error('Invalid invoice request. Reopen Create invoice.');
  const copySource = command.copySourceDocumentId ? context.documents?.find(row => row.id === command.copySourceDocumentId
    && row.company_id === context.company.id && !row.document_deletion) : undefined;
  if (command.copySourceDocumentId && (!copySource || context.existingDocument)) throw new Error('The copy source has moved or is no longer available in this company.');
  const draft = command.draft;
  if (typeof draft.includeVatInDebt !== 'boolean') throw new Error('Select a valid Include VAT in debt default.');
  const statusOptions = context.existingDocument ? documentStatusOptions() : initialInvoiceStatusOptions();
  if ((!context.existingDocument || draft.status !== context.existingDocument.status) && !statusOptions.some(option => option.value === draft.status)) throw new Error(context.existingDocument ? 'Select a valid invoice status.' : 'Select a valid initial invoice status. Approval, payment and transfer require their own workflow.');
  if (!['Purchase', 'Sale'].includes(draft.purpose)) throw new Error('Select the document purpose.');
  if ((!context.existingDocument || draft.kind !== context.existingDocument.document_subtype) && !invoiceTypeOptions(context.invoiceTypes).some(option => option.value === draft.kind)) throw new Error('Select an active Invoice type from OCR → Administration → Document type → Invoices.');
  if (!draft.number.trim() || draft.number.trim().length > 100) throw new Error('Enter an invoice number (up to 100 characters).');
  if (!context.counterparty.id || context.counterparty.id !== draft.counterpartyId) throw new Error('Select a counterparty from this company’s list.');
  if (draft.creditSourceDocumentId !== undefined && typeof draft.creditSourceDocumentId !== 'string') throw new Error('Select a valid document to reconcile.');
  const creditSource = draft.creditSourceDocumentId
    ? invoiceCreditSources(context.documents || [], context.company.id, draft.purpose).find(row => row.id === draft.creditSourceDocumentId) : undefined;
  if (draft.creditSourceDocumentId && (!isCreditInvoiceKind(draft.kind) || !creditSource)) throw new Error('The selected document is no longer available for this credit invoice. Select a document from the same company and purpose.');
  if (creditSource && !invoiceCreditCounterparty(creditSource, [context.counterparty])) throw new Error('The credit invoice counterparty must match the selected document.');
  if (!validDate(draft.invoiceDate) || !validDate(draft.operationDate) || !validDate(draft.dueDate) || draft.dueDate < draft.invoiceDate) throw new Error('Check invoice, operation and due dates.');
  if (!/^[A-Z]{3}$/.test(draft.currency)) throw new Error('Select a valid currency.');
  const baseCurrency = context.company.base_currency || 'EUR';
  const exchangeRate = draft.currency === baseCurrency ? 1 : numeric(draft.exchangeRate);
  if (!Number.isFinite(exchangeRate) || exchangeRate <= 0) throw new Error('Enter an exchange rate greater than zero.');
  if (!draft.lines.length || draft.lines.length > 500) throw new Error('Add between 1 and 500 invoice lines.');
  const allocationError = invoiceAllocationError(draft);
  if (allocationError) throw new Error(allocationError);
  if (draft.notes.length > 10000) throw new Error('Notes must not exceed 10,000 characters.');
  for (const [key, label, limit] of [['analyticalSeries', 'Analytical series', 100], ['mainAnalyticalAccount', 'Main analytical account', 100], ['relatedContract', 'Related contract', 200]] as const) {
    if (draft[key] !== undefined && (typeof draft[key] !== 'string' || draft[key].length > limit)) throw new Error(`Check document ${label} (up to ${limit} characters).`);
  }
  if (draft.purpose === 'Sale' && (typeof draft.customerManagerId !== 'string' && draft.customerManagerId !== undefined)) throw new Error('Select a valid Customer manager.');
  const customerManager = documentResponsiblePatch(draft.purpose === 'Sale' ? draft.customerManagerId || '' : '', context.responsibleUsers || []);
  if (draft.purpose === 'Sale' && !['EN', 'LT'].includes(draft.language)) throw new Error('Select an Invoice language.');
  if (command.attachments.length > 10 || command.attachments.some(file => !file.name || file.size <= 0 || file.size > 10 * 1024 * 1024 || !/^(data:(application\/pdf|image\/(png|jpeg));base64,)/.test(file.url))) throw new Error('Attach up to 10 PDF, PNG or JPG files, each up to 10 MB.');
  const sign = isCreditInvoiceKind(draft.kind) ? -1 : 1;
  const totals = invoiceTotals(draft);
  const amountDue = invoiceAmountDue(draft);
  if (![...Object.values(totals), amountDue].every(Number.isSafeInteger)) throw new Error('Invoice amounts are too large.');
  const mapLine = (line: InvoiceLineDraft, index: number, allocation = false) => {
    const amounts = invoiceLineAmounts(line);
    if (!(context.lineTypes ?? DEFAULT_INVOICE_LINE_TYPES).includes(line.type)) throw new Error(`Select an active Type from this company’s list on line ${index + 1}.`);
    if (!allocation && !(line.name || line.description).trim()) throw new Error(`Enter a name or description on line ${index + 1}.`);
    if (!amounts.valid) throw new Error(`Check quantity, price, discount and VAT rate on line ${index + 1}.`);
    if (line.includeVatInDebt !== undefined && typeof line.includeVatInDebt !== 'boolean') throw new Error(`Check Include VAT in debt on line ${index + 1}.`);
    for (const [key, label, limit] of [['itemCode', 'Item / Service code', 100], ['warehouseId', 'Warehouse', 200], ['lineNote', 'Line note / Comment', 2000], ['analyticalSeries', 'Analytical series', 100], ['mainAnalyticalAccount', 'Main analytical account', 100], ['relatedContract', 'Related contract', 200]] as const) {
      if (line[key] !== undefined && (typeof line[key] !== 'string' || line[key].length > limit)) throw new Error(`Check ${label} on line ${index + 1} (up to ${limit} characters).`);
    }
    if (line.responsibleId !== undefined && typeof line.responsibleId !== 'string') throw new Error(`Select a valid Employee / Responsible person on line ${index + 1}.`);
    const lineResponsible = line.responsibleId === undefined ? context.responsible : documentResponsiblePatch(line.responsibleId, context.responsibleUsers || []);
    const warehouse = context.warehouse?.companyId === context.company.id ? context.warehouse : null;
    if (line.warehouseId && !warehouse?.locations.some(row => row.id === line.warehouseId && row.companyId === context.company.id && !row.inactive)) throw new Error(`Select an active Warehouse from this company on line ${index + 1}.`);
    const items = warehouse?.items.filter(item => item.companyId === context.company.id && !item.inactive && item.code === line.itemCode?.trim()) || [];
    if (line.warehouseId && (line.type !== 'Product' || items.length !== 1 || items[0].type !== 'Product')) throw new Error(`Warehouse is available only for a stocked Product on line ${index + 1}.`);
    return { id: `${command.requestId}:${allocation ? 'allocation' : 'line'}:${index + 1}`, barcode: line.barcode || '', product: (line.name || line.description).trim(), description: line.description.trim(),
      line_number: index + 1, item_code: line.itemCode?.trim() || '', warehouse_id: line.warehouseId || '', stock_item_id: line.type === 'Product' && items.length === 1 ? items[0].id : '',
      line_type: line.type, productGroup: line.productGroup ?? line.type, unit: line.unit, qty: String(sign * numeric(line.quantity)), code: line.code,
      price: numeric(line.price).toString(), subtotal: (sign * amounts.net / 100).toFixed(2), discount: (sign * amounts.discount / 100).toFixed(2), discount_rate: line.discount,
      vat: (sign * amounts.vat / 100).toFixed(2), vatPct: line.vatRate, total: (sign * amounts.total / 100).toFixed(2),
      expense: line.glAccount || draft.glAccount, vatClass: invoiceLineVatClassifier(line, draft.vatClassifier),
      include_vat_in_debt: invoiceLineIncludesVatInDebt(line, draft.includeVatInDebt),
      line_note: line.lineNote?.trim() || '', analytical_series: line.analyticalSeries?.trim() || '', main_analytical_account: line.mainAnalyticalAccount?.trim() || '',
      related_contract: line.relatedContract?.trim() || '', ...lineResponsible,
      ...(line.accountingDefaultOverrides ? { accounting_default_overrides: line.accountingDefaultOverrides } : {}),
      department: line.department ?? draft.department, object: line.project ?? draft.project, center: line.costCenter ?? draft.costCenter, series: line.series ?? draft.series };
  };
  const lines = draft.lines.map((line, index) => mapLine(line, index));
  const allocations = (draft.allocations || draft.lines).map((line, index) => mapLine(line, index, true));
  const one = allocations.length === 1 ? allocations[0] : undefined;
  return {
    id: `invoice-${command.requestId}`, company_id: context.company.id, number: draft.number.trim(), document_type: 'INVOICES', document_subtype: draft.kind,
    type: draft.purpose, document_purpose: draft.purpose, status: draft.status, source: 'Manual', entry_method: 'manual', series: draft.series, order_no: draft.orderNo.trim(),
    counterparty_id: context.counterparty.id, counterparty_code: context.counterparty.company_code, client_counterparty: context.counterparty.name,
    document_date: draft.invoiceDate, operation_date: draft.operationDate, receive_date: context.now.slice(0, 10), due_end_date: draft.dueDate, invoice_contract_date: draft.invoiceDate,
    currency: draft.currency, base_currency: baseCurrency, exchange_rate: String(exchangeRate), exchange_rate_convention: '1 document currency unit = exchange_rate base currency units',
    amount_without_vat: (totals.net / 100).toFixed(2), vat: (totals.vat / 100).toFixed(2), total_amount: (totals.total / 100).toFixed(2),
    amount_due: (amountDue / 100).toFixed(2),
    vat_percent: new Set(lines.map(line => line.vatPct)).size === 1 ? lines[0].vatPct : '',
    expense_account: one?.expense || '', vat_classifier: one?.vatClass || '', department_code: one?.department ?? draft.department, cost_center: one?.center ?? draft.costCenter, object_project: one?.object ?? draft.project,
    ...context.responsible, include_vat_in_debt: draft.includeVatInDebt, invoice_language: draft.purpose === 'Sale' ? draft.language : '', payment_terms: draft.paymentTerms,
    invoice_customer_manager_id: customerManager.accountable_responsible_id, invoice_customer_manager: customerManager.accountable_responsible,
    analytical_series: draft.analyticalSeries?.trim() || '', main_analytical_account: draft.mainAnalyticalAccount?.trim() || '', related_contract: draft.relatedContract?.trim() || '',
    line_items: lines, summary_line_items: allocations,
    invoice_accounting_defaults: { vatClassifier: draft.vatClassifier, department: draft.department, costCenter: draft.costCenter, includeVatInDebt: draft.includeVatInDebt },
    notes: draft.notes.trim(), file_case: command.attachments[0]?.name || '', image_url: command.attachments[0]?.url || null,
    invoice_attachments: command.attachments.map(file => ({ name: file.name, type: file.type, size: file.size, url: file.url })),
    created_by: context.actor, created_at: context.now, creation_request_id: command.requestId,
    ...(copySource ? { copied_from_document_id: copySource.id } : {}),
    ...(creditSource ? { correction_of_document_id: creditSource.id, correction_kind: 'Credit note',
      ...(command.creditNoteSource ? { correction_reason: command.creditNoteSource.reason.trim() } : {}),
      correction_history: [{ id: `${command.requestId}:credit-source`, at: context.now, actor: context.actor, action: 'Credit invoice linked to original document',
        details: `Original: ${creditSource.number}. ${draft.purpose}.${command.creditNoteSource ? ` Reason: ${command.creditNoteSource.reason.trim()}.` : ''} No posting or settlement performed.`, originalDocumentId: creditSource.id }] } : {}),
    creation_history: [{ id: `${command.requestId}:created`, action: draft.status === 'Draft' ? 'Invoice draft created' : 'Invoice created', status: draft.status, at: context.now, actor: context.actor,
      ...(copySource ? { copiedFromDocumentId: copySource.id, details: `Copied from ${copySource.number || copySource.id}. Original document unchanged.` } : {}) }],
  };
}
