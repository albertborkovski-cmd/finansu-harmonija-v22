export type OcrAdditionalInformation = {
  departmentCode: string;
  object: string;
  project: string;
  costCenter: string;
  glAccount: string;
  accountablePerson: string;
  productGroup: string;
  vatClassifier: string;
  source: string;
  detailedSplitting: boolean;
  duplicatesAccepted: boolean;
};

export const EMPTY_OCR_ADDITIONAL_INFORMATION: OcrAdditionalInformation = {
  departmentCode: '', object: '', project: '', costCenter: '', glAccount: '',
  accountablePerson: '', productGroup: '', vatClassifier: '', source: '',
  detailedSplitting: false, duplicatesAccepted: false,
};

// Preserve the existing Dashboard storage key and company-specific settings.
export function ocrAdditionalInformationKey(companyId: string) {
  return `finansu-harmonija:v12:dashboard:ocr-additional-information:${companyId}`;
}

export function readOcrAdditionalInformation(storage: Pick<Storage, 'getItem'>, companyId: string): OcrAdditionalInformation {
  const result = { ...EMPTY_OCR_ADDITIONAL_INFORMATION };
  try {
    const stored: unknown = JSON.parse(storage.getItem(ocrAdditionalInformationKey(companyId)) || 'null');
    if (!stored || typeof stored !== 'object' || Array.isArray(stored)) return result;
    const values = stored as Record<string, unknown>;
    for (const key of Object.keys(result) as (keyof OcrAdditionalInformation)[]) {
      if (key === 'detailedSplitting' || key === 'duplicatesAccepted') {
        if (typeof values[key] === 'boolean') result[key] = values[key];
      } else if (typeof values[key] === 'string') result[key] = values[key];
    }
  } catch { /* Keep the form usable when saved data is unavailable. */ }
  return result;
}

export function isOcrAdditionalInformationShortcut(
  event: Pick<KeyboardEvent, 'code' | 'altKey' | 'ctrlKey' | 'metaKey' | 'repeat' | 'isComposing' | 'defaultPrevented'>,
  isTyping: boolean,
) {
  return !isTyping && !event.repeat && !event.isComposing && !event.defaultPrevented
    && event.code === 'KeyP' && event.altKey && !event.ctrlKey && !event.metaKey;
}
