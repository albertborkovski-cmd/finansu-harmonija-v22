import type { DbDocument } from './supabase';
import type { DocumentIssue } from './documentIssues';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentWorkLog } from '../components/ocrDocumentWorkTimeStore';
import { isInactiveRecord } from './recordLifecycle';

export type MyOcrTask = {
  id: string;
  kind: 'Document review' | 'Document issue';
  document: DbDocument;
  issue?: DocumentIssue;
  savedTask?: WorkspaceTask;
  cells: Record<string, string>;
};

const normalize = (value?: string) => value?.trim().toLowerCase() ?? '';
const COMPLETED_DOCUMENT_STATUSES = new Set(['approved', 'accepted', 'completed', 'processed', 'transferred', 'exported', 'posted', 'paid', 'cancelled', 'canceled', 'inactive', 'deleted']);

/** The Workspace table shows each assigned document once, even if it has several tasks. */
export function assignedOcrDocumentIds(tasks: readonly MyOcrTask[]): ReadonlySet<string> {
  return new Set(tasks.map(task => task.document.id));
}

/** Recheck the current assignment before opening or processing a row from a stale list. */
export function requireAssignedOcrTask(tasks: readonly MyOcrTask[], document: { id: string; companyId?: string }): MyOcrTask {
  const matching = tasks.filter(task => task.document.id === document.id
    && (!document.companyId || task.document.company_id === document.companyId));
  const task = matching.find(item => item.issue) ?? matching[0];
  if (!task) throw new Error('This task is completed, reassigned or no longer accessible.');
  return task;
}

/** Never infer ownership from a display name or from who created the document. */
export function myOcrTasks(documents: DbDocument[], companyNames: ReadonlyMap<string, string>, email: string,
  savedTasks: ReadonlyMap<string, WorkspaceTask>, workLog: OcrDocumentWorkLog,
  access: { documents: boolean; issues: boolean }): MyOcrTask[] {
  const identity = normalize(email);
  if (!identity) return [];
  return documents.flatMap(document => {
    const organization = companyNames.get(document.company_id ?? '');
    if (!organization || isInactiveRecord(document)) return [];
    const rows: MyOcrTask[] = [];
    const common = { organization, number: document.number || document.file_case || '—', fileCase: document.file_case || '—' };
    if (access.issues) for (const issue of document.digitization_issues ?? []) {
      if (issue.status === 'Resolved' || normalize(issue.assignedToEmail) !== identity) continue;
      rows.push({ id: `issue:${document.id}:${issue.id}`, kind: 'Document issue', document, issue,
        cells: { ...common, kind: 'Document issue', description: issue.message, status: issue.status,
          assignedTo: issue.assignedToName || issue.assignedToEmail || '—', assignedAt: issue.assignedAt || '—',
          updatedAt: issue.events.at(-1)?.at || issue.createdAt } });
    }
    const task = savedTasks.get(document.id);
    // Explicit assignment wins over the legacy work log, which records actual OCR work.
    const work = workLog[document.id] ?? workLog[`document-set-${document.id}`];
    const owner = task?.assignedToEmail || work?.email;
    if (access.documents && normalize(owner) === identity && task?.status !== 'Completed'
      && task?.trainingStatus !== 'Confirmed' && task?.teamLeadReview?.status !== 'Pending'
      && !COMPLETED_DOCUMENT_STATUSES.has(normalize(document.status))) {
      rows.push({ id: `document:${document.id}`, kind: 'Document review', document, savedTask: task,
        cells: { ...common, kind: 'Document review', description: document.document_purpose || task?.description || '—',
          status: task?.status || 'In Progress', assignedTo: task?.assignedToName || work?.user || owner || '—',
          assignedAt: task?.assignedAt || task?.editStartedAt || '—', updatedAt: task?.lastCorrectedAt || work?.updatedAt || '—' } });
    }
    return rows;
  }).sort((a, b) => b.cells.updatedAt.localeCompare(a.cells.updatedAt));
}
