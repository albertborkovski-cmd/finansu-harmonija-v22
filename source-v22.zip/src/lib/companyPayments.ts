import { supabase, type Company, type DbDocument } from './supabase';
import { companyBankAccounts } from './bankTransaction';
import { canCreateCompanyBankTransaction } from './bankTransactionCreation';
import { getCurrentUserName } from './currentUser';
import { isInactiveRecord } from './recordLifecycle';

export type PaymentDraft = {
  debtorAccount: string; executionDate: string; counterparty: string; creditorAccount: string;
  amount: string; currency: string; purpose: string; relatedDocumentId: string;
};
export type CompanyPayment = PaymentDraft & {
  id: string; companyId: string; paymentId: string; status: 'Draft';
  relatedDocumentNumber: string; createdAt: string; createdBy: string;
};
export const PAYMENTS_CHANGED = 'finansu-harmonija:payments-changed';
export const companyPaymentsKey = (companyId: string) => `finansu-harmonija:v20:payments:${companyId}`;
export const newPaymentDraft = (currency = ''): PaymentDraft => ({ debtorAccount: '', executionDate: '', counterparty: '', creditorAccount: '', amount: '', currency, purpose: '', relatedDocumentId: '' });

export function paymentRelatedDocuments(documents: readonly DbDocument[], companyId: string) {
  return documents.filter(row => row.company_id === companyId && !row.document_deletion && !isInactiveRecord(row)
    && !row.bank_transaction && row.type !== 'Bank' && row.document_type !== 'Bank transaction');
}

export function preparePaymentDraft(company: Company, id: string, input: PaymentDraft, documents: readonly DbDocument[], at: string, actor: string): CompanyPayment {
  const draft = Object.fromEntries(Object.keys(newPaymentDraft()).map(key => [key, String(input[key as keyof PaymentDraft] ?? '').trim()])) as PaymentDraft;
  if (!id || isInactiveRecord(company)) throw new Error('This company is not available for new payments.');
  if (!companyBankAccounts(company).some(account => account.iban === draft.debtorAccount)) throw new Error('Select an active debtor bank account belonging to this company.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(draft.executionDate) || !Number.isFinite(Date.parse(draft.executionDate))
    || new Date(draft.executionDate).toISOString().slice(0, 10) !== draft.executionDate) throw new Error('Enter a valid execution date.');
  if (!draft.counterparty || draft.counterparty.length > 300) throw new Error('Enter a beneficiary name (up to 300 characters).');
  draft.creditorAccount = draft.creditorAccount.replace(/\s/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(draft.creditorAccount)) throw new Error('Enter a valid beneficiary IBAN.');
  draft.amount = draft.amount.replace(',', '.');
  const amount = Number(draft.amount), minor = Math.round(amount * 100);
  if (!/^\d+(?:\.\d{1,2})?$/.test(draft.amount) || amount <= 0 || !Number.isSafeInteger(minor)) throw new Error('Enter a positive amount with up to two decimal places.');
  draft.amount = amount.toFixed(2);
  draft.currency = draft.currency.toUpperCase();
  if (!/^[A-Z]{3}$/.test(draft.currency)) throw new Error('Select a currency.');
  if (!draft.purpose || draft.purpose.length > 2000) throw new Error('Enter the purpose of payment (up to 2,000 characters).');
  const related = paymentRelatedDocuments(documents, company.id).find(row => row.id === draft.relatedDocumentId);
  if (draft.relatedDocumentId && !related) throw new Error('Select an available document belonging to this company.');
  return { ...draft, id, companyId: company.id, paymentId: `PAY-${id.slice(0, 8).toUpperCase()}`, status: 'Draft',
    relatedDocumentNumber: related?.number || '', createdAt: at, createdBy: actor };
}

export function loadCompanyPayments(companyId: string): CompanyPayment[] {
  const raw = window.localStorage.getItem(companyPaymentsKey(companyId));
  if (raw === null) return [];
  const value = JSON.parse(raw);
  if (value?.version !== 1 || value.companyId !== companyId || !Array.isArray(value.records)
    || value.records.some((row: CompanyPayment) => !row || row.companyId !== companyId || typeof row.id !== 'string' || row.status !== 'Draft'))
    throw new Error('Payment drafts could not be read. Existing data has not been overwritten.');
  return value.records;
}

/** Saves a local draft only: no bank submission, journal posting or reconciliation. */
export async function saveCompanyPaymentDraft(companyId: string, id: string, draft: PaymentDraft) {
  const result = await supabase.from('companies').select('*').eq('id', companyId);
  const company = result.data?.[0] as unknown as Company | undefined;
  if (result.error || !company || !canCreateCompanyBankTransaction(company)) throw new Error('You do not have permission to create this company’s payments.');
  const documents = draft.relatedDocumentId ? await supabase.from('documents').select('*').eq('company_id', companyId) : { data: [], error: null };
  if (documents.error) throw new Error('Related documents could not be checked. Please try again.');
  const record = preparePaymentDraft(company, id, draft, documents.data as unknown as DbDocument[], new Date().toISOString(), getCurrentUserName());
  if (!canCreateCompanyBankTransaction(company)) throw new Error('Your permission to create payments has changed.');
  const records = loadCompanyPayments(companyId);
  if (records.some(row => row.id === id)) throw new Error('This payment draft has already been saved.');
  window.localStorage.setItem(companyPaymentsKey(companyId), JSON.stringify({ version: 1, companyId, records: [record, ...records] }));
  window.dispatchEvent(new CustomEvent(PAYMENTS_CHANGED, { detail: { companyId } }));
  return record;
}
