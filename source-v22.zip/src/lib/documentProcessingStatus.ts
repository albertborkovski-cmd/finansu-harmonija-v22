export const DOCUMENT_PROCESSING_STATUSES = [
  'Draft', 'Pending', 'Paid', 'Processing', 'Rejected', 'Provide Additional',
  'Exception', 'Transferred', 'Duplicate', 'Not Documented',
] as const;

type StatusRecord = { code: string; fullName: string; description: string; country: string; status: string; parentCode: string };
export const DOCUMENT_STATUS_CATALOG_KEY = 'finansu-harmonija:organization-reference:Document Status';
const systemValues: Record<string, string> = {
  DRAFT: 'Draft', PENDING: 'Pending', PAID: 'Paid', PROCESSING: 'Processing', REJECTED: 'Rejected',
  PROVIDE_ADDITIONAL_DATA: 'Provide Additional', EXCEPTION: 'Exception', TRANSFERRED: 'Transferred',
  DUPLICATE: 'Duplicate', NOT_DOCUMENT: 'Not Documented', NEW: 'New', APPROVED: 'Approved', CORRECTING: 'Correcting',
};
export const DEFAULT_DOCUMENT_STATUS_RECORDS: StatusRecord[] = Object.entries(systemValues).map(([code, fullName]) => ({ code, fullName, description: '', country: '', status: 'Active', parentCode: '' }));
export function loadDocumentStatusCatalog(): StatusRecord[] {
  try {
    const raw = typeof window === 'undefined' ? null : window.localStorage.getItem(DOCUMENT_STATUS_CATALOG_KEY);
    if (raw === null) return DEFAULT_DOCUMENT_STATUS_RECORDS.map(row => ({ ...row }));
    const stored: unknown = JSON.parse(raw);
    if (!Array.isArray(stored)) return [];
    const records: StatusRecord[] = stored.flatMap(item => {
      if (typeof item === 'string') {
        const base = DEFAULT_DOCUMENT_STATUS_RECORDS.find(row => row.code === item || row.fullName === item);
        return [{ ...(base ?? { code: item, fullName: item, description: '', country: '', status: 'Active', parentCode: '' }) }];
      }
      if (!item || typeof item.code !== 'string' || !item.code.trim()) return [];
      return [{ code: item.code.trim(), fullName: String(item.fullName || item.code), description: String(item.description || ''), country: '', status: item.status === 'Inactive' ? 'Inactive' : 'Active', parentCode: '' }];
    });
    // Legacy settings contained only seven statuses. Backfill missing workflow entries without replacing edits.
    return [...records, ...DEFAULT_DOCUMENT_STATUS_RECORDS.filter(base => !records.some(row => row.code === base.code)).map(row => ({ ...row }))];
  } catch { return []; }
}
export const isSystemDocumentStatusCode = (code: string) => Object.hasOwn(systemValues, code);
export const documentStatusValue = (code: string) => Object.hasOwn(systemValues, code) ? systemValues[code] : `custom:${code}`;
export function documentStatusOptions() {
  return loadDocumentStatusCatalog().filter(row => row.status === 'Active').map(row => ({ value: documentStatusValue(row.code), label: row.fullName }));
}
export function initialInvoiceStatusOptions() {
  return documentStatusOptions().filter(option => option.value.startsWith('custom:') || ['Draft', 'Pending', 'Rejected', 'Provide Additional', 'Exception', 'Duplicate', 'Not Documented', 'New', 'Correcting'].includes(option.value));
}
export function documentStatusLabel(value: unknown) {
  const status = documentProcessingStatus(value);
  return loadDocumentStatusCatalog().find(row => documentStatusValue(row.code) === status)?.fullName || status;
}

/** Legacy payment lateness is not evidence of a document processing state.
 * Keep the stored value/history intact; show an unspecified processing state. */
export function documentProcessingStatus(value: unknown): string {
  const status = typeof value === 'string' ? value.trim() : '';
  return status.toLowerCase() === 'overdue' ? '' : status;
}
