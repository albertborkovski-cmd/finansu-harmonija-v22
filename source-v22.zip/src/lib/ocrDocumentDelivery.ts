import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canEditCompanyDocuments, canViewCompanyDocuments } from './documentEditAccess';
import { downloadDocumentExport, selectedDocumentRecords } from './documentExport';
import { buildDocumentAccountingExport } from './documentAccountingExport';
import type { TestDeliveryCommand } from './documentTestDelivery';
import { applyDocumentTestDelivery, saveCompanyAccountingDestination, supabase, type Company, type DbDocument } from './supabase';

export type OcrDeliveryRequest = { mode: 'transfer' | 'export'; ids: string[] };

export function canUseOcrDocumentDelivery(mode: OcrDeliveryRequest['mode']) {
  const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  return !!session && canViewMenu(session, 'ocr-review-approve-documents')
    && (mode === 'export' || canEditMenu(session, 'ocr-review-approve-documents'));
}

/** Resolve explicit IDs again for every operation, independently of table filters. */
export async function loadOcrDeliveryRecords(request: OcrDeliveryRequest) {
  if (!canUseOcrDocumentDelivery(request.mode)) throw new Error('You no longer have access to this action in Approve documents.');
  const [documentResult, companyResult] = await Promise.all([
    supabase.from('documents').select('*').in('id', request.ids),
    supabase.from('companies').select('*'),
  ]);
  if (documentResult.error || companyResult.error) throw new Error(documentResult.error?.message || companyResult.error?.message);
  if (!canUseOcrDocumentDelivery(request.mode)) throw new Error('Your access changed. Reopen Approve documents.');
  const documents = selectedDocumentRecords((documentResult.data ?? []) as unknown as DbDocument[], request.ids);
  const companies = (companyResult.data ?? []) as unknown as Company[];
  const companyIds = new Set(documents.map(document => document.company_id));
  for (const companyId of companyIds) {
    const company = companies.find(item => item.id === companyId);
    const allowed = request.mode === 'transfer' ? canEditCompanyDocuments(company) : canViewCompanyDocuments(company);
    if (!allowed) throw new Error('You no longer have access to one of the selected documents. Refresh the list.');
  }
  return { documents, companies: companies.filter(company => companyIds.has(company.id)) };
}

export async function exportOcrDocuments(request: OcrDeliveryRequest, destinationId: string) {
  if (request.mode !== 'export') throw new Error('Reopen Export selected documents.');
  const { documents, companies } = await loadOcrDeliveryRecords(request);
  if (companies.length !== 1) throw new Error('Select documents from one company for each export.');
  downloadDocumentExport(buildDocumentAccountingExport(documents.map(document => ({ ...document })), request.ids, companies[0], destinationId));
}

export async function sendOcrDocuments(request: OcrDeliveryRequest, command: TestDeliveryCommand) {
  if (request.mode !== 'transfer'
    || JSON.stringify([...new Set(request.ids)].sort()) !== JSON.stringify([...new Set(command.ids)].sort())) {
    throw new Error('The selected documents changed. Reopen Send to accounting.');
  }
  const { companies } = await loadOcrDeliveryRecords(request);
  if (companies.length !== 1 || companies[0].id !== command.companyId) throw new Error('Select documents from one company for each transfer.');
  // Same adapter as Companies / Documents: issue/state checks, receipts and audit.
  return applyDocumentTestDelivery(command);
}

export async function saveOcrDeliveryDestination(request: OcrDeliveryRequest, companyId: string, destinationId: string) {
  if (request.mode !== 'transfer') throw new Error('Export choices do not change the company’s sending destination.');
  const { companies } = await loadOcrDeliveryRecords(request);
  if (companies.length !== 1 || companies[0].id !== companyId) throw new Error('Reopen Send to accounting to choose a destination.');
  return saveCompanyAccountingDestination(companyId, destinationId);
}
