type DocumentState = {
  status?: string; source?: string; entry_method?: string;
  inactive?: boolean; active?: boolean; is_active?: boolean;
  ocr_rerun_request?: { status?: string };
  digitization_issues?: { status?: string }[];
  ocr_approval_route?: { destination?: string };
};
type TaskState = {
  status?: string; trainingStatus?: string;
  ocrRunRequest?: { status?: string };
  teamLeadReview?: { status?: string };
};
export type OcrDocumentStage = { queue: 'processing' | 'approval'; status: string };
const normalize = (value?: string) => value?.trim().toLowerCase() || '';
const pending = (value?: string) => ['pending integration', 'pending', 'queued', 'processing', 'in progress'].includes(normalize(value));

/** OCR work stages are separate from the invoice's accounting status.
 * An explicit rerun takes precedence over an older completed task. */
export function ocrDocumentStage(document: DocumentState, task?: TaskState): OcrDocumentStage | null {
  const state = normalize(document.status);
  if (document.inactive || document.active === false || document.is_active === false
    || ['deleted', 'inactive', 'cancelled', 'canceled', 'reversed', 'storno'].includes(state)) return null;
  if (pending(document.ocr_rerun_request?.status) || document.digitization_issues?.some(issue => issue.status === 'Awaiting OCR'))
    return { queue: 'processing', status: 'Awaiting OCR' };
  if (['approved', 'confirmed', 'posted', 'transferred', 'exported', 'paid'].includes(state)) return null;
  if (document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status || '')))
    return { queue: 'processing', status: 'Needs correction' };
  if (normalize(document.entry_method) === 'manual' && !task) return null;
  if (['processing', 'in progress'].includes(state)) return { queue: 'processing', status: 'Processing' };
  if (['queued', 'awaiting ocr', 'pending ocr'].includes(state)) return { queue: 'processing', status: state === 'queued' ? 'Queued' : 'Awaiting OCR' };
  if (task?.teamLeadReview?.status === 'Pending') return { queue: 'approval', status: 'Awaiting approval' };
  if (document.ocr_approval_route?.destination === 'TeamLead') return { queue: 'approval', status: 'Awaiting approval' };
  if (document.ocr_approval_route?.destination === 'FH') return null;
  if (normalize(task?.status) === 'completed' || task?.trainingStatus === 'Confirmed')
    return { queue: 'approval', status: 'Awaiting approval' };
  if (pending(task?.ocrRunRequest?.status)) return { queue: 'processing', status: 'Awaiting OCR' };
  if (['accepted', 'completed', 'processed', 'need review', 'needs review', 'awaiting approval'].includes(state))
    return { queue: 'approval', status: 'Awaiting approval' };
  if (['in progress', 'processing'].includes(normalize(task?.status))) return { queue: 'processing', status: 'In progress' };
  // A manual accounting document does not enter OCR merely because it is Draft.
  const source = normalize(document.entry_method || document.source);
  if (!source || source === 'manual') return null;
  if (['new', 'pending', 'draft', 'uploaded'].includes(state)) return { queue: 'processing', status: 'Queued' };
  if (['correcting', 'provide additional', 'provide additional data', 'exception', 'duplicate', 'rejected', 'not document', 'not documented'].includes(state))
    return { queue: 'processing', status: 'Needs correction' };
  return null;
}
