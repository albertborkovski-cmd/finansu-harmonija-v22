import type { DbDocument } from './supabase';

const legacySuppliers = ['UAB Robolabs', 'MB Technologijos', 'UAB Sprendimų grupė', 'UAB IT Sprendimai'];
const workerSuppliers = ['Baltic Office UAB', 'Amber Technology UAB', 'City Property UAB', 'Northwind Services UAB', 'Atlantic Cloud Ltd',
  'London Software Ltd', 'River Transport UAB', 'Green Energy UAB', 'Sunrise Projects UAB', 'Horizon Partners Ltd', 'Warehouse Supply UAB', 'Studio Partners UAB'];

/** Only known synthetic fixture identities are eligible. Never invent values for uploads. */
export function ocrReviewExampleCompletion(document: Partial<DbDocument> & { ocr_example_completion_version?: number }) {
  if (document.ocr_example_completion_version || document.document_deletion) return null;
  const legacyId = document.id?.match(/^10000000-0000-4000-8000-(\d{12})$/);
  const sequence = Number(legacyId?.[1]);
  const legacy = sequence >= 1 && sequence <= 30 && document.client_counterparty === legacySuppliers[(sequence - 1) % 4]
    ? (sequence - 1) % 4 : -1;
  const workerMatch = document.id?.match(/:v22-ocr-my-tasks-v1:(\d{3})$/);
  const worker = workerMatch && workerSuppliers.indexOf(document.client_counterparty || '');
  let code = '';
  if (typeof legacy === 'number' && legacy >= 0) code = `DEMO-CP-${String(legacy + 1).padStart(3, '0')}`;
  else if (typeof worker === 'number' && worker >= 0 && Number(workerMatch?.[1]) === worker + 1) code = `DEMO-OCR-${String(worker + 1).padStart(3, '0')}`;
  if (!code) return null;
  return { ocr_example_completion_version: 1, ...(!document.counterparty_code?.trim() ? { counterparty_code: code } : {}) };
}
