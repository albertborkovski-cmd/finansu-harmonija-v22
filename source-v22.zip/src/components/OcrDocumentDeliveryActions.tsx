import { translateUi as uiText } from '../i18n/language';
import { useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, Send } from 'lucide-react';
import type { Company, DbDocument } from '../lib/supabase';
import { savedDocumentDeliveryDestination } from '../lib/documentExport';
import { canUseOcrDocumentDelivery, exportOcrDocuments, loadOcrDeliveryRecords, saveOcrDeliveryDestination, sendOcrDocuments, type OcrDeliveryRequest } from '../lib/ocrDocumentDelivery';
import DocumentDeliveryDialog from './DocumentDeliveryDialog';
import { mapRow } from './Documents';
import { PageActionButton } from './PageHeader';

export default function OcrDocumentDeliveryActions({ selectedIds, documents, companies, actionContainer }: {
  selectedIds: ReadonlySet<string>;
  documents: DbDocument[];
  companies: Company[];
  actionContainer?: HTMLElement | null;
}) {
  const [delivery, setDelivery] = useState<OcrDeliveryRequest | null>(null);
  const companyIds = new Set(documents.filter(document => selectedIds.has(document.id)).map(document => document.company_id));
  const company = companyIds.size === 1 ? companies.find(item => companyIds.has(item.id)) : undefined;
  const destination = savedDocumentDeliveryDestination(company);
  const sendAction = <PageActionButton
    ariaLabel={`Send selected documents to ${destination?.label || 'accounting'}`}
    icon={<Send size={15} />}
    disabled={!selectedIds.size || !canUseOcrDocumentDelivery('transfer')}
    onClick={() => setDelivery({ mode: 'transfer', ids: [...selectedIds] })}
  >{`Send to ${destination?.label || 'accounting'}`}</PageActionButton>;

  return <>
    {actionContainer ? createPortal(sendAction, actionContainer) : sendAction}
    <button type="button" data-button-family="export" data-export-icon="download"
      aria-label={uiText("Export selected documents")} title={uiText("Export selected documents")} aria-haspopup="dialog"
      disabled={!selectedIds.size || !canUseOcrDocumentDelivery('export')}
      onClick={() => setDelivery({ mode: 'export', ids: [...selectedIds] })}
      className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] disabled:cursor-not-allowed disabled:text-[#B4B6B8]">
      <Download size={16} strokeWidth={1.8} />
    </button>
    {delivery && <DocumentDeliveryDialog mode={delivery.mode} ids={delivery.ids}
      loadRecords={async () => {
        const result = await loadOcrDeliveryRecords(delivery);
        return { ...result, documents: result.documents.map(mapRow) };
      }}
      onExport={destinationId => exportOcrDocuments(delivery, destinationId)}
      onTestTransfer={async command => (await sendOcrDocuments(delivery, command)).map(mapRow)}
      onSaveDestination={(companyId, destinationId) => saveOcrDeliveryDestination(delivery, companyId, destinationId)}
      onClose={() => setDelivery(null)} />}
  </>;
}
