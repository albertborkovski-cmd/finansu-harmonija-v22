import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState, type FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { RotateCcw, X } from 'lucide-react';
import { LEARNING_FIELDS, LEARNING_MIN_CONSISTENCY, LEARNING_MIN_DOCUMENTS, type LearnedRow, type LearningRuleInput } from '../lib/ocrLearning';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import { PageActionButton } from './PageHeader';

export default function EditLearningRuleDialog({ row, onClose, onSave }: {
  row: LearnedRow; onClose: () => void; onSave: (input: LearningRuleInput | null) => void;
}) {
  const titleId = useId(), valueId = useId(), confidenceId = useId();
  const root = useRef<HTMLDivElement>(null), valueRef = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState(row.value);
  const [confidence, setConfidence] = useState(String(Math.round(row.confidence)));
  const [error, setError] = useState('');
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    valueRef.current?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  const save = (input: LearningRuleInput | null) => {
    try { onSave(input); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Changes could not be saved.'); }
  };
  const submit = (event: FormEvent) => {
    event.preventDefault(); event.stopPropagation();
    save({ value, confidence: confidence.trim() ? Number(confidence) : NaN });
  };
  const inputClass = 'h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 text-[13px] text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10';
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onMouseDown={event => {
    event.stopPropagation(); if (event.target === event.currentTarget) onClose();
  }} onKeyDown={event => {
    event.stopPropagation();
    if (event.key === 'Escape') { event.preventDefault(); onClose(); }
    if (event.key === 'Tab') {
      const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled)')].filter(node => node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }}>
    <div ref={root} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90dvh] w-full max-w-[600px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-start justify-between gap-4 border-b border-[#D3E1EC] px-6 py-4">
        <div><h2 id={titleId} className="text-[18px] font-semibold text-[#10233A]">{uiText("Edit learned field")}</h2><p className="mt-1 text-[12px] text-[#7288A3]">{row.companyName} · {row.supplierName}</p></div>
        <button type="button" aria-label={uiText("Close learned field editor")} onClick={onClose} className="rounded p-1 text-[#7288A3] hover:bg-[#F2F7FC] hover:text-[#007EA7]"><X size={19} /></button>
      </header>
      <form onSubmit={submit} className="flex min-h-0 flex-col">
        <div className="space-y-5 overflow-y-auto px-6 py-5 text-[12px]">
          <div className="rounded-lg bg-[#F2F7FC] px-3 py-2.5"><span className="text-[#7288A3]">{uiText("Field")}</span><p className="mt-1 font-semibold text-[#10233A]">{LEARNING_FIELDS[row.field]}</p><p className="mt-1 text-[#7288A3]">{uiText("Supplier: ")}{row.supplierKey.replace(/^name:/, '')}</p></div>
          <div className="grid gap-4 sm:grid-cols-[1fr_150px]">
            <div className="space-y-2"><label htmlFor={valueId} className="block font-medium text-[#7288A3]">{uiText("Value the system will use ")}<span className="text-[#D92D20]">*</span></label><input id={valueId} ref={valueRef} required maxLength={200} value={value} onChange={event => { setValue(event.target.value); setError(''); }} className={inputClass} /></div>
            <div className="space-y-2"><label htmlFor={confidenceId} className="block font-medium text-[#7288A3]">{uiText("Confidence (%) ")}<span className="text-[#D92D20]">*</span></label><input id={confidenceId} type="number" required min={0} max={100} step={1} value={confidence} onChange={event => { setConfidence(event.target.value); setError(''); }} className={inputClass} /></div>
          </div>
          <p className="leading-5 text-[#7288A3]">{uiText("Applies to future suggestions for this supplier and field. Auto-fill requires ")}{LEARNING_MIN_DOCUMENTS}{uiText(" reviewed documents and ")}{LEARNING_MIN_CONSISTENCY * 100}{uiText("% confidence. Paused learning stays paused. Existing documents and teaching history are not changed.")}</p>
          {row.rule && <p className="text-[#7288A3]">{uiText("Last edited by ")}{row.rule.changedBy.name} · {new Date(row.rule.changedAt).toLocaleString('en-GB')}</p>}
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        </div>
        <footer className="flex flex-wrap justify-end gap-3 border-t border-[#D3E1EC] px-6 py-4">
          {row.rule && <PageActionButton className="mr-auto" icon={<RotateCcw size={14} />} onClick={() => save(null)}>{uiText("Use learned value")}</PageActionButton>}
          <CancelButton onClick={onClose} /><SaveButton type="submit">{uiText("Save changes")}</SaveButton>
        </footer>
      </form>
    </div>
  </div>, document.body);
}
