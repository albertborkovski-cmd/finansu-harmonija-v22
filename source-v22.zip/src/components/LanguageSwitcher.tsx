import { Check, ChevronDown, Languages } from 'lucide-react';
import { useRef, useState } from 'react';
import { getLanguage, setLanguage, translateUi, useLanguage, type Language } from '../i18n/language';
import { useDropdownDismiss } from './useDropdownDismiss';

export default function LanguageSwitcher() {
  const language = useLanguage();
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  useDropdownDismiss(open, root, () => setOpen(false));
  const options: { value: Language; label: string }[] = [{ value: 'en', label: 'English' }, { value: 'lt', label: 'Lietuvių' }];
  return <div ref={root} className="fixed right-[64px] top-2 z-40 font-montserrat" data-language-switcher>
    <button type="button" aria-label={translateUi('Language')} aria-haspopup="listbox" aria-expanded={open}
      onClick={() => setOpen(value => !value)}
      className="flex h-9 items-center gap-1.5 rounded-md border border-[#D3E1EC] bg-white px-2.5 text-[12px] font-semibold text-[#7288A3] shadow-sm hover:border-[#A1B6C6] hover:text-[#007EA7]">
      <Languages size={16} /><span className="w-5 text-center">{language.toUpperCase()}</span><ChevronDown size={12} />
    </button>
    {open && <div role="listbox" aria-label={translateUi('Language')} className="absolute right-0 top-full mt-2 w-44 rounded-lg border border-[#D3E1EC] bg-white p-1 shadow-lg">
      {options.map(option => <button key={option.value} type="button" role="option" aria-selected={option.value === language}
        data-static-selection onClick={() => { if (getLanguage() !== option.value) setLanguage(option.value); setOpen(false); }}
        className={`flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-[13px] font-medium text-[#10233A] hover:bg-[#F2F7FC] ${option.value === language ? 'bg-[#E5EDF9]' : ''}`}>
        <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${option.value === language ? 'border-[#007EA7] bg-[#007EA7] text-white' : 'border-[#A1B6C6] bg-white'}`}>
          {option.value === language && <Check size={12} strokeWidth={2.5} />}
        </span><span lang={option.value}>{option.label}</span>
      </button>)}
    </div>}
  </div>;
}
