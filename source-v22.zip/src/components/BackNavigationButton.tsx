import { translateUi as uiText } from '../i18n/language';
import { ArrowLeft } from "lucide-react";

export default function BackNavigationButton({
  onClick,
  label = "Back to list",
  iconOnly = false,
  disabled = false,
}: {
  onClick: () => void;
  label?: string;
  iconOnly?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      aria-label={uiText(label)}
      className={`flex flex-shrink-0 items-center text-[#007EA7] transition-colors enabled:hover:text-[#006B8F] enabled:hover:underline disabled:cursor-not-allowed disabled:text-[#B4B6B8] ${
        iconOnly
          ? "h-5 w-5 justify-center"
          : "gap-1 font-montserrat text-[12px] font-semibold leading-[18px]"
      }`}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      {!iconOnly && <span className="whitespace-nowrap">{uiText(label)}</span>}
    </button>
  );
}
