import { translateUi as uiText } from '../i18n/language';
import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, ChevronDown, ChevronRight, CornerDownRight, Eye, Info, Pause, Pencil, Play, X } from 'lucide-react';
import EditLearningRuleDialog from './EditLearningRuleDialog';
import { PageActionButton, PageHeader } from './PageHeader';
import OcrBreadcrumb from './OcrBreadcrumb';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters, { type SystemFilterColumn } from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import { usePersistentState } from '../hooks/usePersistentState';
import { useDropdownDismiss } from './useDropdownDismiss';
import { RowDeleteButton } from './DeleteButtons';
import { LEARNING_FIELDS, LEARNING_MIN_CONSISTENCY, LEARNING_MIN_DOCUMENTS, learnedRows, type LearnedRow, type LearningEvidence } from '../lib/ocrLearning';
import { filterLearningRows, learnedColumnValue, learningStatusLabel, learningStatusReason, restoreLearningColumns, LEARNING_STATUS_FILTERS } from '../lib/ocrLearningPresentation';
import { changeLearningState, learningPermissions, loadLearningStore, saveLearningRule, OCR_LEARNING_CHANGED, OCR_LEARNING_KEY } from '../lib/ocrLearningStore';

const COLUMNS: ColConfig[] = [
  { key: 'companyName', label: 'Company', width: 150, visible: true },
  { key: 'supplierKey', label: 'Supplier', width: 180, visible: true },
  { key: 'field', label: 'Field', width: 160, visible: true },
  { key: 'value', label: 'Value the system will use', width: 220, visible: true },
  { key: 'confidence', label: 'Confidence', width: 130, visible: true },
  { key: 'status', label: 'Auto-fill', width: 160, visible: true },
  { key: 'consistency', label: 'Agreement', width: 115, visible: true },
  { key: 'total', label: 'Documents', width: 115, visible: true },
  { key: 'lastSeen', label: 'Last seen', width: 160, visible: true },
];
const dateTime = (value: string) => new Date(value).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' });
const historyId = (row: LearnedRow) => `learning-history-${encodeURIComponent(row.id)}`;

function LearningStatus({ row }: { row: LearnedRow }) {
  const ready = row.status === 'Used automatically';
  const review = row.status === 'Needs review';
  return (
    <div title={learningStatusReason(row)}>
      <span className={`inline-flex max-w-full items-center gap-1.5 rounded px-2 py-1 text-[11px] font-medium ${ready ? 'bg-[#EAF8F2] text-[#087A55]' : review ? 'bg-[#FFF8E5] text-[#9A6700]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>
        {ready ? <CheckCircle2 size={13} className="shrink-0" /> : review ? <AlertTriangle size={13} className="shrink-0" /> : <Pause size={13} className="shrink-0" />}
        <span className="truncate">{learningStatusLabel(row)}</span>
      </span>
      {review && <span className="mt-0.5 block truncate text-[11px] text-[#7288A3]">{row.total < LEARNING_MIN_DOCUMENTS ? `${LEARNING_MIN_DOCUMENTS - row.total} more document${LEARNING_MIN_DOCUMENTS - row.total === 1 ? '' : 's'}` : row.rule ? uiText('Below confidence threshold') : uiText('Conflicting values')}</span>}
    </div>
  );
}

function CompetingLearningValues({ row }: { row: LearnedRow }) {
  return (
    <div role="group" aria-label={`Competing values for ${row.companyName} · ${row.supplierName} · ${LEARNING_FIELDS[row.field]}`}
      className="flex items-start gap-2 border-t border-[#E5EDF9] px-3 py-1.5 text-[11px] leading-4">
      <CornerDownRight size={12} aria-hidden="true" className="mt-0.5 shrink-0 text-[#007EA7]" />
      <div className="flex min-w-0 flex-wrap items-center gap-x-4 gap-y-1 border-l-2 border-[#007EA7]/25 pl-2">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="font-medium text-[#7288A3]">{uiText("Competing values")}</span>
          <span className="text-[#7288A3]">{row.supplierName} · {LEARNING_FIELDS[row.field]}</span>
        </div>
        <dl className="flex flex-wrap items-center gap-x-4 gap-y-1">
          {row.candidates.map(candidate => <div key={candidate.value}
            className="flex items-center gap-1.5 tabular-nums">
            <dt className="font-medium text-[#10233A]">{candidate.value}</dt>
            <dd className="text-[#7288A3]">{candidate.count}{uiText(" document")}{candidate.count === 1 ? '' : 's'}</dd>
          </div>)}
        </dl>
      </div>
    </div>
  );
}

function TeachingHistory({ row, onOpenDocument }: { row: LearnedRow; onOpenDocument: (item: LearningEvidence) => void }) {
  return (
    <div id={historyId(row)} className="border-y border-[#E5EDF9] bg-[#F8FDFF] px-5 py-3">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-[12px]">
        <span className="font-semibold">{uiText("Teaching history ")}<span className="ml-2 font-normal text-[#7288A3]">{row.evidence.length}{uiText(" records · newest first")}</span></span>
        <span className="text-[#7288A3]">{row.control ? `${row.control.paused ? 'Paused' : 'Resumed'} by ${row.control.changedBy.name} · ${dateTime(row.control.changedAt)}` : learningStatusReason(row)}</span>
      </div>
      <table className="w-full table-fixed text-left text-[12px]">
        <thead style={{ top: 40, zIndex: 10 }} className="border-b border-[#D3E1EC] text-[11px] font-medium text-[#7288A3]">
          <tr>{['Document', LEARNING_FIELDS[row.field], 'Confirmed by', 'Confirmed at', 'Learning source'].map(label => <th key={label} scope="col" className="!resize-none px-3 pb-2 font-medium first:pl-0">{uiText(label)}</th>)}<th scope="col" className="!resize-none w-[90px]"><span className="sr-only">{uiText("Actions")}</span></th></tr>
        </thead>
        <tbody>
          {row.evidence.map(item => (
            <tr key={item.id} data-record-inactive={!item.active || undefined} className="h-9 border-b border-[#E5EDF9] last:border-0">
              <td className="pr-3"><button type="button" onClick={() => onOpenDocument(item)} className="max-w-full truncate text-[#007EA7] hover:underline" title={item.documentName}>{item.documentName}</button></td>
              <td className="px-3 font-medium tabular-nums">{item.value}</td>
              <td className="truncate px-3" title={item.confirmedBy.name}>{item.confirmedBy.name}</td>
              <td className="px-3 tabular-nums text-[#7288A3]">{dateTime(item.confirmedAt)}</td>
              <td className="px-3 text-[#7288A3]" title={!item.active ? `${item.retirementReason} by ${item.retiredBy?.name ?? '—'} · ${item.retiredAt ? dateTime(item.retiredAt) : '—'}` : undefined}>{item.active ? uiText('Active') : item.retirementReason}</td>
              <td className="system-table-row-actions py-1 pl-3 text-right"><PageActionButton ariaLabel={`View ${item.documentName}`} icon={<Eye size={14} />} onClick={() => onOpenDocument(item)}>{uiText("View")}</PageActionButton></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function OcrMachineLearningView({ onOpenDocument }: {
  onOpenDocument: (document: LearningEvidence) => void;
}) {
  const [store, setStore] = useState(loadLearningStore);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('');
  const [activeFilterKeys, setActiveFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [columns, setColumns] = usePersistentState<ColConfig[]>('finansu-harmonija:v20:ocr:learning-field-columns', COLUMNS);
  const [columnLayoutVersion, setColumnLayoutVersion] = usePersistentState('finansu-harmonija:v20:ocr:learning-field-columns-version', 0);
  const [showColumns, setShowColumns] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [page, setPage] = useState(1);
  const [expandedHistory, setExpandedHistory] = useState<Set<string>>(new Set());
  const [forgetRow, setForgetRow] = useState<LearnedRow | null>(null);
  const [editRow, setEditRow] = useState<LearnedRow | null>(null);
  const [notice, setNotice] = useState('');
  const helpRef = useRef<HTMLDivElement>(null);
  const tableScrollRef = useRef<HTMLDivElement>(null);
  useDropdownDismiss(showHelp, helpRef, () => setShowHelp(false));
  const { startResize } = useColumnResize(columns, setColumns);
  const permissions = learningPermissions();
  const rows = useMemo(() => learnedRows(store), [store]);
  const filterColumns = useMemo<SystemFilterColumn[]>(() => [
    { key: 'companyName', label: 'Company', options: [...new Set(rows.map(row => row.companyId))], optionLabels: Object.fromEntries(rows.map(row => [row.companyId, row.companyName])) },
    { key: 'supplierKey', label: 'Supplier', options: [...new Set(rows.map(row => row.supplierKey))], optionLabels: Object.fromEntries(rows.map(row => [row.supplierKey, `${row.supplierName} · ${row.supplierKey.replace(/^name:/, '')}`])) },
    { key: 'field', label: 'Field', options: Object.keys(LEARNING_FIELDS), optionLabels: LEARNING_FIELDS },
    { key: 'value', label: 'Value the system will use', options: [...new Set(rows.map(row => row.value).filter(Boolean))] },
  ], [rows]);
  const matchingRows = useMemo(() => filterLearningRows(rows, query, filterValues), [rows, query, filterValues]);
  const filtered = useMemo(() => matchingRows.filter(row => !status || row.status === status), [matchingRows, status]);
  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<LearnedRow, string>(filtered, (row, key) => {
    if (key.startsWith('learned:')) return learnedColumnValue(row, key);
    if (key === 'field') return LEARNING_FIELDS[row.field];
    if (key === 'supplierKey') return row.supplierName;
    if (key === 'vatRate') return row.vatRate === '' ? '' : Number(row.vatRate);
    const value = row[key as keyof LearnedRow];
    return typeof value === 'number' || typeof value === 'string' ? value : '';
  });
  const visibleColumns = columns.filter(column => column.visible);
  const minWidth = visibleColumns.reduce((sum, column) => sum + column.width, 36 + 112);
  const gridTemplateColumns = `36px ${visibleColumns.map(column => `${column.width}px`).join(' ')} minmax(112px, 1fr)`;
  const safePage = Math.min(page, Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE)));

  useEffect(() => {
    if (columnLayoutVersion >= 5) return;
    setColumns(current => restoreLearningColumns(current, COLUMNS));
    setColumnLayoutVersion(5);
  }, [columnLayoutVersion, setColumns, setColumnLayoutVersion]);

  useEffect(() => {
    const refresh = () => setStore(loadLearningStore());
    const storage = (event: StorageEvent) => { if (event.key === OCR_LEARNING_KEY || event.key === null) refresh(); };
    window.addEventListener(OCR_LEARNING_CHANGED, refresh);
    window.addEventListener('storage', storage);
    return () => { window.removeEventListener(OCR_LEARNING_CHANGED, refresh); window.removeEventListener('storage', storage); };
  }, []);
  useEffect(() => {
    if (!forgetRow) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setForgetRow(null); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [forgetRow]);

  const toggleHistory = (row: LearnedRow) => setExpandedHistory(current => {
    const next = new Set(current);
    if (next.has(row.id)) next.delete(row.id); else next.add(row.id);
    return next;
  });
  const act = (row: LearnedRow, action: 'pause' | 'resume' | 'forget') => {
    try {
      const changed = changeLearningState(row.id, action);
      setNotice(changed ? action === 'forget' ? 'Latest teaching source excluded. The document and audit history are retained.'
        : action === 'pause' ? 'Automatic filling paused for this company, supplier and field.' : 'Learning resumed. Confidence thresholds still apply.' : 'This action is not available for your permissions or the current record.');
      setForgetRow(null);
    } catch { setNotice('Changes could not be saved. Please try again.'); }
  };
  const renderCell = (row: LearnedRow, key: string) => {
    if (key === 'field') return <span className="block truncate" title={LEARNING_FIELDS[row.field]}>{LEARNING_FIELDS[row.field]}</span>;
    if (key === 'value' || key.startsWith('learned:')) {
      const value = learnedColumnValue(row, key);
      return value ? <div><button type="button" disabled={!permissions.edit || !row.total} aria-label={`Edit value for ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onClick={() => setEditRow(row)} className="inline-flex max-w-full items-center gap-2 font-semibold text-[#007EA7] disabled:text-[#10233A]" title={value}><span className="truncate tabular-nums">{value}</span>{permissions.edit && <Pencil size={12} className="shrink-0" />}</button>{row.rule && <span className="block text-[11px] text-[#7288A3]">{uiText("Manual setting")}</span>}</div> : <span className="text-[#A1B6C6]" title={uiText("No confirmed learning for this field")}>—</span>;
    }
    if (key === 'confidence') return <button type="button" disabled={!permissions.edit || !row.total} aria-label={`Edit confidence for ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onClick={() => setEditRow(row)} className="inline-flex items-center gap-2 text-[#007EA7] disabled:text-[#7288A3]"><span className="tabular-nums">{Math.round(row.confidence)}%</span>{permissions.edit && <Pencil size={12} />}</button>;
    if (key === 'status') return <LearningStatus row={row} />;
    if (key === 'consistency') return <div className="tabular-nums"><span className="font-medium">{Math.round(row.consistency * 100)}%</span><span className="mt-0.5 block text-[11px] text-[#7288A3]">{row.count}{uiText(" of ")}{row.total}{uiText(" agree")}</span></div>;
    if (key === 'total') return <span className="tabular-nums">{row.total}{uiText(" document")}{row.total === 1 ? '' : 's'}</span>;
    if (key === 'lastSeen') return <span className="tabular-nums">{dateTime(row.lastSeen)}</span>;
    if (key === 'companyName') return <div><span className="block truncate" title={row.companyName}>{row.companyName}</span>{row.sample && <span className="text-[11px] text-[#7288A3]" title={uiText("Demonstration only; never used to fill real documents")}>{uiText("Example data")}</span>}</div>;
    if (key === 'supplierKey') return <div><span className="block truncate font-medium" title={row.supplierName}>{row.supplierName}</span><span className="block truncate text-[11px] text-[#7288A3]" title={row.supplierKey}>{row.supplierKey.replace(/^name:/, '')}</span></div>;
    return '—';
  };

  return (
    <div className="flex h-dvh min-h-0 min-w-0 flex-col gap-4 overflow-hidden bg-white px-4 py-8 font-montserrat text-[#10233A] sm:px-8 sm:py-10 lg:px-[56px]">
      <PageHeader title={uiText("Machine learning")} className="shrink-0 max-sm:[&_h1]:text-[24px]" actions={
        <div ref={helpRef} className="relative shrink-0">
          <button type="button" aria-label={uiText("How it works")} aria-haspopup="dialog" aria-expanded={showHelp}
            aria-controls="learning-help" onClick={() => setShowHelp(value => !value)}
            className="flex h-7 w-7 items-center justify-center rounded-md text-[#007EA7] transition-colors hover:bg-[#E6F2F6] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#007EA7] focus-visible:ring-offset-2">
            <Info size={20} aria-hidden="true" />
          </button>
          {showHelp && <div id="learning-help" role="dialog" aria-label={uiText("Machine learning information")}
            className="absolute right-0 top-9 z-50 max-h-[calc(100dvh-140px)] w-[360px] max-w-[calc(100vw-48px)] overflow-y-auto rounded-lg border border-[#D3E1EC] bg-white p-4 shadow-[0_8px_24px_rgba(16,35,58,0.14)]">
            <p className="font-montserrat text-[13px] font-semibold leading-5 text-[#10233A]">{uiText("Auto-fill requires ")}{LEARNING_MIN_DOCUMENTS}{uiText("+ reviewed documents and ")}{LEARNING_MIN_CONSISTENCY * 100}{uiText("%+ agreement.")}</p>
            <ul className="mt-3 list-disc space-y-2 pl-5 font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3]">
              <li>{uiText("Each row represents one learned field for a company and supplier. Field identifies what was taught; Value the system will use shows the most frequently confirmed value. A dash means no active teaching value is available.")}</li>
              <li>{uiText("Automatic learning covers Expense account and VAT classifier. Below either threshold, the field is left for a person.")}</li>
              <li>{uiText("Edit sets a value and confidence from 0 to 100 for future suggestions. Manual confidence replaces calculated confidence, not the teaching history. Agreement still shows how many reviewed documents contain the selected value. Use learned value restores automatic learning.")}</li>
              <li>{uiText("Competing values and their document counts appear below the row. Expand its arrow to inspect the teaching documents.")}</li>
              <li>{uiText("Pause stops automatic filling. Excluding a teaching source recalculates agreement without deleting the document or its history. Example data never fills real documents.")}</li>
            </ul>
          </div>}
        </div>
      } />
      <OcrBreadcrumb items={['Machine learning']} />

      <div role="group" aria-label={uiText("Learning status filters")} className="flex shrink-0 gap-5 overflow-x-auto border-b border-[#D3E1EC]">
        {LEARNING_STATUS_FILTERS.map(item => <button key={item.value} type="button" aria-pressed={status === item.value} onClick={() => { setStatus(item.value); setPage(1); }} className={`flex h-9 shrink-0 items-center gap-2 border-b-2 text-[12px] font-medium ${status === item.value ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:text-[#007EA7]'}`}>
          {uiText(item.label)}<span className={`rounded px-1.5 py-0.5 text-[11px] tabular-nums ${status === item.value ? 'bg-[#E5EDF9]' : 'bg-[#F2F7FC]'}`}>{item.value ? matchingRows.filter(row => row.status === item.value).length : matchingRows.length}</span>
        </button>)}
      </div>

      <div className="system-table-toolbar flex shrink-0 flex-wrap items-center gap-x-1 gap-y-2">
        <OcrSearchField ariaLabel={uiText("Search learned values")} value={query} onChange={value => { setQuery(value); setPage(1); }} />
        <SystemAddFilters columns={filterColumns} activeKeys={activeFilterKeys} values={filterValues}
          onActiveKeysChange={keys => { setActiveFilterKeys(keys); setPage(1); }} onValuesChange={values => { setFilterValues(values); setPage(1); }}
          onClearFilters={() => { setQuery(''); setStatus(''); setPage(1); }} />
        <div data-table-workspace-tools role="group" aria-label={uiText("Machine learning table tools")} className="ml-auto flex h-7 shrink-0 items-center gap-4">
          <ColumnSettingsButton onClick={() => setShowColumns(true)} /><RefreshAllButton onRefresh={() => setStore(loadLearningStore())} />
        </div>
      </div>
      {notice && <div role="status" className="flex shrink-0 items-center justify-between gap-3 rounded-md bg-[#F2F7FC] px-3 py-2 text-[12px] text-[#7288A3]"><span>{notice}</span><button type="button" aria-label={uiText("Close message")} onClick={() => setNotice('')}><X size={14} /></button></div>}

      <div ref={tableScrollRef} aria-label={uiText("Learned accounting values")} className="min-h-0 flex-1 overflow-auto overscroll-contain scrollbar-hide">
        <div style={{ minWidth }}>
          <div style={{ gridTemplateColumns }} className="system-table-header-row mb-1 grid h-10 items-center border-b border-[#D3E1EC] bg-white text-[12px] font-medium text-[#7288A3]">
            <span aria-hidden="true" />
            {visibleColumns.map((column, index) => <div key={column.key} className={`relative flex min-w-0 items-center gap-1 px-3 ${index ? 'border-l border-[#D3E1EC]' : ''}`}>
              <span className="truncate" title={uiText(column.label)}>{uiText(column.label)}</span>
              <ColumnSortButton columnLabel={uiText(column.label)} direction={directionFor(column.key)} onDirectionChange={direction => { changeSort(column.key, direction); setPage(1); }} />
              <ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} />
            </div>)}
            <div className="system-table-row-actions" aria-hidden="true" />
          </div>
          {sortedRows.slice(0, safePage * TABLE_BATCH_SIZE).map((row, index) => {
            const expanded = expandedHistory.has(row.id);
            const hasCompetingValues = row.candidates.length > 1;
            return <section key={row.id} aria-label={`${row.companyName} · ${row.supplierName} · ${LEARNING_FIELDS[row.field]}`}
              className={hasCompetingValues ? 'mb-1.5 overflow-hidden rounded-md bg-[#F8FDFF] ring-1 ring-inset ring-[#D3E1EC]' : 'mb-0.5'}>
              <div data-record-inactive={row.status === 'Inactive' || undefined} style={{ gridTemplateColumns }} className={`grid min-h-[56px] items-center ${hasCompetingValues ? 'rounded-t-md' : 'rounded-md'} text-[12px] leading-[18px] ${hasCompetingValues || index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}>
                <button type="button" aria-label={`${expanded ? 'Hide' : 'Show'} teaching history for ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} aria-expanded={expanded} aria-controls={expanded ? historyId(row) : undefined} onClick={() => toggleHistory(row)} className="flex h-9 w-9 items-center justify-center text-[#7288A3] hover:text-[#007EA7]">{expanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</button>
                {visibleColumns.map(column => <div key={column.key} className="min-w-0 overflow-hidden px-3 py-1.5">{renderCell(row, column.key)}</div>)}
                <div className="system-table-row-actions flex items-center justify-end gap-2 px-2">
                  <button type="button" disabled={!permissions.edit || !row.total} title={uiText("Edit learned field")} aria-label={`Edit ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onClick={() => setEditRow(row)} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"><Pencil size={14} /></button>
                  <button type="button" disabled={!permissions.edit || !row.total} title={row.control?.paused ? uiText('Resume automatic filling') : uiText('Pause automatic filling')} aria-label={`${row.control?.paused ? 'Resume' : 'Pause'} ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onClick={() => act(row, row.control?.paused ? 'resume' : 'pause')} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40">{row.control?.paused ? <Play size={14} /> : <Pause size={14} />}</button>
                  <RowDeleteButton linked disabled={!permissions.administrator || !permissions.edit || !row.total} label={`Delete latest teaching source for ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onDelete={() => setForgetRow(row)} />
                </div>
              </div>
              {hasCompetingValues && <CompetingLearningValues row={row} />}
              {expanded && <TeachingHistory row={row} onOpenDocument={onOpenDocument} />}
            </section>;
          })}
          {!sortedRows.length && <div className="py-16 text-center text-[13px] text-[#7288A3]">{uiText("No learned values match these filters.")}</div>}
        </div>
      </div>
      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <TablePagination currentPage={safePage} totalPages={Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE))} itemCount={sortedRows.length} onPageChange={setPage} scrollRef={tableScrollRef} />

      {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COLUMNS} onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
      {editRow && <EditLearningRuleDialog row={editRow} onClose={() => setEditRow(null)} onSave={input => {
        saveLearningRule(editRow.id, input);
        setNotice(input ? 'Value and confidence saved for future suggestions. Existing documents are unchanged.' : 'Automatic learned value restored.');
      }} />}
      {forgetRow && <div className="fixed inset-0 z-[250] flex items-center justify-center bg-[#10233A]/30 p-4" onClick={() => setForgetRow(null)}>
        <section role="dialog" aria-modal="true" aria-label={uiText("Exclude teaching source")} className="max-h-[85dvh] w-full max-w-[620px] overflow-auto rounded-xl border border-[#D3E1EC] bg-white p-6 shadow-xl" onClick={event => event.stopPropagation()}>
          <div className="mb-5 flex items-center justify-between gap-4"><h2 className="text-[20px] font-semibold">{uiText("Exclude teaching source")}</h2><button type="button" aria-label={uiText("Close dialog")} onClick={() => setForgetRow(null)}><X size={20} /></button></div>
          <>
            <p className="text-[13px] leading-6 text-[#7288A3]">{uiText("Exclude the latest confirmed document from learning for ")}<strong className="text-[#10233A]">{forgetRow.supplierName} · {LEARNING_FIELDS[forgetRow.field]}</strong>{uiText("? Agreement will be recalculated. The source document and its history will not be deleted.")}</p>
            <div className="mt-6 flex justify-end gap-3"><PageActionButton onClick={() => setForgetRow(null)}>{uiText("Cancel")}</PageActionButton><PageActionButton onClick={() => act(forgetRow, 'forget')}>{uiText("Exclude from learning")}</PageActionButton></div>
          </>
        </section>
      </div>}
    </div>
  );
}
