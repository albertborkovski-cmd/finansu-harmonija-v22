import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeftRight, X } from 'lucide-react';
import { applyDocumentStorno, supabase, type Company } from '../lib/supabase';
import { accountingToday, testDocumentStornoBlocker, testStornoDocumentSnapshot, testStornoOriginalDate, oppositeDocumentAmount, savedDocumentStornoError, savedTestDocumentStornoError, stornoPeriodError, type StornoDocument, type StornoPeriodPolicy } from '../lib/documentStorno';
import { canStornoDocument, canViewStornoDocument, loadStornoPeriodPolicy } from '../lib/documentStornoAccess';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import ScheduleDatePicker from './ScheduleDatePicker';
import { SaveButton } from './ScopedActionButtons';

const buttonClass = 'inline-flex h-8 shrink-0 items-center justify-center gap-2 rounded-md border-2 border-[#D3E1EC] bg-white px-3 font-montserrat text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';

export default function DocumentStornoAction({ documentId, companyId, status, unsavedChanges = false }: { documentId: string; companyId: string; status: string; unsavedChanges?: boolean }) {
  const [open, setOpen] = useState(false);
  const [eligibleDocument, setEligibleDocument] = useState('');
  const eligibilityKey = JSON.stringify([documentId, companyId, status, unsavedChanges]);
  useEffect(() => {
    let cancelled = false;
    let request = 0;
    const refresh = async () => {
      const currentRequest = ++request;
      setEligibleDocument('');
      try {
        const [documents, companies] = await Promise.all([
          supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
          supabase.from('companies').select('*').eq('id', companyId),
        ]);
        if (cancelled || currentRequest !== request) return;
        const document = documents.data?.[0] as StornoDocument | undefined;
        const company = companies.data?.[0] as unknown as Company | undefined;
        if (!documents.error && !companies.error && document && company
          && canViewStornoDocument(company) && !testDocumentStornoBlocker(document, canStornoDocument(company))) setEligibleDocument(eligibilityKey);
      } catch { /* Unverified access or state must not expose the action. */ }
    };
    void refresh();
    const events = ['document-storno-changed', 'storage', SETTINGS_DATA_CHANGED_EVENT];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => { cancelled = true; events.forEach(event => window.removeEventListener(event, refresh)); };
  }, [documentId, companyId, eligibilityKey]);
  return <>
    {eligibleDocument === eligibilityKey && !unsavedChanges && <span title={uiText("Reverse document · Test only, no GL changes")}>
      <button type="button" className={buttonClass} onClick={() => setOpen(true)}><ArrowLeftRight size={14} />{uiText("Storno")}</button>
    </span>}
    {open && <DocumentStornoDialog documentId={documentId} companyId={companyId} onClose={() => setOpen(false)} />}
  </>;
}

export function DocumentStornoDialog({ documentId, companyId, onClose }: { documentId: string; companyId: string; onClose: () => void }) {
  const titleId = useId();
  const root = useRef<HTMLDivElement>(null);
  const saving = useRef(false);
  const [document, setDocument] = useState<StornoDocument | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [allowed, setAllowed] = useState(false);
  const [policy, setPolicy] = useState<StornoPeriodPolicy | null>(null);
  const [date, setDate] = useState(accountingToday);
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const load = useCallback(async () => {
    const [documents, companies] = await Promise.all([
      supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
      supabase.from('companies').select('*').eq('id', companyId),
    ]);
    if (documents.error || companies.error || !documents.data?.[0] || !companies.data?.[0]) throw new Error('The document or its company is unavailable. Refresh before continuing.');
    const currentCompany = companies.data[0] as unknown as Company;
    if (!canViewStornoDocument(currentCompany)) throw new Error('You no longer have access to this company’s documents.');
    return { company: currentCompany, document: documents.data[0] as StornoDocument, allowed: canStornoDocument(currentCompany), policy: loadStornoPeriodPolicy(companyId) };
  }, [documentId, companyId]);
  useEffect(() => {
    let current = true;
    void load().then(value => {
      if (!current) return;
      setCompany(value.company); setDocument(value.document); setAllowed(value.allowed); setPolicy(value.policy);
    }).catch(value => { if (current) setError(value instanceof Error ? value.message : 'The operation could not be loaded.'); });
    return () => { current = false; };
  }, [load]);
  useEffect(() => {
    const previous = window.document.activeElement as HTMLElement | null;
    root.current?.focus();
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, []);
  const integrityError = document ? savedTestDocumentStornoError(document) || savedDocumentStornoError(document) : '';
  const reversal = integrityError ? undefined : document?.document_storno || document?.accounting_storno;
  const amount = document && !integrityError ? oppositeDocumentAmount(document.total_amount) : null;
  const blocker = integrityError || (document ? testDocumentStornoBlocker(document, allowed) : '');
  const periodError = document && policy ? stornoPeriodError(date, testStornoOriginalDate(document), accountingToday(), policy) : '';
  const perform = async () => {
    if (!document || saving.current) return;
    saving.current = true; setBusy(true); setError('');
    try {
      const next = await applyDocumentStorno(documentId, companyId, { expectedDocument: testStornoDocumentSnapshot(document), date, reason });
      setDocument(next as unknown as StornoDocument); setSaved(true);
    } catch (value) { setError(value instanceof Error ? value.message : 'Storno could not be saved.'); }
    finally { saving.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5100] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[92vh] w-full max-w-[760px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none" onKeyDown={event => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        const calendar = root.current?.querySelector<HTMLButtonElement>('button[aria-haspopup="dialog"][aria-expanded="true"]');
        const combobox = root.current?.querySelector('[role="combobox"][aria-expanded="true"]');
        if (combobox) return;
        if (calendar) { calendar.click(); calendar.focus(); return; }
        if (!busy) onClose();
      }
      if (event.key === 'Tab') {
        const nodes = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')].filter(node => node.getClientRects().length);
        if (event.shiftKey && (window.document.activeElement === nodes[0] || window.document.activeElement === root.current)) { event.preventDefault(); nodes.at(-1)?.focus(); }
        else if (!event.shiftKey && (window.document.activeElement === nodes.at(-1) || window.document.activeElement === root.current)) { event.preventDefault(); nodes[0]?.focus(); }
      }
    }}>
      <header className="flex items-start justify-between gap-3 border-b border-[#D3E1EC] px-6 py-4"><div><h2 id={titleId} className="text-[18px] font-semibold">{reversal ? uiText('Storno · Reversed document') : uiText('Storno · Reverse document')}</h2><p className="mt-1 text-[#7288A3]">{company?.name} · {String(document?.number || documentId)}</p></div><button className={`${buttonClass} !w-8 !px-0`} aria-label={uiText("Close Storno")} disabled={busy} onClick={onClose}><X size={16} /></button></header>
      <div className="space-y-4 overflow-y-auto p-6">
        {error && <p role="alert" className="rounded-lg border border-[#F4C7C7] bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {!document && !error && <p role="status">{uiText("Loading document…")}</p>}
        {document && <>
          {(!reversal || document.document_storno) && <p role="status" className="rounded-lg bg-[#E6F2F6] p-3 text-[#007EA7]">{saved ? uiText('Test Storno saved. The document is shown as Reversed. ') : uiText('Test Storno only. ')}{uiText("No GL entries are created or changed. Nothing is sent to an accounting system.")}</p>}
          {!reversal && blocker && <p role="status" className="rounded-lg border border-[#EEB648] bg-[#FFF4DC] p-3 text-[#926317]">{blocker}</p>}
          <dl className="grid grid-cols-2 gap-4 rounded-lg border border-[#D3E1EC] p-4"><div><dt className="text-[#7288A3]">{uiText("Document")}</dt><dd className="mt-1 font-semibold">{String(document.number || documentId)}</dd></div><div><dt className="text-[#7288A3]">{uiText("Document date")}</dt><dd className="mt-1">{String(document.document_date || '—')}</dd></div></dl>
          {amount && <dl aria-label={uiText("Storno amounts")} className="grid grid-cols-2 gap-4 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-4"><div><dt className="text-[#7288A3]">{uiText("Original amount")}</dt><dd className="mt-1 tabular-nums">{amount.original} {String(document.currency || '')}</dd></div><div><dt className="text-[#7288A3]">{reversal ? uiText('Storno amount') : uiText('Storno amount · Preview')}</dt><dd className="mt-1 font-semibold tabular-nums text-[#007EA7]">{amount.reversed} {String(document.currency || '')}</dd></div></dl>}
          {!reversal && <fieldset disabled={busy || Boolean(blocker)} className="grid gap-4 sm:grid-cols-[220px_minmax(0,1fr)]"><div><label className="mb-2 block font-medium">{uiText("Reversal date *")}</label><ScheduleDatePicker value={date} onChange={setDate} ariaLabel={uiText("Reversal date")} placeholder={uiText("YYYY-MM-DD")} />{periodError && <p className="mt-2 text-[#B42318]">{periodError}</p>}</div><div><label htmlFor={`${titleId}-reason`} className="mb-2 block font-medium">{uiText("Reason *")}</label><textarea id={`${titleId}-reason`} value={reason} onChange={event => setReason(event.target.value)} maxLength={2000} rows={3} className="w-full rounded-lg border border-[#D3E1EC] p-3 outline-none focus:border-[#007EA7]" /></div></fieldset>}
          {reversal && <section className="space-y-3 rounded-lg border border-[#D3E1EC] p-4"><div className="flex flex-wrap gap-x-6 gap-y-1"><strong>{reversal.number}</strong><span>{reversal.date}</span><span className="rounded bg-[#E6F2F6] px-2 text-[#007EA7]">{document.document_storno ? uiText('Reversed · Test') : uiText('Previously posted reversal')}</span></div><p className="whitespace-pre-wrap break-words">{reversal.reason}</p><h3 className="font-semibold">{uiText("Action history")}</h3>{reversal.history.map(event => <div key={event.id} className="border-t border-[#E5EDF9] pt-2"><p>{event.action} · {event.actor} · {new Date(event.at).toLocaleString()}</p><p className="mt-1 break-words text-[#7288A3]">{event.details}</p></div>)}</section>}
        </>}
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#D3E1EC] px-6 py-3"><button className={buttonClass} disabled={busy} onClick={onClose}>{uiText("Close")}</button>{!reversal && <SaveButton className="!h-8 !text-[12px]" disabled={!document || !policy || busy || Boolean(blocker) || Boolean(periodError) || !reason.trim()} onClick={() => void perform()}>{busy ? uiText('Saving…') : uiText('Confirm Storno')}</SaveButton>}</footer>
    </div>
  </div>, window.document.body);
}
