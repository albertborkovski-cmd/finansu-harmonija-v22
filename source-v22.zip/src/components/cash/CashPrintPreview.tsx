import { translateUi as uiText } from '../../i18n/language';
import { Printer } from 'lucide-react';
import type { CashPrintReport } from '../../lib/cashPrint';
import GlJournalDialog from '../GlJournalDialog';
import { PageActionButton } from '../PageHeader';
import { CancelButton } from '../ScopedActionButtons';

export default function CashPrintPreview({ report, onClose }: { report: CashPrintReport; onClose: () => void }) {
  return <GlJournalDialog wide printable title={report.title} subtitle={report.company} onClose={onClose} footer={<>
    <CancelButton onClick={onClose}>{uiText("Close preview")}</CancelButton>
    <PageActionButton icon={<Printer size={15} />} onClick={() => window.print()}>{uiText("Print / Save as PDF")}</PageActionButton>
  </>}>
    <dl className="mb-5 grid gap-x-6 gap-y-2 text-[12px] sm:grid-cols-[150px_1fr]">{report.details.map(([label, value]) => <div key={label} className="contents"><dt className="text-[#7288A3]">{uiText(label)}</dt><dd className="min-w-0 break-words">{value}</dd></div>)}</dl>
    <table aria-label={`Printable ${report.title}`} className="gl-journal-print-table w-full table-fixed border-collapse text-[12px]">
      <thead><tr>{report.columns.map(label => <th key={label} className="border-b border-[#D3E1EC] bg-[#F3F7FB] p-3 text-left font-medium text-[#7288A3]">{uiText(label)}</th>)}</tr></thead>
      <tbody>{report.rows.map((row, index) => <tr key={index}>{row.map((value, column) => <td key={column} className="break-words border-b border-[#E5EDF9] p-3 align-top tabular-nums">{value}</td>)}</tr>)}</tbody>
    </table>
    <p className="mt-5 whitespace-pre-line text-[12px] leading-7">{report.footer}</p>
  </GlJournalDialog>;
}
