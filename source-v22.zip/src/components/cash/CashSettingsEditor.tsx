import { translateUi as uiText } from '../../i18n/language';
import { useState } from 'react';
import { CASH_KINDS, cashMasterLinked, type CashAccount, type CashMaster, type CashMasterCollection, type CashPerson, type CashSeries, type CashStore } from '../../lib/cash';
import GlJournalDialog from '../GlJournalDialog';
import SearchableSelect, { type SearchableSelectOption } from '../SearchableSelect';
import { CancelButton, SaveButton } from '../ScopedActionButtons';
import { CashField, cashInput } from './CashControls';

export default function CashSettingsEditor({ collection, initial, store, glAccounts, users, currencies, onSave, onClose }: {
  collection: CashMasterCollection; initial: CashMaster; store: CashStore;
  glAccounts: SearchableSelectOption[]; users: SearchableSelectOption[]; currencies: string[];
  onSave: (record: CashMaster) => void; onClose: () => void;
}) {
  const [draft, setDraft] = useState(() => structuredClone(initial));
  const [error, setError] = useState('');
  const used = cashMasterLinked(store, collection, initial.id);
  const name = collection === 'accounts' ? 'cash account' : collection === 'people' ? 'responsible person' : 'document series';
  const set = (key: string, value: string | number) => setDraft(current => ({ ...current, [key]: value }));
  const save = () => { try { onSave(draft); } catch (cause) { setError((cause as Error).message); } };
  const select = (label: string, value: string, key: string, options: SearchableSelectOption[] | string[], disabled = false) => <CashField label={`${label} *`}><SearchableSelect portalMenu className={cashInput} ariaLabel={uiText(label)} value={value} options={options} disabled={disabled} onChange={value => set(key, value)} /></CashField>;
  const text = (label: string, value: string, key: string, disabled = false) => <CashField label={`${label} *`}><input aria-label={uiText(label)} className={cashInput} value={value} disabled={disabled} onChange={event => set(key, event.target.value)} /></CashField>;
  const account = draft as CashAccount, person = draft as CashPerson, series = draft as CashSeries;
  return <GlJournalDialog title={`${initial.revision ? 'Edit' : 'New'} ${name}`} onClose={onClose} footer={<><CancelButton onClick={onClose}>{uiText("Cancel")}</CancelButton><SaveButton onClick={save}>{uiText("Save")}</SaveButton></>}>
    {error && <p role="alert" className="mb-4 rounded-lg bg-red-50 p-3 text-[12px] text-red-700">{error}</p>}
    <div className="grid grid-cols-2 gap-4">
      {collection === 'accounts' && <>{text('Code', account.code, 'code')}{text('Cash account name', account.name, 'name')}<div className="col-span-2">{select('GL account', account.glAccount, 'glAccount', glAccounts, used)}</div>{select('Currency', account.currency, 'currency', currencies, used)}{used && <p className="col-span-2 text-[11px] leading-5 text-[#7288A3]">{uiText("This account has linked records. Its GL account and currency are retained to preserve accounting history.")}</p>}</>}
      {collection === 'series' && <>{text('Prefix', series.prefix, 'prefix', used)}{select('Operation type', series.kind, 'kind', CASH_KINDS, used)}<CashField label={uiText("Next number *")}><input aria-label={uiText("Next number")} type="number" min="1" step="1" className={cashInput} value={series.nextNumber} onChange={event => set('nextNumber', Number(event.target.value))} /></CashField><CashField label={uiText("Number length *")}><input aria-label={uiText("Number length")} type="number" min="1" max="10" step="1" className={cashInput} value={series.digits} onChange={event => set('digits', Number(event.target.value))} /></CashField><p className="col-span-2 rounded-lg bg-[#F3F7FB] px-3 py-3 text-[13px] text-[#007EA7]">{uiText("Preview: ")}{series.prefix || uiText('KPO')}-{String(series.nextNumber || 1).padStart(Math.min(10, Math.max(1, series.digits || 1)), '0')}</p></>}
      {collection === 'people' && <><div className="col-span-2">{select('Cash account', person.accountId, 'accountId', store.accounts.filter(row => !row.inactive).map(row => ({ value: row.id, label: `${row.code} · ${row.name}` })))}</div><div className="col-span-2"><CashField label={uiText("Internal user *")}><SearchableSelect portalMenu ariaLabel={uiText("Responsible internal user")} className={cashInput} value={person.userId} options={users} onChange={value => setDraft(current => ({ ...current, userId: value, name: users.find(row => row.value === value)?.label || '' }))} /></CashField></div>{select('Responsibility', person.role, 'role', ['Cashier', 'Accountant'])}<span />{(['validFrom', 'validTo'] as const).map(key => <CashField key={key} label={key === 'validFrom' ? uiText('Valid from *') : uiText('Valid to')}><input aria-label={key === 'validFrom' ? uiText('Responsibility valid from') : uiText('Responsibility valid to')} type="date" className={cashInput} value={person[key]} onChange={event => set(key, event.target.value)} /></CashField>)}</>}
    </div>
  </GlJournalDialog>;
}
