import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { RefreshCw, X } from 'lucide-react';
import type { Company, DbDocument } from '../lib/supabase';
import { bankMatchingDefaults, readBankMatchingDemo, saveBankMatchingDemo, type BankMatchingDemo } from '../lib/bankMatchingDemo';
import { bankTransactionFromDocument } from '../lib/bankTransaction';
import SearchableSelect from './SearchableSelect';
import { CancelButton, SaveButton } from './ScopedActionButtons';

const inputClass = 'w-full rounded-md border border-[#D3E1EC] bg-white px-3 py-2 text-[12px] text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9]';
type Props = { record: DbDocument; company: Company; parties: Company[]; onClose: () => void; onSaved: (value: BankMatchingDemo) => void };

export default function BankMatchingDataDialog({ record, company, parties, onClose, onSaved }: Props) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null), purpose = useRef<HTMLTextAreaElement>(null), pending = useRef(false);
  const escapeFromDropdown = useRef(false);
  const [previous] = useState(() => readBankMatchingDemo(company.id, record.id));
  const [draft, setDraft] = useState(() => previous?.input || bankMatchingDefaults(record, company));
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const original = bankTransactionFromDocument(record, company);
  const options = parties.map(party => ({ value: party.id, label: party.name, description: party.company_code }));
  if (!options.some(option => option.value === original.counterpartyId)) options.unshift({ value: original.counterpartyId, label: original.counterpartyName || '—', description: 'Original counterparty' });
  if (draft.counterpartyId && !options.some(option => option.value === draft.counterpartyId)) options.push({ value: draft.counterpartyId, label: previous?.counterpartyName || draft.counterpartyId, description: 'No longer available — select another counterparty' });
  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null;
    // Capture before the shared dropdown's document listener closes its menu.
    const rememberDropdown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') escapeFromDropdown.current = Boolean(root.current?.querySelector('[role="combobox"][aria-expanded="true"]'));
    };
    window.addEventListener('keydown', rememberDropdown, true);
    purpose.current?.focus();
    return () => { window.removeEventListener('keydown', rememberDropdown, true); previousFocus?.focus(); };
  }, []);
  const close = () => { if (!pending.current) onClose(); };
  async function save(event: React.FormEvent) {
    event.preventDefault(); event.stopPropagation();
    if (pending.current) return;
    pending.current = true; setBusy(true); setError('');
    try { onSaved(await saveBankMatchingDemo(record, company, draft, previous?.revision || 0)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not save matching data.'); }
    finally { pending.current = false; setBusy(false); }
  }
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onClick={event => { event.stopPropagation(); if (event.target === event.currentTarget) close(); }} onKeyDown={event => {
    event.stopPropagation();
    if (event.key === 'Escape') { if (escapeFromDropdown.current) { purpose.current?.focus(); return; } event.preventDefault(); close(); }
    if (event.key === 'Tab' && !document.querySelector('[role="listbox"]')) {
      const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')].filter(node => node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }}>
    <div ref={root} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[640px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-5 py-4"><h2 id={titleId} className="text-[18px] font-semibold text-[#10233A]">{uiText("Edit matching data")}</h2><button type="button" aria-label={uiText("Close matching data")} disabled={busy} onClick={close} className="rounded-md p-1 text-[#7288A3] hover:bg-[#F2F5F9] hover:text-[#007EA7] disabled:opacity-50"><X size={19} /></button></header>
      <form onSubmit={event => void save(event)} className="flex min-h-0 flex-col">
        <div className="space-y-4 overflow-y-auto p-5">
          <label className="block space-y-1.5 text-[11px] font-medium text-[#7288A3]"><span>{uiText("Original payment purpose")}</span><textarea aria-label={uiText("Original payment purpose")} readOnly value={original.paymentPurpose || '—'} rows={2} className={`${inputClass} resize-none !bg-[#F2F5F9]`} /></label>
          <label className="block space-y-1.5 text-[11px] font-medium text-[#7288A3]"><span>{uiText("Matching purpose")}</span><textarea ref={purpose} aria-label={uiText("Matching purpose")} disabled={busy} value={draft.matchingPurpose} maxLength={5000} rows={3} onChange={event => setDraft(value => ({ ...value, matchingPurpose: event.target.value }))} className={`${inputClass} resize-y`} /></label>
          <div className="grid gap-4 sm:grid-cols-2"><label className="block space-y-1.5 text-[11px] font-medium text-[#7288A3]"><span>{uiText("Document No.")}</span><input aria-label={uiText("Matching Document No.")} disabled={busy} value={draft.documentNo} maxLength={200} onChange={event => setDraft(value => ({ ...value, documentNo: event.target.value }))} className={`${inputClass} h-9`} /></label>
            <div className="space-y-1.5 text-[11px] font-medium text-[#7288A3]"><span>{uiText("Counterparty")}</span><SearchableSelect ariaLabel={uiText("Matching Counterparty")} value={draft.counterpartyId} options={options} disabled={busy} onChange={counterpartyId => setDraft(value => ({ ...value, counterpartyId }))} className={`${inputClass} h-9 !pr-8`} portalMenu menuClassName="!z-[5500]" /></div></div>
          <p className="text-[11px] leading-5 text-[#7288A3]">{uiText("Frontend demo. Saving updates the suggestion preview only. Original bank data and confirmed reconciliations stay unchanged.")}</p>
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        </div>
        <footer className="flex flex-wrap justify-end gap-3 border-t border-[#D3E1EC] px-5 py-4"><CancelButton onClick={close} className="!h-9 !text-[12px]" /><SaveButton type="submit" disabled={busy} className="!h-9 !gap-2 !text-[12px]"><RefreshCw size={14} className={busy ? 'animate-spin' : ''} />{busy ? uiText('Saving…') : uiText('Save & rerun matching')}</SaveButton></footer>
      </form>
    </div>
  </div>, document.body);
}
