export { default } from './MachineLearningView';
