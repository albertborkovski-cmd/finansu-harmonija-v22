import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, Loader2, Send, X } from 'lucide-react';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { documentDeliveryDestinations, savedDocumentDeliveryDestination } from '../lib/documentExport';
import { documentAccountingExportProfile } from '../lib/documentAccountingExport';
import { documentTestDeliveryBlocker, documentTestDeliverySnapshot, type TestDeliveryCommand } from '../lib/documentTestDelivery';
import type { Document } from './Documents';
import type { Company, DbDocument } from '../lib/supabase';

export default function DocumentDeliveryDialog({ mode, ids, loadRecords, onExport, onTestTransfer, onSaveDestination, onClose }: {
  mode: 'transfer' | 'export'; ids: string[];
  loadRecords: () => Promise<{ documents: Document[]; companies: Company[] }>;
  onExport: (destinationId: string) => Promise<void>; onClose: () => void;
  onTestTransfer: (command: TestDeliveryCommand) => Promise<Document[]>;
  onSaveDestination: (companyId: string, destinationId: string) => Promise<Company>;
}) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null);
  const [records, setRecords] = useState<Document[]>([]), [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [destination, setDestination] = useState('');
  const [complete, setComplete] = useState(false);
  const [savingDestination, setSavingDestination] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [completedRequest, setCompletedRequest] = useState('');
  const pending = useRef(false), testCommand = useRef<TestDeliveryCommand | null>(null);
  const load = useRef(loadRecords);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    let current = true;
    root.current?.focus();
    load.current().then(result => {
      if (!current) return;
      setRecords(result.documents); setCompanies(result.companies);
      const selectedCompanyIds = new Set(result.documents.map(record => record.companyId));
      const selectedCompany = selectedCompanyIds.size === 1 ? result.companies.find(item => selectedCompanyIds.has(item.id)) : undefined;
      setDestination(savedDocumentDeliveryDestination(selectedCompany)?.value ?? '');
    }).catch(cause => { if (current) { setLoadError(true); setError(cause instanceof Error ? cause.message : 'Unable to load selected documents.'); } }).finally(() => { if (current) setLoading(false); });
    return () => { current = false; previous?.focus(); };
  }, []);
  const companyIds = new Set(records.map(record => record.companyId));
  const company = companies.find(item => companyIds.has(item.id));
  const destinations = companyIds.size === 1 ? documentDeliveryDestinations(company?.counterparties_settings) : [];
  const destinationName = destinations.find(item => item.value === destination)?.label;
  const exportProfile = documentAccountingExportProfile(destination);
  const changeDestination = async (value: string) => {
    if (pending.current || loading || loadError || !company || companyIds.size !== 1 || value === destination) return;
    // Download choices must not overwrite the company's direct-transfer setting.
    if (mode === 'export') { setDestination(value); setComplete(false); setError(''); return; }
    const previous = destination;
    pending.current = true; setBusy(true); setSavingDestination(true); setError(''); setComplete(false); setDestination(value);
    try {
      const saved = await onSaveDestination(company.id, value);
      setCompanies(current => current.map(item => item.id === saved.id ? saved : item));
      setDestination(savedDocumentDeliveryDestination(saved)?.value ?? '');
      testCommand.current = null;
    } catch (cause) {
      setDestination(previous); setError(cause instanceof Error ? cause.message : 'The destination could not be saved. Please select it again.');
    } finally { pending.current = false; setBusy(false); setSavingDestination(false); }
  };
  const results = records.flatMap(record => record.testDeliveries?.filter(receipt => receipt.requestId === completedRequest) ?? []);
  const sendTest = async () => {
    if (pending.current || loading || loadError || companyIds.size !== 1 || !company || !destination) return;
    pending.current = true; setBusy(true); setError(''); setComplete(false);
    const snapshots = Object.fromEntries(records.map(record => [record.id, documentTestDeliverySnapshot(record.inlineSource)]));
    if (!testCommand.current || testCommand.current.destinationId !== destination
      || JSON.stringify(testCommand.current.snapshots) !== JSON.stringify(snapshots)) {
      testCommand.current = { requestId: crypto.randomUUID(), companyId: company.id, ids: [...ids], destinationId: destination, scenario: 'accepted', snapshots };
    }
    try {
      const saved = await onTestTransfer(testCommand.current);
      setRecords(saved); setCompletedRequest(testCommand.current.requestId); setComplete(true); testCommand.current = null;
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'The test transfer could not be saved.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const exportFile = async () => {
    if (pending.current || loading || loadError || companyIds.size !== 1 || !destinationName || !records.length) return;
    pending.current = true; setBusy(true); setError(''); setComplete(false);
    try { await onExport(destination); setComplete(true); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'The export file could not be created.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5000] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[760px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none"
      onKeyDown={event => {
        if (event.key === 'Escape' && !busy) {
          event.stopPropagation();
          if ((event.target as HTMLElement).closest('[role="combobox"]') || root.current?.querySelector('[role="combobox"][aria-expanded="true"]')) root.current?.focus();
          else onClose();
        }
        if (event.key === 'Tab') {
          const nodes = [...(root.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]') ?? [])].filter(node => node.getClientRects().length);
          const first = nodes[0], last = nodes.at(-1);
          if (event.shiftKey && (document.activeElement === first || document.activeElement === root.current)) { event.preventDefault(); last?.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        }
      }}>
      <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-6 py-4"><div className="flex flex-wrap items-center gap-3"><h2 id={titleId} className="text-[18px] font-semibold">{mode === 'transfer' ? uiText('Send to accounting') : uiText('Export documents')}</h2>{mode === 'transfer' && <span className="rounded-md bg-[#F2F5F9] px-2 py-1 text-[10px] font-medium text-[#7288A3]" title={uiText("Test only. No documents are sent to an external accounting system.")}>{uiText("Test · API not connected")}</span>}</div><PageActionButton iconOnly className="!px-0" ariaLabel={uiText("Close document delivery")} disabled={busy} onClick={onClose} icon={<X size={16} className="shrink-0" />}>{uiText("Close")}</PageActionButton></header>
      <div className="space-y-5 overflow-y-auto px-6 py-5">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-[#F2F5F9] px-4 py-3"><span className="font-medium">{ids.length}{uiText(" selected ")}{ids.length === 1 ? uiText('document') : uiText('documents')}</span><span className="text-[#7288A3]">{loading ? uiText('Loading…') : companyIds.size === 1 ? company?.name : `${companyIds.size} companies`}</span></div>
        {loading && <p role="status" className="flex items-center gap-2 text-[#7288A3]"><Loader2 size={15} className="animate-spin" />{uiText("Loading selected documents…")}</p>}
        {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {complete && <p role="status" className="rounded-lg bg-[#E5EDF9] p-3 text-[#007EA7]">{mode === 'export' ? `${destinationName} test file prepared. Document statuses have not changed.` : `Test completed · ${results.filter(result => result.outcome === 'Accepted').length} accepted · ${results.filter(result => result.outcome === 'Rejected').length} rejected · ${results.filter(result => result.outcome === 'Blocked').length} blocked. Results saved in document history.`}</p>}
        <label className="block space-y-2"><span className="font-semibold">{uiText("Destination system ")}<span className="text-red-500">*</span></span><SearchableSelect portalMenu menuClassName="!z-[5100]" ariaLabel={uiText("Destination system")} value={destination} onChange={value => void changeDestination(value)} options={destinations} disabled={loading || loadError || busy || companyIds.size !== 1} placeholder={uiText("Select accounting system")} /></label>
        {companyIds.size > 1 && <p role="alert" className="text-[#B42318]">{uiText("Select documents from one company for each ")}{mode === 'export' ? uiText('export') : uiText('transfer')}.</p>}
        {!loading && !loadError && companyIds.size === 1 && !destinations.length && <p role="alert" className="text-[#926317]">{uiText("No active accounting systems configured for this company.")}</p>}
        {mode === 'transfer' ? <>
          <div className="max-h-64 overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full table-fixed text-left"><thead className="sticky top-0 bg-[#F2F5F9]"><tr><th className="w-[25%] px-3 py-2 font-medium">{uiText("Document No.")}</th><th className="w-[20%] px-3 py-2 font-medium">{uiText("Document status")}</th><th className="px-3 py-2 font-medium">{uiText("Validation / last test")}</th></tr></thead><tbody>{records.map(record => {
            const reason = documentTestDeliveryBlocker(record.inlineSource as unknown as DbDocument);
            const receipt = record.testDeliveries?.at(-1);
            const stale = receipt && receipt.sourceSnapshot !== documentTestDeliverySnapshot(record.inlineSource);
            return <tr key={record.id} className="border-t border-[#E5EDF9] align-top"><td className="break-words px-3 py-3">{record.number || record.fileCase}</td><td className="px-3 py-3">{statusText(record.status)}</td><td className="space-y-1 px-3 py-3">
              {reason && <p className="text-[#926317]">{reason}</p>}
              {!reason && !receipt && <span className="text-[#007EA7]">{uiText("Ready for test")}</span>}
              {receipt && <><p className={`font-medium ${receipt.outcome === 'Accepted' ? 'text-[#007EA7]' : 'text-[#926317]'}`}>{uiText("Test ")}{receipt.outcome.toLowerCase()}{stale ? uiText(' · Document changed since test') : ''}</p><p>{receipt.message}</p><p className="text-[11px] text-[#7288A3]">{receipt.destinationName} · {receipt.reference}<br />{new Date(receipt.at).toLocaleString()} · {receipt.actor}</p></>}
            </td></tr>;
          })}</tbody></table></div>
        </> : <>
          {destinationName && <div className="flex items-center justify-between gap-3 rounded-lg border border-[#D3E1EC] px-4 py-3"><span className="font-medium">{destinationName}</span><span className="rounded bg-[#E5EDF9] px-2 py-1 text-[11px] font-medium text-[#007EA7]">{exportProfile.label}{uiText(" · Test export")}</span></div>}
          <div className="max-h-64 overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full table-fixed text-left"><thead className="sticky top-0 bg-[#F2F5F9]"><tr><th className="w-[30%] px-3 py-2 font-medium">{uiText("Document No.")}</th><th className="px-3 py-2 font-medium">{uiText("Document type")}</th><th className="w-[20%] px-3 py-2 font-medium">{uiText("Currency")}</th></tr></thead><tbody>{records.map(record => <tr key={record.id} className="border-t border-[#E5EDF9]"><td className="break-words px-3 py-3">{record.number || record.fileCase}</td><td className="break-words px-3 py-3">{record.documentType || '—'}</td><td className="px-3 py-3">{record.currency || '—'}</td></tr>)}</tbody></table></div>
          <p className="text-[11px] leading-relaxed text-[#7288A3]">{uiText("Selected documents and their accounting allocations are included, regardless of visible columns. Test file only; production import mapping is not yet configured. Nothing is sent to an accounting system.")}</p>
        </>}
      </div>
      <footer className="flex justify-end gap-2 border-t border-[#D3E1EC] px-6 py-4"><PageActionButton disabled={busy} onClick={onClose}>{uiText("Close")}</PageActionButton>{mode === 'export' ? <PageActionButton disabled={loading || busy || loadError || !records.length || companyIds.size !== 1 || !destinationName} onClick={() => void exportFile()} icon={busy ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} />}>{busy ? uiText('Preparing…') : `Export${destinationName ? ` for ${destinationName}` : ' documents'}`}</PageActionButton> : <PageActionButton disabled={loading || busy || loadError || !records.length || companyIds.size !== 1 || !destinations.some(item => item.value === destination)} onClick={() => void sendTest()} icon={busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}>{savingDestination ? uiText('Saving…') : busy ? uiText('Testing…') : `Send to ${destinationName || 'accounting'}`}</PageActionButton>}</footer>
    </div>
  </div>, document.body);
}
