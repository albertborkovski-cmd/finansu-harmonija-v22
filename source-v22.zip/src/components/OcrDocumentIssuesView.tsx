import { translateUi as uiText } from '../i18n/language';
import DocumentIssueQueue from './DocumentIssueQueue';
import OcrBreadcrumb from './OcrBreadcrumb';
import { PageHeader } from './PageHeader';

export default function OcrDocumentIssuesView() {
  return (
    <div className="flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title={uiText("Document issues")} />
      <OcrBreadcrumb items={['Workspace', 'Document issues']} />
      <DocumentIssueQueue />
    </div>
  );
}
