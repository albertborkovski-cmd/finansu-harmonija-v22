import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState, type FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { CancelButton, SaveButton } from './ScopedActionButtons';

export default function SendToTeamLeadDialog({ documentName, onClose, onSend }: {
  documentName: string; onClose: () => void; onSend: (comment: string) => Promise<void>;
}) {
  const titleId = useId(), commentId = useId(), helpId = useId();
  const root = useRef<HTMLDivElement>(null), textarea = useRef<HTMLTextAreaElement>(null), pending = useRef(false);
  const [comment, setComment] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    textarea.current?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  const close = () => { if (!pending.current) onClose(); };
  const submit = async (event: FormEvent) => {
    event.preventDefault(); event.stopPropagation();
    if (pending.current) return;
    if (!comment.trim()) { setError('Describe what the team lead should check.'); textarea.current?.focus(); return; }
    pending.current = true; setBusy(true); setError('');
    try { await onSend(comment); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not send the document. Please try again.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onMouseDown={event => {
    event.stopPropagation(); if (event.target === event.currentTarget) close();
  }} onKeyDown={event => {
    event.stopPropagation();
    if (event.key === 'Escape') { event.preventDefault(); close(); }
    if (event.key === 'Tab') {
      const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), textarea:not(:disabled)')].filter(node => node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }}>
    <div ref={root} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[620px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-start justify-between gap-4 border-b border-[#D3E1EC] px-6 py-4">
        <div className="min-w-0"><h2 id={titleId} className="text-[18px] font-semibold text-[#10233A]">{uiText("Send to team lead")}</h2><p className="mt-1 truncate text-[12px] text-[#7288A3]" title={documentName}>{documentName}</p></div>
        <button type="button" aria-label={uiText("Close team lead request")} disabled={busy} onClick={close} className="rounded-md p-1 text-[#7288A3] hover:bg-[#F2F5F9] hover:text-[#007EA7] disabled:opacity-50"><X size={19} /></button>
      </header>
      <form onSubmit={event => void submit(event)} className="flex min-h-0 flex-col">
        <div className="space-y-3 overflow-y-auto px-6 py-5">
          <label htmlFor={commentId} className="block text-[12px] font-medium text-[#7288A3]">{uiText("Worker comment ")}<span className="text-[#D92D20]">*</span></label>
          <textarea id={commentId} ref={textarea} required aria-describedby={helpId} disabled={busy} rows={5} maxLength={5000} value={comment} onChange={event => { setComment(event.target.value); setError(''); }} placeholder={uiText("Describe what is wrong and what needs to be checked…")} className="w-full resize-y rounded-lg border border-[#D3E1EC] bg-white px-3 py-2.5 text-[13px] leading-5 text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10" />
          <p id={helpId} className="text-[12px] leading-5 text-[#7288A3]">{uiText("The team lead will see this comment in the review list and at the top of the document.")}</p>
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        </div>
        <footer className="flex justify-end gap-3 border-t border-[#D3E1EC] px-6 py-4"><CancelButton onClick={close} /><SaveButton type="submit" disabled={busy || !comment.trim()}>{busy ? uiText('Sending…') : uiText('Send to team lead')}</SaveButton></footer>
      </form>
    </div>
  </div>, document.body);
}
