import { translateUi as uiText } from '../i18n/language';
import { useRef, useState } from 'react';
import SearchableSelect, { type SearchableSelectOption } from './SearchableSelect';

/** A document-level list edit: keep the stored value until the guarded save succeeds. */
export default function DocumentInlineSelectCell({ value, label, options, storedLabel, disabledReason, onSave, localizeOptions = false }: {
  value: string;
  label: string;
  options: string[] | SearchableSelectOption[];
  storedLabel?: string;
  disabledReason: string;
  onSave: (value: string) => Promise<void>;
  localizeOptions?: boolean | 'status';
}) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const busy = useRef(false);
  const save = async (nextValue: string) => {
    if (busy.current || disabledReason || nextValue === value) return;
    busy.current = true;
    setSaving(true);
    setError('');
    try { await onSave(nextValue); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { busy.current = false; setSaving(false); }
  };
  const available = options.map(option => typeof option === 'string' ? { value: option, label: option } : option);
  const currentOptions = value && !available.some(option => option.value === value)
    ? [{ value, label: storedLabel || value, disabled: true }, ...available]
    : available;

  return <div className="min-w-0" title={disabledReason || `Edit ${label}`} onClick={event => event.stopPropagation()}>
    <SearchableSelect
      value={value}
      options={currentOptions}
      localizeOptions={localizeOptions}
      ariaLabel={`Edit ${label}`}
      placeholder={uiText("—")}
      disabled={saving || Boolean(disabledReason)}
      onChange={nextValue => { void save(nextValue); }}
      portalMenu
      menuClassName="!z-[1100]"
      className="h-7 rounded border border-transparent bg-transparent px-2 pr-9 font-montserrat text-[12px] font-normal text-[#10233A] enabled:hover:border-[#D3E1EC] disabled:!bg-transparent disabled:!text-[#10233A]"
    />
    {error && <span role="alert" className="block font-montserrat text-[10px] text-[#B42318]">{error}</span>}
  </div>;
}
