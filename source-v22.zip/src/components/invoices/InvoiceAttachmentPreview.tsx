import { translateUi as uiText } from '../../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, X } from 'lucide-react';
import type { InvoiceAttachment } from '../../lib/invoiceCreation';

export default function InvoiceAttachmentPreview({ file, onClose }: { file: InvoiceAttachment; onClose: () => void }) {
  const title = useId(), root = useRef<HTMLDivElement>(null), close = useRef<HTMLButtonElement>(null);
  const [url, setUrl] = useState(''), [error, setError] = useState('');
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    let objectUrl = '';
    close.current?.focus();
    setUrl(''); setError('');
    try {
      const match = /^data:(application\/pdf|image\/(?:png|jpeg));base64,([A-Za-z0-9+/=\s]+)$/.exec(file.url);
      if (match && match[1] === file.type) {
        objectUrl = URL.createObjectURL(new Blob([Uint8Array.from(atob(match[2]), char => char.charCodeAt(0))], { type: file.type }));
        setUrl(objectUrl);
      } else {
        const storedUrl = new URL(file.url, window.location.href);
        if (!['https:', 'http:', 'blob:'].includes(storedUrl.protocol) || !['application/pdf', 'image/png', 'image/jpeg'].includes(file.type)) throw new Error('Unsupported attachment preview.');
        setUrl(storedUrl.href);
      }
    } catch { setError('This attachment could not be previewed.'); }
    return () => { if (objectUrl) URL.revokeObjectURL(objectUrl); previous?.focus(); };
  }, [file]);
  return createPortal(<div ref={root} role="dialog" aria-modal="true" aria-labelledby={title} className="fixed inset-0 z-[5500] flex items-center justify-center bg-[#10233A]/45 p-4 font-montserrat" onPointerDown={event => { if (event.target === event.currentTarget) onClose(); }} onKeyDown={event => {
    event.stopPropagation();
    if (event.key === 'Escape') { event.preventDefault(); onClose(); }
    if (event.key === 'Tab') {
      const controls = [...root.current!.querySelectorAll<HTMLElement>('a[href],button,iframe')];
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }}><section className="flex h-[90vh] w-full max-w-[1100px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
    <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-5 py-3"><div className="min-w-0"><h2 id={title} className="truncate text-[16px] font-semibold text-[#10233A]">{file.name}</h2>{file.size > 0 && <p className="mt-1 text-[11px] text-[#7288A3]">{(file.size / 1024).toFixed(1)}{uiText(" KB")}</p>}</div><div className="flex shrink-0 items-center gap-2">
      {url && <a href={url} download={file.name} aria-label={`Download ${file.name}`} className="flex h-8 w-8 items-center justify-center rounded-md border border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><Download size={16} /></a>}
      <button ref={close} type="button" onClick={onClose} aria-label={uiText("Close attachment preview")} className="flex h-8 w-8 items-center justify-center rounded-md border border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><X size={16} /></button>
    </div></header>
    <div className="min-h-0 flex-1 overflow-auto bg-[#F2F5F9] p-4">{error ? <p role="alert" className="text-[12px] text-[#B42318]">{error}</p> : !url ? <p role="status">{uiText("Loading attachment…")}</p> : file.type === 'application/pdf' ? <iframe title={`Attachment ${file.name}`} src={url} className="h-full w-full border-0 bg-white" /> : <img src={url} alt={`Attachment ${file.name}`} className="mx-auto max-h-full max-w-full object-contain" />}</div>
  </section></div>, document.body);
}
