import { translateUi as uiText } from '../../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';
import { SaveButton, CancelButton } from '../ScopedActionButtons';
import { documentLineInputClass } from '../documentLineDesign';

type Props = {
  label: string;
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange: (value: string) => void;
  onCreate: (name: string) => Promise<string>;
};

export default function InvoiceLineTypeSelect({ label, value, options, onChange, onCreate }: Props) {
  const [open, setOpen] = useState(false), [name, setName] = useState('');
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const input = useRef<HTMLInputElement>(null), dialog = useRef<HTMLDivElement>(null), pending = useRef(false);
  const titleId = useId();
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    input.current?.focus();
    return () => { previous?.focus(); };
  }, [open]);
  const close = () => { if (!pending.current) setOpen(false); };
  const create = async () => {
    if (pending.current) return;
    pending.current = true; setBusy(true); setError('');
    try { const created = await onCreate(name); onChange(created); setOpen(false); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not create the type.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return <>
    <SearchableSelect ariaLabel={uiText(label)} value={value} options={options} onChange={onChange} placeholder={uiText("Select type")} className={`${documentLineInputClass} w-full !pr-7`} portalMenu menuClassName="!z-[5200]" menuAction={{ label: 'Create line type', onClick: () => { setName(''); setError(''); setOpen(true); } }} />
    {open && createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/25 p-4" onClick={event => { if (event.target === event.currentTarget) close(); }}>
      <div ref={dialog} role="dialog" aria-modal="true" aria-labelledby={titleId} className="w-full max-w-[420px] rounded-xl border border-[#D3E1EC] bg-white p-6 font-montserrat text-[#10233A] shadow-xl" onKeyDown={event => {
        event.stopPropagation();
        if (event.key === 'Escape') { event.preventDefault(); close(); }
        if (event.key === 'Tab') {
          const controls = [...dialog.current!.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled)')];
          const first = controls[0], last = controls.at(-1);
          if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        }
      }}>
        <div className="mb-5 flex items-center justify-between gap-3"><h2 id={titleId} className="text-[18px] font-semibold">{uiText("Create line type")}</h2><button type="button" aria-label={uiText("Close create line type")} disabled={busy} onClick={close} className="text-[#7288A3] hover:text-[#007EA7] disabled:opacity-40"><X size={20} /></button></div>
        <label className="flex flex-col gap-1.5 text-[12px] font-medium text-[#7288A3]">{uiText("Type name ")}<input ref={input} aria-label={uiText("Type name")} required maxLength={80} disabled={busy} value={name} onChange={event => setName(event.target.value)} onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); event.stopPropagation(); void create(); } }} className="h-9 rounded-md border border-[#D3E1EC] bg-white px-3 text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20" /></label>
        {error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{error}</p>}
        <div className="mt-6 flex justify-end gap-3"><CancelButton onClick={close}>{uiText("Cancel")}</CancelButton><SaveButton disabled={busy || !name.trim()} onClick={() => void create()}>{busy ? uiText('Creating…') : uiText('Create type')}</SaveButton></div>
      </div>
    </div>, document.body)}
  </>;
}
