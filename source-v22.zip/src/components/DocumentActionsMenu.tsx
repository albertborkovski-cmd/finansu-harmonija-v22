import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { ChevronDown, Copy, FileMinus2, FilePlus2, Loader2, RotateCcw, Trash2, Undo2 } from 'lucide-react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canEditCompanyDocuments, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { canCreateCompanyDocument, documentActionRights } from '../lib/documentRowActionAccess';
import { canOpenDocumentRowAction, documentRowAction, type DocumentManagementActionKind, type DocumentRowAction } from '../lib/documentRowActions';
import { accountingToday, testDocumentStornoBlocker, type StornoDocument } from '../lib/documentStorno';
import { cancelDocumentApprovalBlocker } from '../lib/documentApproval';
import { loadStornoPeriodPolicy } from '../lib/documentStornoAccess';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import DropdownPortal from './DropdownPortal';
import { PageActionButton } from './PageHeader';
import { useDropdownDismiss } from './useDropdownDismiss';

type Props = {
  documentId: string;
  companyId: string;
  unsavedChanges: boolean;
  busy: boolean;
  onDuplicate?: (document: DbDocument) => void;
  onAction: (kind: DocumentManagementActionKind) => void;
};

/** This menu only opens existing workflows. Each workflow rechecks access and
 * current document state before it can save or delete anything. */
export default function DocumentActionsMenu({ documentId, companyId, unsavedChanges, busy, onDuplicate, onAction }: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [loaded, setLoaded] = useState<{ document: DbDocument; duplicate: boolean; storno: boolean; cancelApproval: boolean; action: DocumentRowAction }>();
  const anchor = useRef<HTMLDivElement>(null), menu = useRef<HTMLDivElement>(null);
  const menuId = useId(), focusLast = useRef(false);
  useDropdownDismiss(open, anchor, () => {
    if (menu.current?.contains(document.activeElement)) anchor.current?.querySelector('button')?.focus();
    setOpen(false);
  }, menu);

  useEffect(() => {
    if (!open) return;
    let cancelled = false, request = 0;
    const refresh = async () => {
      const currentRequest = ++request;
      setLoading(true); setLoaded(undefined); setError('');
      try {
        const [documents, companies, corrections] = await Promise.all([
          supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
          supabase.from('companies').select('*').eq('id', companyId),
          supabase.from('documents').select('id').eq('company_id', companyId).eq('correction_of_document_id', documentId),
        ]);
        if (cancelled || currentRequest !== request) return;
        const document = documents.data?.[0] as unknown as DbDocument | undefined;
        const company = companies.data?.[0] as unknown as Company | undefined;
        if (documents.error || companies.error || !document || !company || !canViewCompanyDocuments(company)) throw new Error('Document actions are unavailable. Refresh the document and check your access.');
        const rights = documentActionRights(company);
        const source = document as unknown as StornoDocument;
        let cancelApproval = false;
        try {
          cancelApproval = !corrections.error && !cancelDocumentApprovalBlocker(source, {
            allowed: canEditCompanyDocuments(company), today: accountingToday(), period: loadStornoPeriodPolicy(companyId),
            hasCorrections: Boolean(corrections.data?.length),
          });
        } catch { /* An unverifiable accounting period must not permit cancellation. */ }
        setLoaded({ document, duplicate: canCreateCompanyDocument(company),
          cancelApproval,
          storno: !testDocumentStornoBlocker(source, rights.storno),
          action: documentRowAction(source, rights) });
      } catch (cause) { if (!cancelled && currentRequest === request) setError(cause instanceof Error ? cause.message : 'Document actions are unavailable.'); }
      finally { if (!cancelled && currentRequest === request) setLoading(false); }
    };
    void refresh();
    const events = ['storage', SETTINGS_DATA_CHANGED_EVENT, 'document-storno-changed', 'finansu-harmonija:data-changed'];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => { cancelled = true; events.forEach(event => window.removeEventListener(event, refresh)); };
  }, [open, documentId, companyId]);

  useEffect(() => {
    if (!open || loading || !loaded) return;
    const frame = requestAnimationFrame(() => {
      const items = menu.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)');
      (focusLast.current ? items?.[items.length - 1] : items?.[0])?.focus();
    });
    return () => cancelAnimationFrame(frame);
  }, [open, loading, loaded]);

  const closeAndFocus = () => { setOpen(false); anchor.current?.querySelector('button')?.focus(); };
  const run = (action: () => void) => { if (busy || unsavedChanges || loading || !loaded) return; setOpen(false); action(); };
  const blocked = busy || unsavedChanges;
  const rowClass = 'flex min-h-9 w-full items-center gap-2.5 rounded-md px-3 py-2 text-left text-[12px] font-medium text-[#10233A] hover:bg-[#E5EDF9] focus:bg-[#E5EDF9] focus:outline-none disabled:cursor-not-allowed disabled:text-[#A1B6C6]';
  return <div ref={anchor} className="shrink-0" data-document-management-actions="true">
    <PageActionButton ariaLabel={uiText("Document actions")} ariaHasPopup="menu" ariaExpanded={open} ariaControls={open ? menuId : undefined} disabled={busy}
      className="border-2 border-[#D3E1EC]" onClick={() => { focusLast.current = false; setOpen(value => !value); }}
      onKeyDown={event => {
        if (['ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); focusLast.current = event.key === 'ArrowUp'; setOpen(true); }
        if (event.key === 'Escape') { event.stopPropagation(); closeAndFocus(); }
      }}><span className="inline-flex items-center gap-2">{uiText("Actions")}<ChevronDown size={14} className={open ? 'rotate-180' : ''} /></span></PageActionButton>
    {open && <DropdownPortal anchorRef={anchor} menuRef={menu} role="menu" ariaLabel={uiText("Document management actions")} id={menuId} align="end" width={248} height={300} zIndex={5200}
      onKeyDown={event => {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closeAndFocus(); return; }
        if (event.key === 'Tab') { setOpen(false); return; }
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        const items = [...(menu.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)') || [])];
        if (!items.length) return;
        const current = items.indexOf(document.activeElement as HTMLButtonElement);
        const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + items.length) % items.length;
        items[next]?.focus();
      }}>
      <div className="min-h-0 overflow-y-auto font-montserrat">
        {unsavedChanges && <p className="px-3 py-2 text-[11px] text-[#7288A3]">{uiText("Save your changes before using document actions.")}</p>}
        {loading && <p role="status" className="flex items-center gap-2 px-3 py-2 text-[12px] text-[#7288A3]"><Loader2 size={14} className="animate-spin" />{uiText("Checking available actions…")}</p>}
        {error && <p role="alert" className="px-3 py-2 text-[12px] text-[#B42318]">{error}</p>}
        {!loading && loaded && <>
          {loaded.duplicate && onDuplicate && <button type="button" role="menuitem" className={rowClass} disabled={blocked} onClick={() => run(() => onDuplicate(loaded.document))}><Copy size={16} className="shrink-0 text-[#7288A3]" />{uiText("Copy document")}</button>}
          {loaded.cancelApproval && <button type="button" role="menuitem" className={rowClass} disabled={blocked} onClick={() => run(() => onAction('cancel-approval'))}><RotateCcw size={16} className="shrink-0 text-[#7288A3]" />{uiText("Cancel approval")}</button>}
          {loaded.storno && <button type="button" role="menuitem" className={rowClass} disabled={blocked} onClick={() => run(() => onAction('storno'))}><Undo2 size={16} className="shrink-0 text-[#7288A3]" />{uiText("Storno")}</button>}
          {loaded.action.kind !== 'storno' && <span title={loaded.action.disabledReason || undefined} className="block">
            <button type="button" role="menuitem" className={rowClass} disabled={blocked || !canOpenDocumentRowAction(loaded.action)} onClick={() => run(() => onAction(loaded.action.kind))}>
              {loaded.action.kind === 'delete' ? <Trash2 size={16} className="shrink-0 text-[#7288A3]" /> : loaded.action.label === 'Create debit note' ? <FilePlus2 size={16} className="shrink-0 text-[#7288A3]" /> : <FileMinus2 size={16} className="shrink-0 text-[#7288A3]" />}
              {loaded.action.label}
            </button>
          </span>}
          {!(loaded.duplicate && onDuplicate) && !loaded.storno && !loaded.cancelApproval && loaded.action.kind === 'storno' && <p className="px-3 py-2 text-[12px] text-[#7288A3]">{uiText("No document actions are available.")}</p>}
        </>}
      </div>
    </DropdownPortal>}
  </div>;
}
