import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(source(path), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText;
const access = {};
new Function('exports', 'require', compile('../src/lib/accessControl.ts'))(access, () => ({ isInactiveRecord: () => false }));
const previous = 'ocr-review-approve-documents';
const current = 'ocr-workspace-document-issues';

test('reported issues have a separate Workspace route and system breadcrumb, not an approval panel', () => {
  const page = source('../src/components/OcrDocumentIssuesView.tsx');
  assert.match(page, /<PageHeader title="Document issues"/);
  assert.match(page, /<OcrBreadcrumb items=\{\['Workspace', 'Document issues'\]\}/);
  assert.match(page, /<DocumentIssueQueue \/>/);
  assert.doesNotMatch(source('../src/components/OcrReviewView.tsx'), /DocumentIssueQueue/);
  const dashboard = source('../src/components/Dashboard.tsx');
  assert.match(dashboard, /activeMenu === "ocr-workspace-document-issues"\)\s*return <OcrDocumentIssuesView \/>/);
  assert.doesNotMatch(dashboard, /<WorkspaceView|import WorkspaceView/);
  assert.match(dashboard, /activeMenu === "ocr-workspace-my-tasks"\)\s*return <OcrMyTasksView/);
  const sidebar = source('../src/components/Sidebar.tsx');
  assert.match(sidebar, /id: "ocr-workspace", label: "Workspace", icon: Monitor, hasDropdown: true/);
  assert.match(sidebar, /id: "ocr-workspace-document-issues", label: "Document issues"/);
  assert.match(sidebar, /workspaceSubItems.filter\(sub => canViewMenu\(sub.id\)\)/);
  assert.match(sidebar, /aria-current=\{isSubActive \? 'page' : undefined\}/);
});

test('Workspace parent opens My tasks directly and still supports collapse and expand', () => {
  const sidebar = source('../src/components/Sidebar.tsx');
  const tree = ts.createSourceFile('Sidebar.tsx', sidebar, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'handleMenuClick') handler = node.initializer;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(handler);
  const js = ts.transpileModule('return (' + handler.getText(tree) + ');', {
    compilerOptions: { target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const createHandler = new Function('activeMenu', 'workspaceSubItems', 'canViewMenu', 'setWorkspaceExpanded', 'onMenuClick', js);
  const tasks = 'ocr-workspace-my-tasks';
  const items = [{ id: tasks }, { id: current }];
  const click = (active, expanded, allowed = () => true) => {
    const navigations = [];
    createHandler(active, items, allowed, update => { expanded = update(expanded); }, id => navigations.push(id))('ocr-workspace');
    return { expanded, navigations };
  };
  for (const active of ['ocr-all-documents-processed', 'ocr-workspace', current]) {
    assert.deepEqual(click(active, false), { expanded: true, navigations: [tasks] });
  }
  assert.deepEqual(click(current, true), { expanded: true, navigations: [tasks] });
  assert.deepEqual(click(tasks, true), { expanded: false, navigations: [] });
  assert.deepEqual(click(tasks, false), { expanded: true, navigations: [] });
  assert.deepEqual(click('ocr-all-documents-processed', false, id => id === current), { expanded: true, navigations: [current] });
  assert.deepEqual(click('ocr-all-documents-processed', false, () => false).navigations, []);
});

test('legacy Workspace navigation resolves to an accessible child and never opens a separate parent page', () => {
  const dashboard = source('../src/components/Dashboard.tsx');
  const tree = ts.createSourceFile('Dashboard.tsx', dashboard, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const resolver = tree.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'workspaceDefaultMenu');
  assert.ok(resolver);
  const js = ts.transpileModule(resolver.getText(tree) + '\nreturn workspaceDefaultMenu;', {
    compilerOptions: { target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const resolve = new Function('canViewMenu', 'firstAccessibleMenu', js)((session, menu) => session.includes(menu), () => 'profile');
  assert.equal(resolve(['ocr-workspace-my-tasks', current]), 'ocr-workspace-my-tasks');
  assert.equal(resolve([current]), current);
  assert.equal(resolve([]), 'profile');
  assert.match(dashboard, /if \(activeMenu === "ocr-workspace"\)\s*\{\s*setActiveMenu\(workspaceDefaultMenu\(session\)\)/);
  assert.match(dashboard, /menu === "ocr-workspace" \? workspaceDefaultMenu\(session\) : menu/);
  const fallback = tree.statements.find(node => ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => declaration.name.getText(tree) === 'MENU_FALLBACK_ORDER'));
  assert.doesNotMatch(fallback.getText(tree), /"ocr-workspace"/);
});

test('new access area is under Workspace and inherits prior queue rights without modifying approval rights', () => {
  const workspace = access.flattenRoleAccessTree().find(node => node.id === 'ocr-workspace');
  assert.ok(workspace.children.some(node => node.id === current));
  for (const permission of [{ view: true, edit: true }, { view: true, edit: false }, { view: false, edit: false }]) {
    const original = { [previous]: permission };
    const migrated = access.migrateDocumentIssueMenuKey(original);
    assert.deepEqual(migrated[current], permission);
    assert.deepEqual(migrated[previous], permission);
    assert.equal(current in original, false);
  }
  const configured = { [previous]: { view: true, edit: true }, [current]: { view: false, edit: false } };
  assert.deepEqual(access.migrateDocumentIssueMenuKey(configured), configured);
  assert.deepEqual(access.migrateDocumentIssueMenuKey({}), {});
  assert.match(source('../src/lib/documentIssueAccess.ts'), /canEditMenu\(session, 'ocr-workspace-document-issues'\)/);
  assert.match(source('../src/components/SettingsIdentityManagementView.tsx'), /'ocr-workspace-document-issues',/);
});

test('Workspace uses the system connector between visible submenu items without dangling lines', () => {
  const sidebar = source('../src/components/Sidebar.tsx');
  const tree = ts.createSourceFile('Sidebar.tsx', sidebar, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let expression;
  const visit = node => {
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression)
      && node.expression.name.text === 'map'
      && node.expression.expression.getText(tree) === 'workspaceSubItems.filter(sub => canViewMenu(sub.id))') expression = node;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(expression);
  const js = ts.transpileModule('return ' + expression.getText(tree), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.React },
  }).outputText;
  const render = new Function('React', 'StepperDot', 'workspaceSubItems', 'canViewMenu', 'activeMenu', 'onMenuClick', js);
  const items = [{ id: 'ocr-workspace-my-tasks', label: 'My tasks' }, { id: current, label: 'Document issues' }];
  const React = { createElement: (type, props, ...children) => ({ type, props, children }) };
  const rows = render(React, 'StepperDot', items, () => true, current, () => {});
  assert.deepEqual(rows.map(row => row.children[0].props), [
    { isActive: false, isFirst: true, isLast: false },
    { isActive: true, isFirst: false, isLast: true },
  ]);
  const single = render(React, 'StepperDot', items, id => id === current, current, () => {});
  assert.deepEqual(single[0].children[0].props, { isActive: true, isFirst: true, isLast: true });
});

test('worker actions still require queue permission and exclude external users', () => {
  let session = { email: 'worker@example.test', roleNames: ['Worker'], access: access.createFullAccess(), menuAccess: access.createFullMenuAccess() };
  let external = [];
  const issues = {};
  const previousWindow = globalThis.window;
  globalThis.window = { localStorage: { getItem: () => 'session' } };
  try {
    new Function('exports', 'require', compile('../src/lib/documentIssueAccess.ts'))(issues, name => {
      if (name === './accessControl') return { ...access, parseSession: () => session };
      if (name === './currentUser') return { AUTH_SESSION_KEY: 'auth' };
      if (name === './linkedSettingsData') return { loadLinkedDirectoryUsers: () => external, canAccessAssignedOrganization: () => true };
      throw new Error(`Unexpected import: ${name}`);
    });
    assert.equal(issues.canReviewDocumentIssues(), true);
    session.menuAccess[current] = { view: true, edit: false };
    assert.equal(issues.canReviewDocumentIssues(), false);
    session.menuAccess[current] = { view: true, edit: true };
    external = [{ email: session.email }];
    assert.equal(issues.canReviewDocumentIssues(), false);
    external = [];
    session.roleNames = ['External demo user'];
    assert.equal(issues.canReviewDocumentIssues(), false);
    session = null;
    assert.equal(issues.canReviewDocumentIssues(), false);
  } finally {
    if (previousWindow === undefined) delete globalThis.window;
    else globalThis.window = previousWindow;
  }
});
