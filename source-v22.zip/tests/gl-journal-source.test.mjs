import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = source => ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
function load(file, require = name => { throw Error(name); }) {
  const exports = {};
  new Function('exports', 'require', compile(read(file)))(exports, require);
  return exports;
}
const source = load('../src/lib/glJournalSource.ts');
const inline = load('../src/lib/documentInlineEditing.ts');
const statuses = load('../src/lib/documentProcessingStatus.ts');
const detail = load('../src/lib/documentDetailEditing.ts', name => name === './documentInlineEditing' ? inline : statuses);
const issues = load('../src/lib/documentIssues.ts');
const storno = load('../src/lib/documentStorno.ts');

// Exercise the actual Documents mapping without loading its React UI.
const documentsSource = read('../src/components/Documents.tsx');
const ast = ts.createSourceFile('Documents.tsx', documentsSource, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const mappingSource = ast.statements.filter(node => ts.isFunctionDeclaration(node)
  && ['mapRow', 'commonLineValue'].includes(node.name?.text)).map(node => node.getText(ast)).join('\n');
const mapping = {};
new Function('exports', 'documentStornoPresentation', 'documentIssueStatus', 'documentIssueStatusLabel', compile(mappingSource))(
  mapping, storno.documentStornoPresentation, issues.documentIssueStatus, issues.documentIssueStatusLabel,
);
const accounts = new Set(['6300', '6202', '4430']);
const line = { id: 'allocation-1', expense: '6300', department: 'ADMIN', object: 'PROJECT-A', center: 'KC01', subtotal: '100.00', total: '121.00 EUR' };
const document = { id: 'doc-1', company_id: 'alice', number: 'INV-001', status: 'Draft', document_type: 'Invoices', document_subtype: 'Invoice',
  document_date: '2026-11-01', operation_date: '2026-11-02', currency: 'EUR', total_amount: '121.00',
  client_counterparty: 'Supplier A', expense_account: '6300', notes: 'Original note',
  summary_line_items: [line], line_items: [{ ...line, id: 'ocr-1', expense: '4430' }] };
const projected = raw => source.createJournalCandidates(mapping.mapRow(raw), accounts);

test('journal uses canonical accounting allocations, not OCR/product lines, without mutating either', () => {
  const input = structuredClone(document);
  input.summary_line_items.push({ ...line, id: 'allocation-2', expense: '6202', total: '20.50 EUR', department: 'SALES', object: 'PROJECT-B', center: 'KC02' });
  const before = JSON.stringify(input);
  const rows = projected(input);
  assert.deepEqual(rows.map(row => row.account), ['6300', '6202']);
  assert.deepEqual(rows.map(row => row.total), [121, 20.5]);
  assert.deepEqual(rows.map(row => [row.department, row.object, row.costCenter]), [['ADMIN', 'PROJECT-A', 'KC01'], ['SALES', 'PROJECT-B', 'KC02']]);
  assert.equal(rows[0].document.id, document.id);
  assert.equal(rows[0].description, 'Original note');
  assert.equal(JSON.stringify(input), before);
});

test('older source documents retain line and header account fallbacks and localized amounts', () => {
  const legacy = { ...document, summary_line_items: [] };
  assert.equal(projected(legacy)[0].account, '4430');
  const header = { ...legacy, line_items: [], total_amount: '1 234,56 EUR' };
  assert.equal(projected(header)[0].account, '6300');
  assert.equal(projected(header)[0].total, 1234.56);
  assert.equal(projected({ ...header, total_amount: '1,234.56 EUR' })[0].total, 1234.56);
});

test('edit routes source documents to their existing card and keeps journal drafts in their own editor', () => {
  const mapped = mapping.mapRow(document), row = projected(document)[0];
  const context = { row, companyId: 'alice', allowed: true, sourceMode: 'company', sourceDocument: mapped };
  assert.equal(source.journalEditTarget(context), 'document');
  assert.equal(source.journalEditTarget({ ...context, sourceDocument: { ...mapped, status: 'Approved' } }), 'document');
  const postingRow = { ...row, sourceDocumentId: mapped.id, posted: true, document: { ...row.document, id: 'posting-1' } };
  assert.equal(source.journalEditTarget({ ...context, row: postingRow }), 'document');
  assert.equal(source.journalSourceDocumentId(postingRow), mapped.id);
  assert.equal(source.journalEditTarget({ ...context, savedEntry: { id: document.id } }), 'journal');
  assert.equal(source.journalEditTarget({ ...context, row: { ...row, sample: true }, sourceMode: 'test', sourceDocument: undefined }), 'journal');
  for (const change of [{ allowed: false }, { sourceDocument: undefined }, { companyId: 'another-company' },
    { row: { ...row, inactive: true } }, { savedEntry: { id: document.id, inactive: true } },
    { sourceDocument: { ...mapped, inlineSource: { inactive: true } } },
    { sourceDocument: { ...mapped, inlineSource: { document_deletion: {} } } }]) {
    assert.equal(source.journalEditTarget({ ...context, ...change }), null);
  }
});

function fixture(initial = document) {
  const store = new Map(), events = []; let allowed = true;
  const api = {}, require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentDetailEditing') return detail;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile(read('../src/lib/supabase.ts')))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout,
      dispatchEvent: event => events.push(event) }, {}, async () => { throw Error('Isolated static storage'); },
    class { constructor(type, options) { this.type = type; this.detail = options?.detail; } });
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [initial]); put('companies', [{ id: 'alice', name: 'Alice Stone' }]); put('document_history', []);
  return { ...api, get, events, revoke: () => { allowed = false; } };
}

test('a save through the shared document command updates the same record, journal projection and history', async () => {
  const f = fixture(), before = JSON.stringify(document);
  const patch = { notes: 'Corrected from journal', number: 'INV-002', operation_date: '2026-11-04', client_counterparty: 'Supplier B',
    accountable_responsible: 'Accountant B', summary_line_items: [{ ...line, expense: '6202', department: 'SALES', center: 'KC02', object: 'PROJECT-B', total: '242.00 EUR' }],
    total_amount: '242.00' };
  const result = await f.applyDocumentDetailEdit(document.id, 'alice', patch, detail.documentDetailSnapshot(document), 'Corrected GL allocation');
  const stored = f.get('documents');
  assert.equal(stored.length, 1); assert.equal(stored[0].id, document.id);
  assert.deepEqual(stored[0], result.document);
  assert.deepEqual(stored[0].line_items, document.line_items);
  const [journal] = projected(stored[0]);
  assert.equal(journal.account, '6202'); assert.equal(journal.total, 242);
  assert.equal(journal.documentNumber, 'INV-002'); assert.equal(journal.operationDate, '2026-11-04');
  assert.equal(journal.counterparty, 'Supplier B'); assert.equal(journal.employee, 'Accountant B');
  assert.equal(journal.department, 'SALES'); assert.equal(journal.costCenter, 'KC02'); assert.equal(journal.object, 'PROJECT-B');
  assert.equal(journal.description, 'Corrected from journal');
  assert.equal(stored[0].detail_edit_history[0].user_name, 'Test accountant');
  assert.equal(f.get('document_history').length, 1);
  assert.ok(f.events.some(event => source.isJournalSourceChange(event)));
  assert.equal(JSON.stringify(document), before);
  await assert.rejects(f.applyDocumentDetailEdit(document.id, 'alice', patch, detail.documentDetailSnapshot(document), 'Stale correction'), /changed/);
  f.revoke();
  await assert.rejects(f.applyDocumentDetailEdit(document.id, 'alice', patch, detail.documentDetailSnapshot(result.document), 'No access'), /access/);
});

test('opening from the journal cannot bypass approval, posted-operation or company boundaries', async () => {
  for (const state of [{ status: 'Approved' }, { accounting_posting: {} }, { inactive: true }]) {
    const original = { ...document, ...state }, f = fixture(original);
    await assert.rejects(f.applyDocumentDetailEdit(original.id, 'alice', { notes: 'Forbidden correction' }, detail.documentDetailSnapshot(original), 'Edit'));
    assert.deepEqual(f.get('documents'), [original]);
  }
  const f = fixture();
  await assert.rejects(f.applyDocumentDetailEdit(document.id, 'another-company', { notes: 'Wrong company' }, detail.documentDetailSnapshot(document), 'Edit'));
  assert.deepEqual(f.get('documents'), [document]);
});

test('document save notifications and cross-tab changes refresh the journal, unrelated changes do not', () => {
  assert.equal(source.isJournalSourceChange({ type: 'finansu-harmonija:data-changed', detail: { table: 'documents' } }), true);
  assert.equal(source.isJournalSourceChange({ type: 'finansu-harmonija:data-changed', detail: { table: 'document_history' } }), false);
  assert.equal(source.isJournalSourceChange({ type: 'storage', key: 'finansu-harmonija-v4:data:documents' }), true);
  assert.equal(source.isJournalSourceChange({ type: 'storage', key: 'unrelated' }), false);
  assert.equal(source.isJournalSourceChange({ type: 'storage', key: null }), true);
  const view = read('../src/components/CompanyGlJournalView.tsx');
  assert.match(view, /initialViewDocumentId=\{sourceEditorDocumentId\} initialDocumentMode="edit"/);
  assert.match(view, /onInitialViewBack=\{\(\) => \{ setSourceEditorDocumentId\(null\); void loadDocuments\(\); \}\}/);
  assert.match(view, /if \(target === 'document'\) \{ setSourceEditorDocumentId\(journalSourceDocumentId\(row\)\); return; \}/);
  assert.match(read('../src/lib/documentStorno.ts'), /sourceDocumentId: document\.id/);
  assert.match(view, /window.removeEventListener\('finansu-harmonija:data-changed', refreshSource\)/);
  assert.match(view, /window.removeEventListener\('storage', refreshSource\)/);
});
