import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const issues = {}, storno = {}, examples = {}, exportsCore = {}, core = {};
new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
new Function('exports', compile('../src/lib/documentTestingExamples.ts'))(examples);
new Function('exports', compile('../src/lib/documentExport.ts'))(exportsCore);
new Function('exports', 'require', compile('../src/lib/documentTestDelivery.ts'))(core, name => { if (name === './documentIssues') return issues; throw Error(name); });
const documents = examples.createDocumentTestingExamples('company-1');
const snapshot = core.documentTestDeliverySnapshot;
const command = (rows, extra = {}) => ({ requestId: 'test-request-001', companyId: 'company-1', ids: rows.map(row => row.id), destinationId: 'rivile', scenario: 'accepted', snapshots: Object.fromEntries(rows.map(row => [row.id, snapshot(row)])), ...extra });
const receipt = (row, extra = {}) => core.createDocumentTestDelivery(row, command([row], extra), 'Rivilė', 'Test accountant', '2026-11-04T10:00:00.000Z');

test('successful simulation creates a clearly marked receipt without changing processing or GL state', () => {
  const doc = structuredClone(documents[0]), before = structuredClone(doc);
  const result = receipt(doc);
  assert.equal(result.mode, 'test'); assert.equal(result.outcome, 'Accepted');
  assert.match(result.reference, /^TEST-/); assert.match(result.message, /Nothing was sent/);
  assert.deepEqual(doc, before);
  assert.equal(result.status, undefined); assert.equal(result.accounting_posting, undefined);
});

test('simulation rejects or blocks independently of document status and never ignores digitization issues', () => {
  assert.equal(receipt(documents[0], { scenario: 'rejected' }).outcome, 'Rejected');
  for (const index of [10, 11, 18, 19]) assert.equal(receipt(documents[index]).outcome, 'Blocked', documents[index].number);
  assert.match(receipt(documents[10]).message, /Resolve.*issue/);
  assert.match(receipt(documents[18]).message, /already been transferred/);
  assert.equal(receipt(documents[17]).outcome, 'Accepted');
  for (const change of [{ inactive: true }, { active: false }, { accounting_storno: {} }, { status: 'Unknown' }, { external_document_id: 'ERP-123' }]) assert.equal(receipt({ ...documents[0], ...change }).outcome, 'Blocked');
});

test('validation uses accounting allocations, not OCR product count, and explains missing or inconsistent data', () => {
  assert.equal(documents[1].line_items.length, 12); assert.equal(receipt(documents[1]).outcome, 'Accepted');
  assert.equal(documents[2].summary_line_items.length, 3); assert.equal(receipt(documents[2]).outcome, 'Accepted');
  for (const patch of [{ number: '' }, { client_counterparty: '' }, { document_date: '2026-02-30' }, { currency: '' }, { total_amount: 'oops' }, { total_amount: '1' }]) assert.equal(receipt({ ...documents[0], ...patch }).outcome, 'Blocked');
  const missing = structuredClone(documents[0]); missing.summary_line_items[0].expense = '';
  assert.match(receipt(missing).message, /GL account/);
  missing.summary_line_items[0].expense = '6000'; missing.summary_line_items[0].vatClass = '';
  assert.match(receipt(missing).message, /VAT classifier/);
  const unequal = structuredClone(documents[2]); unequal.summary_line_items.pop();
  assert.match(receipt(unequal).message, /do not match/);
  assert.equal(receipt(documents[7]).outcome, 'Accepted');
  assert.equal(receipt(documents[6]).outcome, 'Accepted');
});

test('source snapshots detect edits and company changes without including previous simulation metadata', () => {
  const row = documents[0], request = command([row]);
  assert.throws(() => core.createDocumentTestDelivery({ ...row, total_amount: '1' }, request, 'Rivilė', 'Accountant', 'now'), /changed/);
  assert.throws(() => core.createDocumentTestDelivery({ ...row, company_id: 'other' }, request, 'Rivilė', 'Accountant', 'now'), /outside/);
  assert.notEqual(snapshot(row), snapshot({ ...row, order_no: 'changed' }));
  assert.equal(snapshot(row), snapshot({ ...row, accounting_test_deliveries: [receipt(row)] }));
  const reversed = { ...row, document_storno: { mode: 'test', status: 'Reversed' } };
  assert.notEqual(snapshot(row), snapshot(reversed));
  assert.equal(receipt(reversed).outcome, 'Blocked');
  assert.match(receipt(reversed).message, /reversed in test mode/);
});

function fixture() {
  const storage = new Map(); let allowed = true;
  const api = {};
  const require = name => {
    if (name === './documentTestDelivery') return core;
    if (name === './documentExport') return exportsCore;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './documentTestingExamples') return examples;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  const fakeWindow = { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} };
  const requests = [];
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require, fakeWindow, {}, async url => { requests.push(url); throw Error('Static deployment'); }, class {});
  const put = (table, rows) => storage.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(storage.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', documents); put('companies', [{ id: 'company-1', name: 'Alice Stone' }]); put('document_history', []);
  return { ...api, put, get, requests, revoke: () => { allowed = false; } };
}

test('adapter persists results and history, survives reload, and deduplicates double-click/concurrent retries', async () => {
  const f = fixture(), selected = [documents[0], documents[10]], request = command(selected);
  const [first, second] = await Promise.all([f.applyDocumentTestDelivery(request), f.applyDocumentTestDelivery(request)]);
  assert.deepEqual(first, second);
  assert.deepEqual(first.map(row => row.accounting_test_deliveries[0].outcome), ['Accepted', 'Blocked']);
  assert.equal(f.get('document_history').length, 2);
  for (const row of f.get('documents')) {
    const original = documents.find(original => original.id === row.id);
    const { accounting_test_deliveries, ...rest } = row;
    assert.deepEqual(rest, original);
    assert.ok(!accounting_test_deliveries || accounting_test_deliveries.length === 1);
  }
  assert.ok(f.requests.every(url => url.startsWith('/__meso_shared_data/')));
  const result = await f.supabase.from('documents').select('*').eq('id', selected[0].id);
  assert.equal(result.data[0].accounting_test_deliveries[0].outcome, 'Accepted');
  assert.equal(result.data[0].status, 'Draft');
});

test('a rejected test can be retried successfully while retaining both attempts and immutable source records', async () => {
  const f = fixture(), row = documents[0];
  await f.applyDocumentTestDelivery(command([row], { scenario: 'rejected' }));
  await f.applyDocumentTestDelivery(command([row], { requestId: 'test-request-002' }));
  const saved = f.get('documents')[0];
  assert.deepEqual(saved.accounting_test_deliveries.map(attempt => attempt.outcome), ['Rejected', 'Accepted']);
  assert.equal(saved.status, row.status); assert.equal(saved.total_amount, row.total_amount);
  assert.equal(f.get('document_history').length, 2);
});

test('adapter rechecks permissions, selection, destination and concurrent source data before writing any results', async () => {
  const f = fixture(), row = documents[0];
  await assert.rejects(f.applyDocumentTestDelivery(command([row], { ids: [] })), /Select/);
  await assert.rejects(f.applyDocumentTestDelivery(command([row], { ids: ['missing'] })), /no longer/);
  await assert.rejects(f.applyDocumentTestDelivery(command([row], { destinationId: 'unknown' })), /unavailable/);
  await assert.rejects(f.applyDocumentTestDelivery(command([row], { companyId: 'other' })), /access/);
  await assert.rejects(f.applyDocumentTestDelivery(command([row], { scenario: 'fake' })), /Invalid/);
  f.put('documents', [{ ...row, notes: 'Changed by someone else' }, documents[1]]);
  await assert.rejects(f.applyDocumentTestDelivery(command([row, documents[1]])), /changed/);
  assert.equal(f.get('documents')[1].accounting_test_deliveries, undefined);
  f.revoke(); await assert.rejects(f.applyDocumentTestDelivery(command([documents[1]])), /access/);
  assert.equal(f.get('document_history').length, 0);
});

test('destination is saved immediately per company without transferring documents or replacing company settings', async () => {
  const f = fixture();
  const company = { id: 'company-1', name: 'Alice Stone', email: 'alice@example.test', counterparties_settings: JSON.stringify({ keep: 'unchanged' }) };
  const other = { id: 'company-2', name: 'Other company', accounting_destination_id: 'agnum' };
  f.put('companies', [company, other]);
  const saved = await f.saveCompanyAccountingDestination('company-1', 'rivile');
  assert.deepEqual(saved, { ...company, accounting_destination_id: 'rivile' });
  assert.deepEqual(f.get('companies'), [saved, other]);
  const reloaded = await f.supabase.from('companies').select('*').eq('id', 'company-1');
  assert.equal(exportsCore.savedDocumentDeliveryDestination(reloaded.data[0]).value, 'rivile');
  assert.deepEqual(f.get('documents'), documents);
  assert.deepEqual(f.get('document_history'), []);
  await f.saveCompanyAccountingDestination('company-1', 'agnum');
  assert.equal(f.get('companies')[0].accounting_destination_id, 'agnum');
  assert.deepEqual(f.get('companies')[1], other);
});

test('direct send rechecks Primary export format under the write lock and leaves obsolete destination settings untouched', async () => {
  const f = fixture(), row = documents[0];
  const company = { id: 'company-1', name: 'Alice Stone', primary_export_format: 'B1', accounting_destination_id: 'rivile' };
  f.put('companies', [company]);
  const request = command([row], { destinationSource: 'primary-export-format', destinationId: 'b1' });
  await assert.rejects(f.applyDocumentTestDelivery({ ...request, destinationId: 'rivile' }), /Primary export format has changed/);
  assert.deepEqual(f.get('document_history'), []);
  assert.deepEqual(f.get('documents'), documents);
  const [saved] = await f.applyDocumentTestDelivery(request);
  assert.equal(saved.accounting_test_deliveries[0].destinationId, 'b1');
  assert.equal(saved.accounting_test_deliveries[0].destinationName, 'B1');
  assert.equal(saved.status, row.status);
  assert.deepEqual(f.get('companies'), [company]);
  assert.equal(f.get('document_history').length, 1);
});

test('invalid or unavailable Primary export formats never create receipts or switch to old preferences', async () => {
  const f = fixture(), row = documents[0];
  const request = command([row], { destinationSource: 'primary-export-format' });
  for (const primary_export_format of ['', 'Unknown']) {
    f.put('companies', [{ id: 'company-1', name: 'Alice Stone', primary_export_format, accounting_destination_id: 'rivile' }]);
    await assert.rejects(f.applyDocumentTestDelivery(request), /unavailable/);
  }
  f.put('companies', [{ id: 'company-1', name: 'Alice Stone', primary_export_format: 'Rivilė' }]);
  await assert.rejects(f.applyDocumentTestDelivery({ ...request, destinationSource: 'other' }), /Invalid accounting destination source/);
  assert.deepEqual(f.get('document_history'), []);
  assert.deepEqual(f.get('documents'), documents);
});

test('destination persistence checks fresh permissions and integration availability', async () => {
  const f = fixture();
  await assert.rejects(f.saveCompanyAccountingDestination('other', 'rivile'), /access/);
  await assert.rejects(f.saveCompanyAccountingDestination('company-1', 'unknown'), /unavailable/);
  await assert.rejects(f.saveCompanyAccountingDestination('company-1', ''), /unavailable/);
  f.put('companies', [{ id: 'company-1', name: 'Alice Stone', counterparties_settings: JSON.stringify({ exportIntegrations: [{ id: 'rivile', name: 'Rivilė', active: false }] }) }]);
  await assert.rejects(f.saveCompanyAccountingDestination('company-1', 'rivile'), /unavailable/);
  f.put('companies', [{ id: 'company-1', name: 'Alice Stone' }]);
  f.revoke();
  await assert.rejects(f.saveCompanyAccountingDestination('company-1', 'rivile'), /access/);
  assert.equal(f.get('companies')[0].accounting_destination_id, undefined);
});

test('queued destination changes keep the latest choice and preserve independent companies', async () => {
  const f = fixture();
  f.put('companies', [{ id: 'company-1', name: 'Alice Stone' }, { id: 'company-2', name: 'Second company' }]);
  await Promise.all([
    f.saveCompanyAccountingDestination('company-1', 'agnum'),
    f.saveCompanyAccountingDestination('company-2', 'rivile-api'),
    f.saveCompanyAccountingDestination('company-1', 'rivile'),
  ]);
  assert.deepEqual(f.get('companies').map(row => row.accounting_destination_id), ['rivile', 'rivile-api']);
});

test('UI remembers the destination, names Send accordingly and removes verbose test controls while labelling simulated results', () => {
  const dialog = read('../src/components/DocumentDeliveryDialog.tsx');
  assert.doesNotMatch(dialog, /Test mode|Test scenario|Rejected response|No accounting API is connected|Accounting entries remain unchanged/);
  assert.match(dialog, /Test · API not connected/);
  assert.match(dialog, /No documents are sent to an external accounting system/);
  assert.match(dialog, /Send to \$\{destinationName \|\| 'accounting'\}/);
  assert.match(dialog, /onChange=\{value => void changeDestination\(value\)\}/);
  assert.match(dialog, /savedDocumentDeliveryDestination\(selectedCompany\)/);
  assert.match(dialog, /await onSaveDestination\(company\.id, value\)/);
  assert.match(dialog, /setDestination\(previous\)/);
  assert.match(dialog, /scenario: 'accepted'/);
  assert.match(dialog, /record\.testDeliveries\?\.at\(-1\)/);
  assert.match(read('../src/components/Documents.tsx'), /applyDocumentTestDelivery\(command\)/);
  assert.doesNotMatch(read('../src/lib/documentTestDelivery.ts'), /fetch\(|status:\s*'Transferred'/);
});
