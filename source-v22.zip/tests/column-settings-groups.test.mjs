import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';

const require = createRequire(import.meta.url), exports = {};
const source = readFileSync(new URL('../src/components/ColumnSettingsPanel.tsx', import.meta.url), 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText;
new Function('exports', 'require', compiled)(exports, name => name === './ScopedActionButtons' ? { SaveButton: () => createElement('button', null, 'Save') } : require(name));
const render = columns => renderToStaticMarkup(createElement(exports.default, { columns, onSave() {}, onClose() {} }));
const column = (key, group, visible = false) => ({ key, label: key, width: 100, visible, ...(group ? { group } : {}) });

test('grouped settings retain one section per group, with stable checked controls and reorder handles', () => {
  const html = render([column('System ID', undefined, true), column('Barcode', 'Items / Services'), column('Discount %', 'Prices / Discounts'), column('Item code', 'Items / Services')]);
  assert.equal((html.match(/<h3 /g) || []).length, 3);
  assert.ok(html.indexOf('Show Barcode column') < html.indexOf('Show Item code column'));
  assert.ok(html.indexOf('Show Item code column') < html.indexOf('Show Discount % column'));
  assert.match(html, /aria-label="Hide System ID column" aria-pressed="true"/);
  assert.match(html, /aria-label="Show Barcode column" aria-pressed="false"/);
  assert.match(html, /Drag Barcode column/);
  assert.match(html, /w-\[420px\]/);
});

test('un-grouped system tables retain their existing list, width, ordering and footer', () => {
  const html = render([column('Name', undefined, true), column('ID')]);
  assert.ok(!html.includes('<h3'));
  assert.match(html, /w-\[340px\]/);
  assert.ok(html.indexOf('Hide Name column') < html.indexOf('Show ID column'));
  for (const label of ['Search columns', 'Default', 'Cancel', 'Save']) assert.ok(html.includes(label));
});
