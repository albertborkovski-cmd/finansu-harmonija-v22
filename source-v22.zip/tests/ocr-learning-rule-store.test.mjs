import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const load = (file, dependencies = {}, globals = {}) => {
  const api = {};
  new Function('exports', 'require', ...Object.keys(globals), ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)
    (api, key => { if (dependencies[key]) return dependencies[key]; throw new Error(key); }, ...Object.values(globals));
  return api;
};
const core = load('../src/lib/ocrLearning.ts');
test('learning edits persist and affect only future empty suggestions, with permission checked at save', () => {
  let edit = true;
  const values = new Map(), events = [];
  const localStorage = { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, value) };
  const context = { companyId: 'alice', companyName: 'Alice', supplierKey: '123', supplierName: 'Supplier', vatRate: '21', expenseAccount: '', vatClassifier: '' };
  let store = core.emptyLearningStore();
  for (const documentId of ['one', 'two']) store = core.confirmLearning(store, { ...context, field: 'expense_account', value: '6202', documentId, documentName: documentId + '.pdf', confirmedAt: '2026-11-13', confirmedBy: { name: 'Worker', email: 'worker@example.test' } });
  const api = load('../src/lib/ocrLearningStore.ts', {
    './ocrLearning': core, './supabase': {}, './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserIdentity: () => ({ fullName: 'Admin', email: 'admin@example.test' }) },
    './accessControl': { parseSession: () => ({ roleNames: [] }), canEditMenu: () => edit, isSystemAdministratorRole: () => false },
  }, { localStorage, window: { dispatchEvent: event => events.push(event) }, CustomEvent: class {} });
  values.set(api.OCR_LEARNING_KEY, JSON.stringify(store));
  const id = core.learnedRows(store)[0].id;
  api.saveLearningRule(id, { value: '6300', confidence: 100 });
  assert.equal(core.learnedRows(api.loadLearningStore())[0].rule.value, '6300');
  assert.equal(api.suggestDocumentAccounting(context).expenseAccount, '6300');
  assert.equal(api.suggestDocumentAccounting({ ...context, expenseAccount: 'Existing' }).expenseAccount, 'Existing');
  edit = false; const before = values.get(api.OCR_LEARNING_KEY);
  assert.throws(() => api.saveLearningRule(id, { value: '9999', confidence: 100 }), /permission/);
  assert.equal(values.get(api.OCR_LEARNING_KEY), before);
  edit = true; api.saveLearningRule(id, null);
  assert.equal(api.suggestDocumentAccounting(context).expenseAccount, '6202');
  assert.equal(events.length, 2);
});
