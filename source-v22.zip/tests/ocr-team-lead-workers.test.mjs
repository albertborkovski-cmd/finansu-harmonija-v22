import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = text => ts.transpileModule(text, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const load = (path, require = () => { throw Error('Unexpected import'); }) => {
  const exports = {}; new Function('exports', 'require', compile(source(path)))(exports, require); return exports;
};
const lifecycle = load('../src/lib/recordLifecycle.ts');
const { ocrTaskWorker, documentWorkEntry, teamLeadWorkerDirectory, teamLeadWorkerDocumentIds, matchesIssueWorker } = load('../src/lib/ocrTeamLeadWorkers.ts', () => lifecycle);
const documents = [
  { id: 'd1', company_id: 'c1' }, { id: 'd2', company_id: 'c1' },
  { id: 'd3', company_id: 'c1', digitization_issues: [{ assignedToEmail: 'issue@example.test', assignedToName: 'Issue worker' }] },
  { id: 'd4', company_id: 'c1', inactive: true },
];
const tasks = new Map([
  ['d1', { assignedToEmail: ' ALICE@example.test ', assignedToName: 'Same name', teamLeadReview: { status: 'Pending', requestedByEmail: 'lead@example.test' } }],
  ['d2', { assignedToEmail: 'bob@example.test', assignedToName: 'Same name', status: 'Completed' }],
  ['d4', { assignedToEmail: 'alice@example.test' }],
]);

test('worker identity uses explicit assignment before review sender or work log and never infers by name', () => {
  assert.deepEqual(ocrTaskWorker(tasks.get('d1'), { email: 'lead@example.test', user: 'Team lead' }), { email: 'alice@example.test', name: 'Same name' });
  assert.deepEqual(ocrTaskWorker({ teamLeadReview: { requestedByEmail: 'worker@example.test', requestedBy: 'Worker' } }), { email: 'worker@example.test', name: 'Worker' });
  assert.equal(ocrTaskWorker({ assignedToName: 'Same name' }, { user: 'Same name' }), undefined);
  assert.equal(documentWorkEntry({ 'document-set-d1': { email: 'worker@example.test' } }, 'd1').email, 'worker@example.test');
});

test('all-worker tasks and exact-worker tasks retain completed work without mixing same-name workers', () => {
  assert.deepEqual([...teamLeadWorkerDocumentIds(documents, tasks, {})], ['d1', 'd2']);
  assert.deepEqual([...teamLeadWorkerDocumentIds(documents, tasks, {}, ' ALICE@example.test ')], ['d1']);
  assert.deepEqual([...teamLeadWorkerDocumentIds(documents, tasks, {}, 'bob@example.test')], ['d2']);
  assert.deepEqual([...teamLeadWorkerDocumentIds(documents, tasks, {}, 'missing@example.test')], []);
  const workers = teamLeadWorkerDirectory(documents, tasks, {}, [{ email: 'alice@example.test', fullName: 'Alice Worker' }, { email: 'unrelated@example.test', fullName: 'Not a worker' }]);
  assert.equal(workers.length, 3);
  assert.equal(workers.find(worker => worker.email === 'alice@example.test').name, 'Alice Worker');
  assert.ok(workers.some(worker => worker.email === 'issue@example.test'));
});

test('issue scope cannot be cleared by search or confused with a worker display name', () => {
  assert.equal(matchesIssueWorker({ assignedToEmail: 'WORKER@example.test' }, 'worker@example.test'), true);
  assert.equal(matchesIssueWorker({ assignedToName: 'Worker' }, 'worker@example.test'), false);
  assert.equal(matchesIssueWorker({ assignedToEmail: 'other@example.test' }, 'worker@example.test'), false);
  assert.equal(matchesIssueWorker({}, ''), true);
});

test('TeamLead oversight requires internal TeamLead rights and preserves company access', () => {
  let session = { email: 'lead@example.test', roleNames: ['TeamLead'] }, view = true, assigned = true, external = [];
  const access = load('../src/lib/ocrTeamLeadAccess.ts', name => ({
    './accessControl': { canViewMenu: (_session, area) => view && area === 'ocr-ml' },
    './documentIssueAccess': { documentIssueSession: () => session },
    './linkedSettingsData': { canAccessAssignedOrganization: () => assigned, loadLinkedDirectoryUsers: () => external },
  })[name]);
  assert.equal(access.canViewTeamLeadWork(), true);
  assert.equal(access.canViewTeamLeadOrganization({ id: 'c1', name: 'Company' }), true);
  assigned = false; assert.equal(access.canViewTeamLeadOrganization({ id: 'c1', name: 'Company' }), false);
  external = [{ email: session.email }]; assert.equal(access.canViewTeamLeadWork(), false);
  external = []; view = false; assert.equal(access.canViewTeamLeadWork(), false);
  view = true; session = null; assert.equal(access.canViewTeamLeadWork(), false);
});

test('worker overview reuses system tables and opens read-only tasks without assignment or work-time writes', () => {
  const page = source('../src/components/OcrTeamLeadWorkersView.tsx');
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  const parent = source('../src/components/ml/MachineLearningView.tsx');
  const issues = source('../src/components/DocumentIssueQueue.tsx');
  for (const component of ['PageHeader', 'OcrBreadcrumb', 'SearchableSelect', 'ProcessedDocumentsTable', 'DocumentIssueQueue', 'WorkspaceDocumentEditor'])
    assert.match(page, new RegExp('<' + component + '\\b'));
  assert.match(page, /readOnly viewNotice="Worker task · Read-only"/);
  assert.doesNotMatch(page, /onSave=|onEditDocument=|applyDocumentIssueAction/);
  assert.match(parent, /onOpenWorker=\{worker => setWorkerOverview\(worker.email\)\}/);
  assert.match(table, /optionLabels:[\s\S]*row.workerEmail/);
  assert.match(issues, /!teamLeadOverview && <button type="button" title=\{disabledReason/);
  assert.match(issues, /matchesIssueWorker\(row.issue, workerEmail\)/);
});

test('team lead issue view does not claim another worker’s issue and rejects edit or cross-worker requests', async () => {
  const queue = source('../src/components/DocumentIssueQueue.tsx');
  const tree = ts.createSourceFile('queue.tsx', queue, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => { if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'openEditor') handler = node.initializer; ts.forEachChild(node, visit); };
  visit(tree);
  const document = { id: 'd1', company_id: 'c1', digitization_issues: [{ id: 'i1', status: 'In progress', assignedToEmail: 'worker@example.test' }] };
  const events = [], errors = [];
  const build = workerEmail => new Function('teamLeadOverview', 'workerEmail', 'matchesIssueWorker', 'canViewTeamLeadOrganization', 'opening', 'setOpening', 'setError', 'setQueuedNotice', 'supabase', 'companyById', 'editError', 'applyDocumentIssueAction', 'setEditing', compile('return ' + handler.getText(tree)))
    (true, workerEmail, matchesIssueWorker, () => true, false, () => {}, error => { if (error) errors.push(error); }, () => {},
      { from: () => ({ select: () => ({ eq: async () => ({ data: [document] }) }) }) }, new Map([['c1', { id: 'c1' }]]), () => '',
      () => { throw Error('Must not claim'); }, value => events.push(value));
  await build('worker@example.test')(document, 'i1', true);
  assert.deepEqual(events, [{ document, issueId: 'i1', readOnly: true }]);
  events.length = 0;
  await build('worker@example.test')(document, 'i1', false);
  await build('different@example.test')(document, 'i1', true);
  assert.equal(events.length, 0); assert.equal(errors.length, 2);
});
