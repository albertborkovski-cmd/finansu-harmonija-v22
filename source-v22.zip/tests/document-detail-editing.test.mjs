import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const inline = {}, statuses = {}, core = {};
new Function('exports', compile('../src/lib/documentInlineEditing.ts'))(inline);
new Function('exports', compile('../src/lib/documentProcessingStatus.ts'))(statuses);
new Function('exports', 'require', compile('../src/lib/documentDetailEditing.ts'))(core, name => name === './documentInlineEditing' ? inline : statuses);
const row = { id: 'line-1', qty: '2', price: '50', discount: '0', subtotal: '100', vatPct: '21%', vat: '21.00 EUR', total: '121.00 EUR' };
const document = { id: 'doc-1', company_id: 'company-1', status: 'Draft', document_type: 'Invoices', document_subtype: 'Credit invoice', summary_line_items: [row, { ...row, id: 'line-2' }], line_items: [row] };

test('all document header fields have a persisted value, independent of the number of allocations', () => {
  const header = { documentType: 'Contracts', type: 'Purchase', status: 'Pending', documentDate: '2026-11-03', documentPurpose: 'Purchase', validForm: '2026-11-01', note: 'Corrected note' };
  const patch = core.documentDetailHeaderPatch(header, 'Invoices');
  assert.deepEqual(patch, { document_type: 'Contracts', type: 'Purchase', status: 'Pending', document_date: '2026-11-03', document_purpose: 'Purchase', valid_form: '2026-11-01', notes: 'Corrected note', document_subtype: '' });
  assert.doesNotThrow(() => core.validateDocumentDetailEdit(document, patch, core.documentDetailSnapshot(document), true));
  assert.equal(patch.summary_line_items, undefined);
});

test('Document purpose offers only Purchase and Sale while preserving unchanged historical descriptions', () => {
  assert.deepEqual(core.DOCUMENT_PURPOSE_OPTIONS, ['Purchase', 'Sale']);
  const legacy = { ...document, document_purpose: 'Office supplies · original description' };
  const snapshot = core.documentDetailSnapshot(legacy);
  for (const purpose of core.DOCUMENT_PURPOSE_OPTIONS) {
    assert.doesNotThrow(() => core.validateDocumentDetailEdit(legacy, { document_purpose: purpose }, snapshot, true));
  }
  assert.doesNotThrow(() => core.validateDocumentDetailEdit(legacy, { document_purpose: legacy.document_purpose, notes: 'New note' }, snapshot, true));
  for (const purpose of ['Free text', '', null, 'purchase']) {
    assert.throws(() => core.validateDocumentDetailEdit(legacy, { document_purpose: purpose }, snapshot, true), /Select Purchase or Sale/);
  }
  assert.equal(legacy.document_purpose, 'Office supplies · original description');
  const source = read('../src/components/DocumentDetailPanel.tsx');
  assert.match(source, /<EditableOptionField label="Document purpose" value=\{header.documentPurpose\} options=\{DOCUMENT_PURPOSE_OPTIONS\}/);
  assert.doesNotMatch(source, /<EditableValueField label="Document purpose"/);
});

test('Amount and Total Amount are derived from editable quantity, price, discount and VAT', () => {
  const quantity = core.recalculateDocumentLine(row, 'qty', '3', 'EUR');
  assert.equal(quantity.subtotal, '150.00'); assert.equal(quantity.total, '181.50 EUR');
  const price = core.recalculateDocumentLine(row, 'price', '75,50', 'EUR');
  assert.equal(price.subtotal, '151.00'); assert.equal(price.total, '182.71 EUR');
  const discount = core.recalculateDocumentLine(row, 'discount', '10', 'EUR');
  assert.equal(discount.subtotal, '90.00'); assert.equal(discount.total, '108.90 EUR');
  const vat = core.recalculateDocumentLine(row, 'vat', '18,75', 'EUR');
  assert.equal(vat.subtotal, '100.00'); assert.equal(vat.total, '118.75 EUR');
  assert.equal(core.documentLineNumber('-1 234,56 EUR'), -1234.56);
});

test('header VAT is editable and distributed to multiple allocations without losing a cent', () => {
  const rows = [row, { ...row, id: 'line-2' }, { ...row, id: 'line-3' }];
  const result = core.distributeDocumentVat(rows, '20.02', 'EUR');
  assert.deepEqual(result.map(line => line.vat), ['6.67 EUR', '6.68 EUR', '6.67 EUR']);
  assert.deepEqual(result.map(line => line.subtotal), ['100', '100', '100']);
  assert.equal(result.reduce((sum, line) => sum + Math.round(core.documentLineNumber(line.total) * 100), 0), 32002);
  assert.equal(rows[0].vat, '21.00 EUR');
});

test('card editing preserves access, accounting locks, organization boundaries and concurrent changes', () => {
  const snapshot = core.documentDetailSnapshot(document);
  assert.throws(() => core.validateDocumentDetailEdit(document, { notes: 'x' }, snapshot, false), /access/);
  for (const change of [{ accounting_posting: {} }, { document_storno: { mode: 'test' } }, { status: 'Approved' }, { inactive: true }]) {
    assert.throws(() => core.validateDocumentDetailEdit({ ...document, ...change }, { notes: 'x' }, snapshot, true));
  }
  assert.throws(() => core.validateDocumentDetailEdit(document, { company_id: 'other' }, snapshot, true), /cannot be changed/);
  assert.throws(() => core.validateDocumentDetailEdit({ ...document, notes: 'Another edit' }, { notes: 'x' }, snapshot, true), /changed/);
  assert.throws(() => core.validateDocumentDetailEdit(document, { status: 'Overdue' }, snapshot, true), /valid document status/);
});

function fixture() {
  const store = new Map(); let allowed = true;
  const issues = {}, storno = {}, api = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentDetailEditing') return core;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [document]); put('companies', [{ id: document.company_id, name: 'Test company' }]); put('document_history', []);
  return { ...api, get, put, revoke: () => { allowed = false; } };
}

test('card command saves corrected fields and authoritative history, without changing company master data', async () => {
  const f = fixture();
  const saved = await f.applyDocumentDetailEdit(document.id, document.company_id, { notes: 'Card note', counterparty_code: 'NEW-CODE', type: 'Sale', document_purpose: 'Sale' }, core.documentDetailSnapshot(document), 'Document: Note, Counterparty code, Type, Document purpose');
  assert.equal(saved.document.notes, 'Card note'); assert.equal(saved.document.counterparty_code, 'NEW-CODE');
  assert.equal(saved.document.document_purpose, 'Sale');
  assert.deepEqual(saved.document.summary_line_items, document.summary_line_items);
  assert.deepEqual(f.get('companies'), [{ id: document.company_id, name: 'Test company' }]);
  assert.equal(f.get('documents')[0].detail_edit_history.length, 1); assert.equal(f.get('document_history').length, 1);
  await assert.rejects(f.applyDocumentDetailEdit(document.id, document.company_id, { notes: 'Stale' }, core.documentDetailSnapshot(document), 'Updated'), /changed/);
  f.revoke();
  await assert.rejects(f.applyDocumentDetailEdit(document.id, document.company_id, { notes: 'No rights' }, core.documentDetailSnapshot(saved.document), 'Updated'), /access/);
});

test('legacy card edits cannot retain a stale responsible user ID after changing the person', async () => {
  const f = fixture(), linked = { ...document, accountable_responsible: 'First user', accountable_responsible_id: 'user-1' };
  f.put('documents', [linked]);
  const result = await f.applyDocumentDetailEdit(document.id, document.company_id, { accountable_responsible: 'Second user' }, core.documentDetailSnapshot(linked), 'Changed responsible person');
  assert.equal(result.document.accountable_responsible_id, '');
  assert.equal(result.document.accountable_responsible, 'Second user');
});

test('card keeps Amount / Total Amount static and exposes the requested header controls', () => {
  const source = read('../src/components/DocumentDetailPanel.tsx');
  for (const label of ['Status', 'Document type', 'Type', 'Document date', 'Document purpose', 'Note', 'Counterparty code', 'VAT']) {
    assert.match(source, new RegExp(`<Editable(?:Option|Value)Field\\s+label="${label}"`));
  }
  assert.match(source, /<Field label="Amount"/);
  assert.match(source, /<Field\s+label="Total Amount"/);
  assert.match(source, /<Cell value=\{line.subtotal\} width=\{90\} grey/);
  assert.match(source, /<Cell value=\{row.subtotal\} width=\{90\} grey/);
  assert.doesNotMatch(source, /<EditCell\s+value=\{(?:row|line).subtotal\}/);
  assert.match(source, /applyDocumentDetailEdit\(doc.id, doc.companyId/);
  assert.doesNotMatch(source, /code: doc.number \|\| item.code/);
});
