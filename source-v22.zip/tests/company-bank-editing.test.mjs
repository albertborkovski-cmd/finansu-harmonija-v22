import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const source = read('../src/lib/companyBankEditing.ts');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const company = { id: 'company-1', name: 'Alice Stone' };
const document = { id: 'entry-1', company_id: company.id, number: 'BANK-1', status: 'Draft', total_amount: '100.00' };
function fixture() {
  const state = { bankEdit: true, documentEdit: true, signedIn: true, error: null,
    documents: [structuredClone(document)], companies: [company], queries: [] };
  const api = {};
  const require = name => {
    if (name === './supabase') return { supabase: { from(table) {
      const filters = [];
      return { select() { return this; }, eq(key, value) { filters.push([key, value]); return this; },
        then(resolve, reject) {
          state.queries.push({ table, filters });
          return Promise.resolve({ data: structuredClone(state[table].filter(row => filters.every(([key, value]) => row[key] === value))), error: state.error }).then(resolve, reject);
        } };
    } } };
    if (name === './accessControl') return { parseSession: () => state.signedIn ? {} : null, canEditMenu: (_session, menu) => menu === 'bank' && state.bankEdit };
    if (name === './currentUser') return { AUTH_SESSION_KEY: 'session' };
    if (name === './documentEditAccess') return { canEditCompanyDocuments: target => target.id === company.id && state.documentEdit };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', compiled)(api, require, { localStorage: { getItem: () => '{}' } });
  return { state, ...api };
}

test('bank row Edit loads the latest record in the active company without changing it', async () => {
  const f = fixture(), before = structuredClone(f.state.documents);
  const actual = await f.loadCompanyBankDocument(document.id, company.id);
  assert.deepEqual(actual, document); assert.deepEqual(f.state.documents, before);
  assert.deepEqual(f.state.queries.find(query => query.table === 'documents').filters, [['id', document.id], ['company_id', company.id]]);
  f.state.documents[0].number = 'UPDATED-1';
  assert.equal((await f.loadCompanyBankDocument(document.id, company.id)).number, 'UPDATED-1');
});

test('Edit refuses missing, moved, deleted and unreadable bank entries', async () => {
  for (const mutate of [
    state => { state.documents = []; },
    state => { state.documents[0].company_id = 'other-company'; },
    state => { state.documents[0].document_deletion = { at: '2026-11-09' }; },
    state => { state.companies = []; },
    state => { state.error = new Error('unavailable'); },
  ]) {
    const f = fixture(); mutate(f.state);
    await assert.rejects(f.loadCompanyBankDocument(document.id, company.id), /no longer available/);
  }
});

test('Edit requires both Bank and underlying document rights, checked again on click', async () => {
  for (const permission of ['bankEdit', 'documentEdit', 'signedIn']) {
    const f = fixture();
    assert.equal(f.canEditCompanyBankEntries(company), true);
    f.state[permission] = false;
    assert.equal(f.canEditCompanyBankEntries(company), false);
    await assert.rejects(f.loadCompanyBankDocument(document.id, company.id), /permission/);
  }
});

test('row icons follow all data columns and open the dedicated bank transaction form', () => {
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /system-table-row-actions flex w-\[52px\]/);
  assert.match(view, /aria-label=\{`Edit bank entry/);
  assert.match(view, /<Pencil size=\{14\}/);
  assert.match(view, /border-2 border-\[#D3E1EC\] bg-white text-\[#7288A3\]/);
  assert.match(view, /onClick=\{\(\) => void openEditor\(row.documentId\)\}/);
  assert.match(view, /loadCompanyBankDocument\(documentId, company.id\)/);
  assert.match(view, /<BankTransactionEditor/);
  assert.doesNotMatch(view, /<CreateInvoiceForm|<DocumentDetailPanel/);
  assert.match(view, /onClose=\{closeEditor\}/);
  assert.match(view, /const closeEditor = \(\) => \{ setEditor\(undefined\); void loadDocuments\(\); \}/);
  assert.doesNotMatch(view, /return <BankTransactionEditor/);
});
