import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('../src/lib/documentActionHistory.ts'))(core);
const event = (id, action, at = '2026-11-09T12:00:00Z') => ({ id, action, at, actor: 'Original accountant' });
const original = { id: 'original', company_id: 'company', number: 'INV-001', status: 'Approved',
  approval_cancellation_history: [{ ...event('cancel', 'Approval cancelled', '2026-11-08T12:00:00Z'), fromStatus: 'Approved', reason: 'Correct the description' }],
  document_storno: { number: 'ST-001', history: [{ ...event('storno', 'Document Storno saved (test)', '2026-11-09T13:00:00Z'), details: 'Reason: duplicate operation' }] } };
const credit = { id: 'credit', company_id: 'company', number: 'CN-001', correction_of_document_id: 'original', correction_kind: 'Credit note',
  creation_history: [event('create', 'Invoice draft created')],
  correction_history: [{ ...event('link', 'Credit invoice linked to original document'), details: 'Original INV-001 · incorrect price' }] };
const mirror = [{ id: 'create', document_id: 'credit', original_document_id: 'original', organization_id: 'company', action: 'Invoice draft created', created_at: '2026-11-09T12:00:00Z', user_name: 'Original accountant' },
  { id: 'cancel', document_id: 'original', organization_id: 'company', action: 'Approval cancelled', created_at: '2026-11-08T12:00:00Z', user_name: 'Original accountant', details: 'Approved → Draft. Correct the description' }];

test('all lifecycle actions retain dates/users, link related documents and sort newest first', () => {
  const debit = { ...credit, id: 'debit', number: 'DN-001', correction_kind: 'Debit note', creation_history: [], correction_history: [event('debit-created', 'Debit note draft created', '2026-11-07T12:00:00Z')] };
  const deleted = { ...credit, id: 'deleted-credit', number: 'CN-002', document_deletion: { at: '2026-11-09T15:00:00Z', actor: 'Deleting accountant' } };
  const docs = [original, credit, debit, deleted], before = structuredClone(docs);
  const rows = core.buildDocumentActionHistory('original', 'company', docs, mirror);
  assert.deepEqual(docs, before, 'reading history never edits source records');
  assert.deepEqual(rows.map(row => row.action), ['Delete', 'Storno', 'Create credit note', 'Create credit note', 'Cancel approval', 'Create debit note']);
  assert.equal(rows[0].actor, 'Deleting accountant');
  assert.equal(rows[0].at, deleted.document_deletion.at);
  assert.deepEqual(rows[0].related, [{ documentId: 'deleted-credit', label: 'CN-002', kind: 'document', available: false, deleted: true }]);
  assert.equal(rows[1].related[0].label, 'ST-001');
  assert.equal(rows[1].related[0].kind, 'storno');
  const created = rows.find(row => row.documentId === 'credit');
  assert.equal(created.actor, 'Original accountant');
  assert.equal(created.related[0].documentId, 'credit');
  assert.match(created.details, /incorrect price/);
  assert.equal(rows.filter(row => row.documentId === 'credit').length, 1, 'creation, link and mirror represent one correction');
});

test('corrective-document history links back to the original without importing its unrelated events', () => {
  const rows = core.buildDocumentActionHistory('credit', 'company', [original, credit], mirror);
  assert.equal(rows.length, 1);
  assert.deepEqual(rows[0].related, [{ documentId: 'original', label: 'INV-001', kind: 'document', available: true, deleted: false }]);
});

test('Delete audit remains available on retained tombstones even when the audit mirror failed', () => {
  const deleted = { ...credit, document_deletion: { at: '2026-11-09T15:00:00Z', actor: 'Accountant B' } };
  const rows = core.buildDocumentActionHistory('credit', 'company', [original, deleted], []);
  assert.equal(rows[0].action, 'Delete');
  assert.equal(rows[0].actor, 'Accountant B');
  assert.equal(rows[0].related[0].label, original.number);
  assert.match(rows[0].details, /audit history is retained/);
});

test('company scoping excludes foreign records, forged events and foreign document names', () => {
  const foreign = { ...credit, id: 'foreign', company_id: 'elsewhere', number: 'SECRET-1' };
  const forged = { id: 'forged', document_id: 'original', organization_id: 'elsewhere', action: 'Delete' };
  const rows = core.buildDocumentActionHistory('original', 'company', [original, credit, foreign], [...mirror, forged]);
  assert.ok(rows.every(row => row.documentId !== 'foreign' && row.id !== 'forged'));
  const linked = { ...credit, correction_of_document_id: foreign.id };
  const ref = core.buildDocumentActionHistory('credit', 'company', [linked, foreign], [])[0].related[0];
  assert.equal(ref.label, 'Unavailable document'); assert.equal(ref.available, false);
  assert.deepEqual(core.buildDocumentActionHistory('original', 'elsewhere', [original], mirror), []);
});

test('unknown legacy authors are not attributed to the current viewer; old correction metadata is supported', () => {
  const legacy = { id: 'legacy', company_id: 'company', number: 'CN-OLD', correction_of_document_id: 'original', created_at: '2026-01-01T12:00:00Z', created_by: 'Earlier user' };
  const row = core.buildDocumentActionHistory('original', 'company', [original, legacy], [{ id: 'old', document_id: 'original', action: 'Updated', user_name: 'Current user' }]);
  assert.equal(row.at(-1).actor, 'Not recorded');
  assert.equal(row.find(item => item.documentId === legacy.id).actor, 'Earlier user');
  assert.equal(row.find(item => item.documentId === legacy.id).action, 'Create credit note');
});

function fixture() {
  const store = new Map(); let allowed = true, writes = 0;
  const api = {};
  const require = name => {
    if (name === './documentActionHistory') return core;
    if (name === './documentEditAccess') return { canViewCompanyDocuments: () => allowed };
    if (name === './documentIssueAccess') return { canReviewDocumentIssues: () => false, canAccessIssueOrganization: () => false };
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './currentUser') return { getCurrentUserName: () => 'Different viewer' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    return {};
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => { if (store.get(key) !== value) writes++; store.set(key, value); } }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static fixture'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  put('documents', [original, credit, { ...credit, id: 'deleted', document_deletion: { at: '2026-11-09T15:00:00Z', actor: 'Deleting user' } }, { ...credit, id: 'foreign', company_id: 'other' }, { ...original, id: 'unrelated' }]);
  put('companies', [{ id: 'company', name: 'Company' }]); put('document_history', mirror);
  return { ...api, store, writes: () => writes, revoke: () => { allowed = false; } };
}

test('history loader is read-only, includes retained deletion audits while the register excludes deleted documents', async () => {
  const f = fixture(), before = new Map(f.store);
  const rows = await f.loadDocumentActionHistory('original', 'company');
  assert.ok(rows.some(row => row.action === 'Delete'));
  assert.deepEqual(f.store, before); assert.equal(f.writes(), 0);
  const register = await f.supabase.from('documents').select('*');
  assert.ok(!register.data.some(row => row.id === 'deleted'));
});

test('related-document navigation rechecks rights, company, relation and deletion before opening View', async () => {
  const f = fixture();
  assert.equal((await f.loadHistoryRelatedDocument('original', 'credit', 'company')).id, 'credit');
  assert.equal((await f.loadHistoryRelatedDocument('credit', 'original', 'company')).id, 'original');
  for (const id of ['deleted', 'foreign', 'unrelated', 'missing']) await assert.rejects(f.loadHistoryRelatedDocument('original', id, 'company'), /unavailable/);
  f.revoke();
  await assert.rejects(f.loadHistoryRelatedDocument('original', 'credit', 'company'), /access/);
  await assert.rejects(f.loadDocumentActionHistory('original', 'company'), /access/);
});

test('both saved-document forms use the same read-only history, preserving form provenance during navigation', () => {
  const detail = read('../src/components/DocumentDetailPanel.tsx'), invoice = read('../src/components/invoices/CreateInvoiceForm.tsx');
  assert.match(detail, /<DocumentActionHistory documentId=\{doc.id\}/);
  assert.match(invoice, /documentId && <DocumentActionHistory/);
  assert.doesNotMatch(detail, /displayedHistoryUserName|currentHistoryUserName|update\(\{ user_name/);
  const component = read('../src/components/DocumentActionHistory.tsx');
  for (const heading of ['Date', 'User', 'Action', 'Details', 'Related documents']) assert.ok(component.includes(heading));
  assert.match(component, /loadHistoryRelatedDocument\(documentId, reference.documentId, companyId\)/);
  assert.match(component, /if \(unsavedChanges\)/);
  assert.match(component, /reference.deleted \? ' \(Deleted\)'/);
  assert.match(component, /<time dateTime=/);
  assert.doesNotMatch(component, /\.update\(|\.insert\(/);
  const table = read('../src/components/Documents.tsx');
  assert.equal(table.match(/onOpenRelatedDocument=\{openHistoryDocument\}/g).length, 2);
  assert.match(table, /setViewDoc\(mapRow\(document\)\)/);
});
