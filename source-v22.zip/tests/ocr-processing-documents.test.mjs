import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const helpers = {};
new Function('exports', ts.transpileModule(read('../src/lib/ocrProcessingDocuments.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText)(helpers);
const { processingColumns, processingSubtype, processingDocumentPurpose, processingDocumentNumber } = helpers;
const catalog = [
  { code: 'INVOICES', fullName: 'Invoices', parentCode: '', status: 'Active' },
  { code: 'VAT_INVOICE', fullName: 'VAT invoice', parentCode: 'INVOICES', status: 'Active' },
  { code: 'CREDIT_INVOICE', fullName: 'Credit invoice', parentCode: 'INVOICES', status: 'Active' },
  { code: 'OLD', fullName: 'Old invoice', parentCode: 'INVOICES', status: 'Inactive' },
  { code: 'CONTRACTS', fullName: 'Contracts', parentCode: '', status: 'Active' },
  { code: 'LEASE', fullName: 'Lease agreement', parentCode: 'CONTRACTS', status: 'Active' },
];

test('Processing columns migrate names and remove Invoice without losing user preferences', () => {
  const source = [
    { key: 'number', label: 'Number', width: 220, visible: false },
    { key: 'invoice', label: 'Invoice', width: 120, visible: true },
    { key: 'type', label: 'Type', width: 180, visible: true },
  ];
  const result = processingColumns(source);
  assert.deepEqual(result, [
    { key: 'number', label: 'Series / No.', width: 220, visible: false },
    { key: 'subtype', label: 'Subtype', width: 180, visible: true },
  ]);
  assert.deepEqual(processingColumns(result), result);
  assert.equal(source[1].key, 'invoice');
});

test('Subtype is taken from the correct OCR catalog group, never the Purchase/Sale field', () => {
  assert.equal(processingSubtype({ document_type: 'INVOICES', document_subtype: 'VAT_INVOICE', type: 'Purchase' }, catalog)?.fullName, 'VAT invoice');
  assert.equal(processingSubtype({ document_type: 'VAT invoice' }, catalog)?.code, 'VAT_INVOICE');
  assert.equal(processingSubtype({ document_type: 'Credit note' }, catalog)?.code, 'CREDIT_INVOICE');
  assert.equal(processingSubtype({ document_type: 'INVOICES', type: 'Purchase' }, catalog), undefined);
  assert.equal(processingSubtype({ document_type: 'CONTRACTS', document_subtype: 'LEASE' }, catalog)?.fullName, 'Lease agreement');
});

const workflow = {};
new Function('exports', ts.transpileModule(read('../src/lib/ocrDocumentWorkflow.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText)(workflow);
const { ocrDocumentStage } = workflow;

test('Processing and approval are disjoint queues with workflow-specific labels', () => {
  for (const status of ['Processing', 'In progress', 'Queued', 'Awaiting OCR']) {
    assert.equal(ocrDocumentStage({ status, source: 'Email' }).queue, 'processing');
  }
  for (const status of ['Accepted', 'Completed', 'Processed', 'Need review']) {
    assert.deepEqual(ocrDocumentStage({ status }), { queue: 'approval', status: 'Awaiting approval' });
  }
  for (const status of ['Approved', 'Transferred', 'Posted', 'Paid', 'Deleted']) assert.equal(ocrDocumentStage({ status }), null);
  assert.deepEqual(ocrDocumentStage({ status: 'Pending', source: 'Email' }), { queue: 'processing', status: 'Queued' });
  assert.equal(ocrDocumentStage({ status: 'Draft', source: 'Manual', entry_method: 'manual' }), null);
  assert.equal(ocrDocumentStage({ status: 'Accepted', entry_method: 'manual' }), null);
});

test('Saved completion moves to approval, while OCR reruns remain in processing', () => {
  const completed = { status: 'Completed', trainingStatus: 'Confirmed' };
  assert.equal(ocrDocumentStage({ status: 'Pending' }, completed).queue, 'approval');
  assert.equal(ocrDocumentStage({ status: 'Draft' }, { status: 'In Progress' }).queue, 'processing');
  assert.equal(ocrDocumentStage({ status: 'Pending' }, { teamLeadReview: { status: 'Pending' } }).queue, 'approval');
  assert.deepEqual(ocrDocumentStage({ status: 'Processing', ocr_rerun_request: { status: 'Pending integration' } }, completed), { queue: 'processing', status: 'Awaiting OCR' });
  assert.equal(ocrDocumentStage({ status: 'Accepted', digitization_issues: [{ status: 'Open' }] }, completed).status, 'Needs correction');
  assert.equal(ocrDocumentStage({ status: 'Completed', inactive: true }, completed), null);
});

test('Document purpose exposes only Purchase or Sale without overwriting legacy descriptions', () => {
  const source = { document_purpose: 'Office supplies', type: 'Purchase' };
  assert.equal(processingDocumentPurpose(source), 'Purchase');
  assert.equal(source.document_purpose, 'Office supplies');
  assert.equal(processingDocumentPurpose({ document_purpose: 'Sale', type: 'Purchase' }), 'Sale');
  assert.equal(processingDocumentPurpose({ document_purpose: 'Other', type: 'Income' }), '');
});

test('Series and number are displayed without a repeated series', () => {
  assert.equal(processingDocumentNumber({ series: 'INV', number: '001' }), 'INV / 001');
  assert.equal(processingDocumentNumber({ series: 'INV', number: 'INV-001' }), 'INV-001');
  assert.equal(processingDocumentNumber({ number: '001' }), '001');
  assert.equal(processingDocumentNumber({}), '—');
});

test('File/Case opens the exact saved document and the list remains mounted', () => {
  const source = read('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(source, /key === 'fileCase' && onViewDocument/);
  assert.match(source, /<a href=\{`#ocr-document-/);
  assert.match(source, /<div hidden=\{Boolean\(viewedDocument\)\}/);
  assert.match(source, /documentId=\{viewedDocument.reference.id\}/);
  assert.match(source, /companyId=\{viewedDocument.reference.companyId\}/);
  assert.match(source, /loadSavedReviewDocumentTask\(reference, localStorage\)/);
  assert.match(source, /\n\s+readOnly\n/);
  assert.doesNotMatch(source, /SearchableSelect|applyDocumentDetailEdit|saveClassification/);
});

test('Processing documents is consistent in OCR navigation and heading', () => {
  for (const file of ['../src/components/Sidebar.tsx', '../src/lib/accessControl.ts']) {
    assert.match(read(file), /id: ["']ocr-all-documents-processed["'], label: ["']Processing documents["']/);
  }
  assert.match(read('../src/components/OcrProcessedDocumentsView.tsx'), /title="Processing documents"/);
});
