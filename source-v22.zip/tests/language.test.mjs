import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import ts from 'typescript';

const source = file => readFileSync(new URL(`../src/${file}`, import.meta.url), 'utf8');
function loadLanguage(initial = 'en', blockedStorage = false) {
  const data = new Map([['finansu-harmonija:language', initial], ['documents', '[{"status":"Approved"}]']]);
  const writes = [], events = {};
  const window = { localStorage: {
    getItem: key => { if (blockedStorage) throw Error('Blocked'); return data.get(key) ?? null; },
    setItem: (key, value) => { if (blockedStorage) throw Error('Blocked'); writes.push([key, value]); data.set(key, value); },
  }, addEventListener: (name, callback) => { events[name] = callback; } };
  const document = { documentElement: { lang: '' } };
  const compile = (file, require = () => { throw Error('Unexpected dependency'); }) => {
    const exports = {};
    new Function('require', 'exports', 'window', 'document', ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(require, exports, window, document);
    return exports;
  };
  const lt = compile('i18n/lt.ts'), extra = compile('i18n/lt-interface.ts'), company = compile('i18n/lt-company.ts');
  const api = compile('i18n/language.ts', name => name === './lt' ? lt : name === './lt-interface' ? extra : name === './lt-company' ? company : name === 'react' ? { useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot() } : assert.fail(name));
  const reconciliation = compile('i18n/reconciliation.ts', name => name === './language' ? api : assert.fail(name));
  const warehouse = compile('i18n/warehouse.ts', name => name === './language' ? api : assert.fail(name));
  return { ...api, ...reconciliation, ...warehouse, data, writes, events, document };
}

test('dashboard upload, summary cards and company action labels have Lithuanian translations', () => {
  const { translateUi: t } = loadLanguage('lt');
  const labels = {
    'Uploading documents': 'Dokumentų įkėlimas',
    'Or email documents to:': 'Arba siųskite dokumentus el. paštu:',
    'Currently being processed': 'Šiuo metu apdorojama',
    'Processed': 'Apdorota', 'Successfully processed': 'Sėkmingai apdorota',
    'Needs attention': 'Reikia dėmesio', 'View all documents': 'Rodyti visus dokumentus',
    'Based on current documents': 'Pagal esamus dokumentus', 'Open company': 'Atidaryti įmonę',
  };
  for (const [en, lt] of Object.entries(labels)) { assert.equal(t(en), lt); assert.equal(t(en, 'en'), en); }
  for (const label of ['Action required', 'Status', 'Save', 'Cancel', 'Column settings', 'Add filters']) assert.notEqual(t(label), label);
  assert.equal(t('4. Accounting defaults'), '4. Numatytieji apskaitos nustatymai');
});

test('status labels are separate from actions, preserve custom values and never mutate stored data', () => {
  const { translateUi: t, translateStatus: status, translateFieldValue: field, data } = loadLanguage('lt');
  assert.equal(t('Open'), 'Atidaryti'); assert.equal(status('Open'), 'Atvira');
  assert.equal(status('Duplicate'), 'Dublikatas');
  for (const value of ['New', 'Pending', 'Processing', 'Approved', 'Active', 'Resolved', 'Matched', 'Blocked', 'Transferred', 'Corrected']) assert.notEqual(status(value), value);
  assert.equal(field('company_status', 'Active'), 'Aktyvi');
  assert.equal(field('fullName', 'Open'), 'Open');
  assert.equal(status('Special customer workflow'), 'Special customer workflow');
  assert.equal(t('Alice Stone'), 'Alice Stone');
  assert.equal(data.get('documents'), '[{"status":"Approved"}]');
});

test('language preference persists independently and round-trips without record writes', () => {
  const app = loadLanguage();
  app.setLanguage('lt'); assert.equal(app.getLanguage(), 'lt'); assert.equal(app.document.documentElement.lang, 'lt');
  app.setLanguage('en'); assert.equal(app.translateUi('Open company'), 'Open company');
  app.setLanguage('xx'); assert.equal(app.getLanguage(), 'en');
  assert.ok(app.writes.every(([key]) => key === app.LANGUAGE_STORAGE_KEY));
  app.data.set(app.LANGUAGE_STORAGE_KEY, 'lt'); app.events.storage({ key: app.LANGUAGE_STORAGE_KEY });
  assert.equal(app.getLanguage(), 'lt');
  const blocked = loadLanguage('en', true); blocked.setLanguage('lt'); assert.equal(blocked.getLanguage(), 'lt');
});

test('render boundaries translate statuses and filters without translating select values', () => {
  assert.match(source('components/DashboardView.tsx'), /uiText\(item\.description\)/);
  assert.match(source('components/Documents.tsx'), /statusText\(documentStatusLabel/);
  assert.match(source('components/Documents.tsx'), /statusText\(label\)/);
  assert.match(source('components/SystemAddFilters.tsx'), /translateFieldValue\(column\.key/);
  assert.match(source('components/SearchableSelect.tsx'), /onChange\(option\.value\)/);
  assert.match(source('components/SearchableSelect.tsx'), /localizeOptions = false/);
  assert.match(source('components/SearchableSelect.tsx'), /normalizedOptions, query, localizeOptions, language/);
  assert.doesNotMatch(source('App.tsx'), /<AppContent\s+key=/);
});

test('company overview translates every chart, VAT label, month and helper', () => {
  const { translateUi: t } = loadLanguage('lt');
  for (const label of ['Pay tax date', 'Pay for the service', 'Tax period:', 'VAT payable', 'VAT deductible', 'VAT to pay', 'days left', 'Income & Expenses', 'Payment structure', 'Show only personal amount', 'Pending payments', 'Overdue payments', 'For months', 'In quarters', 'Net revenue', 'Expense analysis', 'Awaiting confirmation from the tax authority', 'total', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']) {
    assert.notEqual(t(label), label, label);
    assert.equal(t(label, 'en'), label);
  }
  const dashboard = source('components/DashboardView.tsx');
  for (const boundary of ['uiText(centerSub)', 'uiText(m)', 'uiText(activeMonth)', 'uiText(row.label)', 'uiText(selectedAnalyticsTitle)', "statusText(document.status || 'Submitted')"]) assert.ok(dashboard.includes(boundary), boundary);
  assert.match(dashboard, /active=\{activeMonth\}/);
  assert.match(dashboard, /key=\{m\}/);
  assert.doesNotMatch(dashboard, /(?:key|active|value)=\{uiText\(/);
});

test('reconciliation localizes enums and notices but preserves document and payment data', () => {
  const app = loadLanguage('lt');
  const { translateUi: t, translateStatus: status, reconciliationValueText: value, translateMessage: message } = app;
  for (const label of ['All items', 'Reconciled', 'Suggestions & open items', 'Accounting operations', 'Advances & deposits', 'Cash transactions', 'Missing document', 'History', 'Auto match', 'Matching rules', 'Payment date', 'Debit in currency', 'Credit in currency', 'Balance in currency', 'Counterparty assignment', 'Match amount', 'Reconcile · Select records', 'Reconcile selected', 'Only opposite GL entries are listed. Clear the Counterparty filter to include other counterparties. Select multiple records and adjust To match amounts as needed.']) {
    assert.notEqual(t(label), label, label);
    assert.equal(t(label, 'en'), label);
  }
  assert.equal(status('Reconciled'), 'Sudengta');
  assert.equal(t('Reconciled'), 'Sudengti įrašai');
  assert.equal(value('kind', 'Sales invoice'), 'Pardavimo sąskaita');
  assert.equal(value('glEntry', 'Debit'), 'Debetas');
  assert.equal(value('glEntry', 'INV-001: Debit · PAY-002: Credit'), 'INV-001: Debetas · PAY-002: Kreditas');
  assert.equal(value('category', 'Bank fees'), 'Banko mokesčiai');
  for (const field of ['counterparty', 'documentNumber', 'paymentPurpose', 'reference', 'actor', 'glAccount']) assert.equal(value(field, 'Sales invoice'), 'Sales invoice', field);
  assert.equal(message('A balance of {amount} {currency} will remain open.', { amount: '123.45', currency: 'EUR' }), 'Nesudengtas likutis bus 123.45 EUR.');
  assert.equal(message('View document {document}', { document: '$&' }), 'View document $&');
  app.setLanguage('en');
  assert.equal(value('kind', 'Sales invoice'), 'Sales invoice');
  assert.equal(message('A balance of {amount} {currency} will remain open.', { amount: '123.45', currency: 'EUR' }), 'A balance of 123.45 EUR will remain open.');
  assert.equal(app.data.get('documents'), '[{"status":"Approved"}]');
});

test('reconciliation render and filter boundaries use localized labels without replacing stable keys', () => {
  const main = source('components/CompanyReconciliationView.tsx');
  assert.match(main, /uiText\('Suggestions & open items'\) : uiText\(name\)/);
  assert.match(main, /setTab\(name\)/);
  assert.match(main, /uiText\(filter\)/);
  assert.match(main, /uiText\(proposal\.confidence\)/);
  const table = source('components/ReconciliationTable.tsx');
  assert.match(table, /reconciliationValueText\(key, String\(value\)\)/);
  assert.match(table, /optionLabels: Object\.fromEntries/);
  assert.match(table, /filterValues\[key\]\.includes\(filterValue\(row, key\)\)/);
  assert.match(table, /\[columns, rows, language\]/);
  assert.match(source('components/ReconciliationMatchDialog.tsx'), /uiText\(confirmLabel\)/);
  assert.match(source('components/ReconciliationDialogs.tsx'), /uiText\(option\.description\)/);
});

test('warehouse stock labels, choices and validation messages translate without changing record values', () => {
  const app = loadLanguage('lt');
  for (const label of ['Stock balances', 'Items & services', 'Item / service', 'New item / service', 'Unit cost EUR', 'Stock balance', 'Stock value EUR', 'Sale price EUR', 'Minimum stock', 'Sales GL account', 'Cost GL account', 'Item type', 'VAT rate %', 'Revalue prices', 'Fixed price', 'Markup on cost', 'Adjust base price', 'Code, name and unit are required.', 'Item code already exists.', 'Record saved.', 'Sales returns']) {
    assert.notEqual(app.translateUi(label), label, label);
    assert.equal(app.translateUi(label, 'en'), label);
  }
  assert.equal(app.warehouseValueText('status', 'In stock'), 'Yra atsargų');
  assert.equal(app.warehouseValueText('status', 'Low stock'), 'Mažai atsargų');
  assert.equal(app.warehouseValueText('type', 'Service'), 'Paslauga');
  assert.equal(app.warehouseValueText('unit', 'pcs'), 'vnt.');
  assert.equal(app.warehouseValueText('unit', 'hour'), 'val.');
  for (const field of ['name', 'code', 'warehouse', 'counterparty', 'group', 'barcode']) {
    assert.equal(app.warehouseValueText(field, 'Service'), 'Service', field);
  }
  app.setLanguage('en');
  assert.equal(app.warehouseValueText('unit', 'pcs'), 'pcs');
  assert.equal(app.warehouseValueText('status', 'In stock'), 'In stock');
  assert.equal(app.data.get('documents'), '[{"status":"Approved"}]');
  const table = source('components/WarehouseTable.tsx');
  assert.match(table, /optionLabels: Object\.fromEntries/);
  assert.match(table, /values\[key\]\.includes\(String\(row\[key\]/);
  assert.match(table, /\[defaults, rows, valueLabel, language\]/);
  const editor = source('components/WarehouseMasterEditor.tsx');
  assert.match(editor, /value: option, label: warehouseValueText\(field.key, option\)/);
});

test('ADDINFO shortcut help is translated and retains both keyboard combinations', () => {
  const text = 'On the company Dashboard or All documents, press Alt + P (Option ⌥ + P on Mac) while no text field is focused to open the ADDINFO form and manually enter additional information.';
  const { translateUi: t } = loadLanguage('lt');
  assert.match(t(text), /^Įmonės „Apžvalgos“ arba „Visų dokumentų“ lange/);
  for (const token of ['Alt + P', 'Option ⌥ + P', 'ADDINFO']) assert.ok(t(text).includes(token));
  assert.equal(t(text, 'en'), text);
  assert.ok(source('components/Documents.tsx').includes(`uiText("${text}")`));
});
