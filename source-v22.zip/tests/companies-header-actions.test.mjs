import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const source = readFileSync(new URL('../src/components/Companies.tsx', import.meta.url), 'utf8');

test('Companies restores the scoped bulk-actions menu with all three existing actions', () => {
  assert.match(source, /entityLabel === "company" && dataSource === "companies"/);
  assert.match(source, /\['Assign accountant', 'Replace accountant', 'Set substitution'\]/);
  assert.match(source, /ariaLabel="Bulk actions" ariaHasPopup="menu" ariaExpanded=\{bulkActionsOpen\}/);
  assert.match(source, /disabled=\{selectedCompanyCount === 0 \|\| availableBulkActions.length === 0\}/);
  assert.match(source, /useDropdownDismiss\(bulkActionsOpen, bulkActionsRef/);
  assert.match(source, /<GlJournalDialog title=\{selectedBulkAction\}/);
});

test('Companies retains creation, filtering, selection and existing accountant information', () => {
  for (const marker of ['<PageHeader', '<PageActionButton', 'canCreateOrganization', 'selectedCompanyIds', 'allCompaniesSelected', 'assignedAccountantFilter', 'organizationAccountantNames', 'selectCompanySubstitutions', 'useOrganizationAccessRevision();']) {
    assert.ok(source.includes(marker), `Missing preserved functionality: ${marker}`);
  }
  assert.match(source, /selectedCompanyCount = companies\.filter\(\(row\) => selectedCompanyIds\.has\(row\.id\)\)\.length/);
});

test('bulk operations recheck permission on confirmation and use the existing persistence helpers', () => {
  const dialog = source.slice(source.indexOf('{selectedBulkAction && canManageAccountants'), source.indexOf('{/* Content */}'));
  for (const helper of ['addAccountantToOrganizations', 'replaceAccountantInOrganizations', 'setOrganizationSubstitution']) {
    assert.ok(source.includes(`${helper}(`), `Missing bulk operation: ${helper}`);
  }
  assert.equal((dialog.match(/const currentSession = parseSession\(window\.localStorage\.getItem\(AUTH_SESSION_KEY\)\);/g) || []).length, 3);
  assert.equal((dialog.match(/!currentSession \|\| !canEditMenu\(currentSession, 'dashboard'\)/g) || []).length, 3);
  assert.match(source, /initialBulkAccountantIds\.filter\(\(id\) => !bulkAccountantIds\.includes\(id\)\)/);
  assert.match(source, /setOrganizationSubstitution\(substituteId, substitutionFrom, substitutionTo, companies\.filter\(row => selectedCompanyIds\.has\(row\.id\)\), editingSubstitutionIds\)/);
});

test('bulk-action controls keep stable user IDs and support Lithuanian labels', () => {
  assert.match(source, /key=\{option\.id\}/);
  assert.match(source, /role="option" aria-selected=\{value\.includes\(option\.id\)\} data-static-selection/);
  assert.match(source, /\{uiText\("Bulk actions"\)\}/);
  assert.match(source, /\{uiText\(action\)\}/);
  const translations = readFileSync(new URL('../src/i18n/lt-interface.ts', import.meta.url), 'utf8');
  for (const label of ['Bulk actions', 'Assign accountant', 'Replace accountant', 'Set substitution']) {
    assert.ok(translations.includes(`"${label}":`), `Missing Lithuanian translation: ${label}`);
  }
});
