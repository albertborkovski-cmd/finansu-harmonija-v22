import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const load = name => {
  const result = {};
  new Function('exports', ts.transpileModule(readFileSync(new URL(`../src/lib/${name}.ts`, import.meta.url), 'utf8'), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText)(result);
  return result;
};
const { buildReviewAnalytics, reviewAnalyticsColumns } = load('ocrReviewAnalytics');
const { requestTeamLeadReview, updateTeamLeadReview } = load('ocrTeamLeadReview');
const users = [{ id: 'a', fullName: 'Same Name', email: 'a@example.test' }, { id: 'b', fullName: 'Same Name', email: 'b@example.test' }];
test('migrates saved columns without Email, preserving sizes and adding both counts', () => {
  const columns = reviewAnalyticsColumns([{ key: 'email', width: 200, visible: true }, { key: 'employee', width: 300, visible: true }]);
  assert.ok(!columns.some(c => c.key === 'email'));
  assert.equal(columns[0].width, 300);
  assert.ok(columns.find(c => c.key === 'teamLeadReferrals')?.visible);
  assert.ok(columns.find(c => c.key === 'assignedIssues')?.visible);
  assert.deepEqual(reviewAnalyticsColumns(columns), columns);
});
test('counts referrals, deduplicates queue snapshots and counts assigned issue documents once', () => {
  const review = { requestedAt: '2026-11-13T10:00:00Z', requestedBy: 'Same Name', requestedByEmail: 'a@example.test', status: 'Approved' };
  const docs = [{ id: 'd1', status: 'Approved', company_id: 'c', digitization_issues: [
    { assignedToEmail: 'a@example.test', status: 'Resolved' }, { assignedToEmail: 'a@example.test', status: 'Open' },
    { createdBy: 'b@example.test', status: 'Open' },
  ] }, { id: 'd2', status: 'Pending', digitization_issues: [{ assignedToEmail: 'b@example.test' }] }];
  const tasks = new Map([['d1', { assignedToEmail: 'a@example.test', teamLeadReview: review, teamLeadReviewHistory: [review, { ...review, requestedAt: '2026-11-12T10:00:00Z' }] }]]);
  const before = JSON.stringify(docs);
  const rows = buildReviewAnalytics(docs, [{ id: 'c', name: 'Alice Stone' }], users, { d1: { seconds: 120 } }, tasks);
  const a = rows.find(row => row.id === 'user:a'), b = rows.find(row => row.id === 'user:b');
  assert.equal(a.teamLeadReferrals, 2);
  assert.equal(a.assignedIssues, 1);
  assert.equal(a.approved, 1);
  assert.equal(a.totalSeconds, 120);
  assert.equal(b.teamLeadReferrals, 0);
  assert.equal(b.assignedIssues, 1);
  assert.equal(JSON.stringify(docs), before);
});
test('a second TeamLead hand-off retains the first referral after approval', () => {
  const initial = { id: 'task', comments: [] };
  const actor = { fullName: 'Worker', email: 'worker@example.test' };
  const first = requestTeamLeadReview(initial, 'Check number', actor, '2026-11-12T10:00:00Z');
  const approved = updateTeamLeadReview({ ...first, status: 'Completed' });
  const second = requestTeamLeadReview(approved, 'Check amount', actor, '2026-11-13T10:00:00Z');
  assert.equal(second.teamLeadReviewHistory.length, 2);
  assert.equal(second.teamLeadReviewHistory[0].status, 'Approved');
});
