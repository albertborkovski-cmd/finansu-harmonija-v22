import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
function load(file, dependencies = {}, globals = {}) {
  const api = {};
  const js = ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', ...Object.keys(globals), js)(api, name => {
    if (!(name in dependencies)) throw new Error(`Unexpected dependency ${name}`);
    return dependencies[name];
  }, ...Object.values(globals));
  return api;
}
const core = load('../src/lib/financialStatementArticles.ts');
const accounts = [{ code: '11', name: 'Intangible assets' }, { code: '1110', name: 'Development costs', parentCode: '11' }, { code: '1118', name: 'Development costs amortisation', parentCode: '11' }, { code: '2710', name: 'Bank account' }, { code: '4431', name: 'Trade payables' }, { code: 'custom', name: 'Please classify manually' }];
const initial = () => core.newStatementStore('alice', 'Standard');
let id = 0;
const run = (state, command, chart = accounts) => core.changeStatementStore(state, command, chart, 'accountant@example.test', '2026-11-05T10:00:00Z', () => `id-${++id}`);
const link = (code = '1110', articleId = 'statement-A-1.1', operation = 'Debit') => ({ type: 'assign', links: [{ accountCode: code, articleId, operation }] });

test('starter items have unique codes, two reports and isolated mutable company copies', () => {
  const a = initial(), b = core.newStatementStore('bob', 'Custom');
  assert.ok(a.articles.length > 40);
  assert.equal(new Set(a.articles.map(item => item.code)).size, a.articles.length);
  assert.deepEqual([...new Set(a.articles.map(item => item.report))], ['Balance sheet', 'Profit and loss']);
  a.articles[0].name = 'Changed';
  assert.notEqual(b.articles[0].name, 'Changed');
  assert.notEqual(core.statementStorageKey('alice', 'Standard'), core.statementStorageKey('bob', 'Standard'));
  assert.notEqual(core.statementStorageKey('alice', 'Standard'), core.statementStorageKey('alice', 'Custom'));
});
test('mapping multiple accounts is atomic, persists operation and audit, and never mutates the chart', () => {
  const before = initial(), snapshot = JSON.stringify(accounts);
  const result = run(before, { type: 'assign', links: [...link().links, ...link('1118').links] });
  assert.equal(before.mappings.length, 0); assert.equal(result.mappings.length, 2);
  assert.equal(result.revision, 1); assert.equal(result.audit.length, 2);
  assert.equal(result.mappings[0].operation, 'Debit');
  assert.equal(result.audit[0].by, 'accountant@example.test');
  assert.equal(JSON.stringify(accounts), snapshot);
  assert.deepEqual(core.parseStatementStore(JSON.stringify(result), 'alice', 'Standard'), JSON.parse(JSON.stringify(result)));
});
test('inactive, missing and parent accounts are rejected; invalid batches save nothing', () => {
  for (const code of ['11', 'missing']) assert.throws(() => run(initial(), link(code)), /unavailable|parent/);
  const start = initial(); start.articles[0].inactive = true;
  assert.throws(() => run(start, link()), /active/);
  assert.throws(() => run(initial(), link('1110', 'missing')), /active/);
  assert.throws(() => run(initial(), link('1110', 'statement-A-1.1', 'Other')), /Debit or Credit/);
  const before = initial();
  assert.throws(() => run(before, { type: 'assign', links: [...link().links, ...link('missing').links] }));
  assert.equal(before.mappings.length, 0); assert.equal(before.audit.length, 0);
});
test('each account maps once per report, and editing never silently overwrites another mapping', () => {
  const a = run(initial(), link());
  assert.throws(() => run(a, link()), /already has a mapping/);
  assert.throws(() => run(a, link('1110', 'statement-A-1.2')), /already has a mapping/);
  const b = run(a, link('1110', 'statement-PL-3'));
  assert.equal(b.mappings.length, 2);
  assert.throws(() => run(b, { type: 'edit-mapping', mappingId: b.mappings[1].id, articleId: 'statement-A-1.2', operation: 'Credit' }), /already has a mapping/);
  const edited = run(a, { type: 'edit-mapping', mappingId: a.mappings[0].id, articleId: 'statement-A-1.2', operation: 'Credit' });
  assert.equal(edited.mappings[0].articleId, 'statement-A-1.2');
  assert.equal(edited.mappings[0].operation, 'Credit');
  assert.ok(edited.audit.some(item => item.action === 'Mapping changed'));
});
test('unlink keeps audit and restores availability; linked and historically used items deactivate', () => {
  const linked = run(initial(), link());
  const inactive = run(linked, { type: 'remove-article', articleId: 'statement-A-1.1' });
  assert.equal(inactive.articles[0].inactive, true); assert.equal(inactive.mappings.length, 1);
  const unlinked = run(linked, { type: 'unlink', mappingIds: [linked.mappings[0].id] });
  assert.equal(unlinked.mappings.length, 0); assert.equal(unlinked.audit.length, 2);
  assert.equal(core.statementArticleUsed(unlinked, 'statement-A-1.1'), true);
  assert.equal(run(unlinked, { type: 'remove-article', articleId: 'statement-A-1.1' }).articles[0].inactive, true);
  assert.equal(run(unlinked, link()).mappings.length, 1);
  const unused = run(initial(), { type: 'remove-article', articleId: 'statement-A-1.1' });
  assert.ok(!unused.articles.some(item => item.id === 'statement-A-1.1'));
  assert.equal(run(initial(), { type: 'remove-article', articleId: 'statement-A-1.1', linked: true }).articles[0].inactive, true);
});
test('custom items validate required fields and codes; used report cannot change, reactivation preserves mappings', () => {
  const a = initial(), article = { ...a.articles[0], id: 'custom-item', code: 'CUSTOM-1', name: 'My item' };
  const created = run(a, { type: 'save-article', article });
  assert.ok(created.articles.some(item => item.id === article.id));
  assert.throws(() => run(created, { type: 'save-article', article: { ...article, id: 'another' } }), /already exists/);
  assert.throws(() => run(a, { type: 'save-article', article: { ...article, name: ' ' } }), /Enter/);
  const used = run(a, link());
  assert.throws(() => run(used, { type: 'save-article', article: { ...used.articles[0], report: 'Profit and loss' } }), /cannot be changed/);
  const inactive = run(used, { type: 'remove-article', articleId: 'statement-A-1.1' });
  const restored = run(inactive, { type: 'save-article', article: { ...inactive.articles[0], inactive: false } });
  assert.equal(restored.mappings.length, 1); assert.equal(restored.articles[0].inactive, false);
});
test('name-based suggestions are review-only, skip existing/ambiguous accounts and do not rely on code', () => {
  const a = initial(), snapshot = JSON.stringify(a);
  const suggestions = core.suggestStatementMappings(a, [...accounts, { code: '1130', name: 'Completely unrelated' }, { code: 'X-1', name: 'Software' }, { code: 'mixed', name: 'Software and development costs' }], 'Balance sheet');
  assert.ok(suggestions.some(s => s.accountCode === 'X-1' && s.articleId === 'statement-A-1.3'));
  assert.ok(!suggestions.some(s => ['11', '1130', 'custom', 'mixed'].includes(s.accountCode)));
  assert.equal(JSON.stringify(a), snapshot);
  const linked = run(a, link());
  assert.ok(!core.suggestStatementMappings(linked, accounts, 'Balance sheet').some(s => s.accountCode === '1110'));
  const noMatch = core.suggestStatementMappings(a, [{ code: 'XYZ', name: 'Unknown account' }], 'Balance sheet');
  assert.deepEqual(noMatch, []);
});
test('corrupt storage, mismatched scopes, duplicate mappings and orphan links fail closed', () => {
  for (const raw of ['{', '{}', JSON.stringify({ ...initial(), companyId: 'bob' }), JSON.stringify({ ...initial(), template: 'Other' })]) assert.throws(() => core.parseStatementStore(raw, 'alice', 'Standard'));
  const linked = run(initial(), link());
  linked.mappings.push({ ...linked.mappings[0], id: 'duplicate' });
  assert.throws(() => core.parseStatementStore(JSON.stringify(linked), 'alice', 'Standard'), /more than once/);
  linked.mappings = [{ ...linked.mappings[0], articleId: 'missing' }];
  assert.throws(() => core.parseStatementStore(JSON.stringify(linked), 'alice', 'Standard'));
});
test('export includes mapped report fields and neutralizes spreadsheet formulas', () => {
  const state = run(initial(), link(), accounts.map(a => a.code === '1110' ? { ...a, name: '=DANGEROUS()' } : a));
  const csv = core.statementMappingsCsv(state);
  assert.ok(csv.includes('"Financial statement item"')); assert.ok(csv.includes('"A-1.1"')); assert.ok(csv.includes('"Debit"'));
  assert.ok(csv.includes('"\'=DANGEROUS()"'));
});

function fixture() {
  const values = new Map(), events = [];
  const company = { id: 'alice', name: 'Alice Stone', general_ledger: 'Standard' };
  let freshCompany = { ...company }, view = true, edit = true, access = true, chart = accounts;
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  const api = load('../src/lib/financialStatementStore.ts', {
    './accessControl': { canEditMenu: () => edit, canViewMenu: () => view, parseSession: () => ({ email: 'test@example.test' }) },
    './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserIdentity: () => ({ email: 'test@example.test', fullName: 'Tester' }) },
    './linkedSettingsData': { canAccessAssignedOrganization: () => access },
    './recordLifecycle': { isRecordLinked: () => false },
    './supabase': { supabase: { from: () => ({ select: () => ({ eq: async () => ({ data: freshCompany ? [freshCompany] : [], error: null }) }) }) } },
    '../components/GeneralLedgerView': { loadCompanyGeneralLedgerAccountHierarchy: () => chart, loadGeneralLedgerTemplates: () => [{ name: 'Standard' }] },
    './financialStatementArticles': core,
  }, { localStorage: storage, window: { dispatchEvent: event => events.push(event) }, CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } }, crypto: { randomUUID: () => `saved-${++id}` } });
  return { ...api, company, values, events, setRights: (v, e, a = true) => { view = v; edit = e; access = a; }, fresh: value => { freshCompany = value; }, chart: value => { chart = value; } };
}
test('store writes only company/template-scoped mapping data, persists reload and detects concurrent edits', async () => {
  const f = fixture(); assert.equal(f.values.size, 0);
  assert.equal(f.loadStatementStore(f.company).revision, 0); assert.equal(f.values.size, 0);
  await f.updateStatementStore(f.company, 0, link());
  assert.deepEqual([...f.values.keys()], [core.statementStorageKey('alice', 'Standard')]);
  assert.equal(f.loadStatementStore(f.company).mappings.length, 1); assert.equal(f.events.length, 1);
  await assert.rejects(() => f.updateStatementStore(f.company, 0, link('1118')), /another window/);
  assert.equal(f.loadStatementStore(f.company).mappings.length, 1);
});
test('mutations recheck rights, company template and active accounts at action time', async () => {
  for (const rights of [[true, false], [false, true], [true, true, false]]) {
    const f = fixture(); f.setRights(...rights);
    await assert.rejects(() => f.updateStatementStore(f.company, 0, link()), /permission/); assert.equal(f.values.size, 0);
  }
  const changed = fixture(); changed.fresh({ ...changed.company, general_ledger: 'Different' });
  await assert.rejects(() => changed.updateStatementStore(changed.company, 0, link()), /chart has changed/);
  const missing = fixture(); missing.fresh(null);
  await assert.rejects(() => missing.updateStatementStore(missing.company, 0, link()), /no longer/);
  const inactive = fixture(); inactive.chart(accounts.filter(a => a.code !== '1110'));
  await assert.rejects(() => inactive.updateStatementStore(inactive.company, 0, link()), /unavailable/);
  assert.equal(inactive.values.size, 0);
  const unavailable = fixture(); const company = { ...unavailable.company, general_ledger: 'Removed chart' }; unavailable.fresh(company);
  await assert.rejects(() => unavailable.updateStatementStore(company, 0, link()), /assigned chart is unavailable/);
  assert.equal(unavailable.values.size, 0);
});
test('UI uses the system menu, table design, stable filtered selection and review-before-apply suggestions', () => {
  const ui = read('../src/components/FinancialStatementItemsView.tsx'), detail = read('../src/components/CompanyDetail.tsx');
  assert.match(detail, /id: 'financial-statement-items', label: 'Financial statement items'/);
  assert.match(detail, /<FinancialStatementItemsView key=\{`\$\{currentCompany.id\}:\$\{currentCompany.general_ledger/);
  for (const component of ['PageHeader', 'CompanyBreadcrumb', 'SearchableSelect', 'SystemAddFilters', 'ColumnSettingsPanel', 'HorizontalTableScrollbar', 'WorkspaceExpandButton', 'ColumnSortButton']) assert.ok(ui.includes(`<${component}`), component);
  assert.match(ui, /toggleFilteredSelection\(selected, filtered.map\(row => row.id\)\)/);
  assert.match(ui, /const eligibleSelected = rows.filter\(row => selected.has\(row.id\)\)/);
  assert.match(ui, /useWorkspaceExpansion\(expanded, root, setExpanded\)/);
  assert.match(ui, /Review suggested mappings/); assert.match(ui, /Apply selected/);
  assert.match(ui, /system-table-row-actions/);
  assert.match(ui, /financial-statement-layout/);
  assert.match(read('../src/index.css'), /\.financial-statement-layout\[data-expanded-table-path\]\s*\{\s*display: grid !important/);
  assert.doesNotMatch(ui, /createJournal|createInvoice|\.from\('documents'\).*update/);
});
