import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = value => ts.transpileModule(value, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const load = file => {
  const result = {};
  new Function('exports', 'require', compile(source(file)))(result, name => {
    if (name === './documentIssues') return load('../src/lib/documentIssues.ts');
    if (name === './ocrProcessingDocuments') return load('../src/lib/ocrProcessingDocuments.ts');
    if (name === './ocrTeamLeadReview') return load('../src/lib/ocrTeamLeadReview.ts');
    throw new Error(`Unexpected import: ${name}`);
  });
  return result;
};
const { documentIssueRows, filterDocumentIssueRows } = load('../src/lib/documentIssueTable.ts');
const { REVIEW_COLUMNS } = load('../src/lib/ocrDocumentColumns.ts');
const queue = source('../src/components/DocumentIssueQueue.tsx');
const issues = [
  { id: 'i1', message: 'Verify supplier code', status: 'Open', createdBy: 'Accountant', createdAt: '2026-11-04T09:00:00Z' },
  { id: 'i2', message: 'Correct the invoice date', status: 'Resolved', createdBy: 'Reviewer', createdAt: '2026-11-03T09:00:00Z', resolution: 'Date corrected' },
];
const document = extra => ({ id: 'd1', company_id: 'c1', number: 'INV-1', status: 'Correcting', document_type: 'INVOICES',
  counterparty_id: 'internal-id', counterparty_code: '123456789', client_counterparty: 'Supplier', total_amount: '0.00', currency: 'USD',
  accountable_responsible: 'Accountant', notes: 'Original document note', digitization_issues: issues, ...extra });
const companies = new Map([['c1', 'Alice Stone']]);

test('all shared OCR columns and additional correction fields are visible and mapped', () => {
  const tree = ts.createSourceFile('queue.tsx', queue, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const declaration = tree.statements.flatMap(statement => ts.isVariableStatement(statement) ? [...statement.declarationList.declarations] : [])
    .find(node => node.name.getText(tree) === 'COLUMNS');
  const columns = new Function('REVIEW_COLUMNS', compile('const columns = ' + declaration.initializer.getText(tree) + ';\nreturn columns;'))(REVIEW_COLUMNS);
  assert.equal(new Set(columns.map(column => column.key)).size, columns.length);
  assert.ok(columns.every(column => column.visible));
  assert.ok(REVIEW_COLUMNS.every(column => columns.some(candidate => candidate.key === column.key)));
  const row = documentIssueRows([document()], companies)[0];
  for (const column of columns) assert.equal(typeof row.cells[column.key], 'string', column.key);
  assert.deepEqual(columns.slice(0, 4).map(column => column.key), ['number', 'organization', 'reportedIssue', 'issueStatus']);
});

test('one row per report preserves exact document identity, note, issue state and zero amounts', () => {
  const original = document();
  const snapshot = JSON.stringify(original);
  const rows = documentIssueRows([original, document({ id: 'no-issues', digitization_issues: [] })], companies);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map(row => row.id), ['d1:i1', 'd1:i2']);
  assert.equal(rows[0].document, original);
  assert.equal(rows[0].issue, issues[0]);
  assert.equal(rows[0].cells.status, 'Correcting');
  assert.equal(rows[0].cells.issueStatus, 'Open');
  assert.equal(rows[0].cells.organization, 'Alice Stone');
  assert.equal(rows[0].cells.counterpartyCode, '123456789');
  assert.equal(rows[0].cells.totalAmount, '0.00');
  assert.equal(rows[0].cells.note, 'Original document note');
  assert.equal(rows[0].cells.reportedIssue, 'Verify supplier code');
  assert.equal(rows[1].cells.resolution, 'Date corrected');
  assert.equal(JSON.stringify(original), snapshot);
  assert.equal(documentIssueRows([document({ counterparty_code: '' })], companies)[0].cells.counterpartyCode, '—');
});

test('accounting columns show every Summary allocation rather than misleading document defaults or OCR lines', () => {
  const rows = documentIssueRows([document({ expense_account: 'wrong-header',
    summary_line_items: [{ expense: '6000', vatClass: 'PVM1', department: 'Sales', center: 'Office' }, { expense: '6300', vatClass: 'PVM5', department: 'Admin', center: 'Office' }],
    line_items: [{ expense: 'wrong-ocr-line', productGroup: 'Services' }],
  })], companies);
  assert.equal(rows[0].cells.glAccount, '6000, 6300');
  assert.equal(rows[0].cells.vatClassifier, 'PVM1, PVM5');
  assert.equal(rows[0].cells.departmentCode, 'Sales, Admin');
  assert.equal(rows[0].cells.costCenter, 'Office');
  assert.equal(rows[0].cells.productGroup, 'Services');
});

test('search includes every document field and filters distinguish issue state from processing state', () => {
  const rows = documentIssueRows([document()], companies);
  assert.equal(filterDocumentIssueRows(rows, 'USD', [], {}).length, 2);
  assert.equal(filterDocumentIssueRows(rows, '123456789', ['issueStatus'], { issueStatus: ['Open', 'In progress'] }).length, 1);
  assert.equal(filterDocumentIssueRows(rows, 'Alice', ['issueStatus', 'status'], { issueStatus: ['Fixed'], status: ['Correcting'] })[0].issue.id, 'i2');
  assert.equal(filterDocumentIssueRows(rows, '', [], {}).length, 2);
});

test('Reported issue is a plain description; document links and View open the document directly', () => {
  assert.match(queue, /\['number', 'fileCase'\]\.includes\(column.key\)/);
  assert.doesNotMatch(queue, /\[[^\]\n]*'reportedIssue'[^\]\n]*\]\.includes\(column.key\)/);
  assert.match(queue, /: <span className="block truncate" title=\{row.cells\[column.key\]\}/);
  assert.match(queue, /title="View document"[\s\S]*?onClick=\{\(\) => void openEditor\(row.document, row.issue.id, true\)\}/);
  assert.doesNotMatch(queue, /<DocumentIssueDialog|setReview|openReview/);
  assert.match(queue, /readOnly=\{editing.readOnly\}/);
});

test('viewing the document never claims an issue; direct Edit still claims and preserves correction context', async () => {
  const tree = ts.createSourceFile('queue.tsx', queue, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'openEditor') handler = node.initializer;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(handler);
  const current = document();
  const events = [];
  const open = new Function('teamLeadOverview', 'opening', 'setOpening', 'setError', 'supabase', 'companyById',
    'canReviewDocumentIssues', 'canAccessIssueOrganization', 'editError', 'applyDocumentIssueAction', 'setEditing', 'setQueuedNotice',
    compile('return ' + handler.getText(tree)))(false, false, () => {}, error => { if (error) throw new Error(error); },
    { from: () => ({ select: () => ({ eq: async () => ({ data: [current] }) }) }) }, new Map([['c1', { id: 'c1' }]]),
    () => true, () => true, () => '',
    async () => { events.push('claimed'); return current; }, value => events.push(value), () => {});
  await open(current, 'i1', true);
  assert.deepEqual(events, [{ document: current, issueId: 'i1', readOnly: true }]);
  events.length = 0;
  await open(current, 'i1');
  assert.deepEqual(events, ['claimed', { document: current, issueId: 'i1', readOnly: false }]);
});

test('system table controls and explicit issue-aware editing retain permission and accounting guards', () => {
  for (const component of ['SystemAddFilters', 'ColumnSettingsPanel', 'ColumnSortButton', 'ResizeHandle', 'HorizontalTableScrollbar', 'TablePagination'])
    assert.match(queue, new RegExp('<' + component + '\\b'));
  assert.match(queue, /system-table-toolbar/);
  assert.match(queue, /system-table-row-actions/);
  assert.match(queue, /canReviewDocumentIssues\(\)/);
  assert.match(queue, /canAccessIssueOrganization\(company\)/);
  assert.match(queue, /canEditCompanyDocuments/);
  assert.match(queue, /documentEditStateError/);
  assert.match(queue, /reportedIssueId=\{editing.issueId\}/);
  assert.match(source('../src/components/DocumentIssueDialog.tsx'), /onEditDocument\(document, currentIssue.id\)/);
  const detail = source('../src/components/DocumentDetailPanel.tsx');
  assert.match(detail, /issues.find\(issue => issue.id === reportedIssueId\)/);
  assert.match(detail, /aria-label="Reported issue for correction"/);
  assert.match(detail, /\{correctionIssue.message\}/);
  assert.match(queue, /applyDocumentIssueAction\(current.id, current.company_id \?\? '', \{ type: 'start', issueId \}\)/);
  assert.doesNotMatch(queue, /update\(\{ status: 'Approved'/);
});
