import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const load = path => {
  const result = {};
  new Function('exports', 'require', ts.transpileModule(source(path), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText)(result,
    name => load(`../src/lib/${name.slice(2)}.ts`));
  return result;
};
const { requestTeamLeadReview, updateTeamLeadReview, saveTeamLeadReviewTask, teamLeadColumns, TEAM_LEAD_QUEUE_KEY } = load('../src/lib/ocrTeamLeadReview.ts');
const { findSavedReviewDocumentTask } = load('../src/lib/ocrReviewDocuments.ts');
const original = () => ({ id: 'document-set-doc-1', name: 'testas.pdf', status: 'In Progress', fields: { invoiceNumber: 'INV-1' },
  products: [{ id: 'line-1', name: 'Paper' }], accounting: { documentId: 'doc-1', companyId: 'company-1' },
  comments: [{ id: 'old', text: 'Original comment', author: 'Another worker', createdAt: '2026-11-12T09:00:00Z' }] });
const actor = { fullName: 'OCR Worker', email: 'worker@example.test' };
const at = '2026-11-13T09:00:00Z';

test('a team lead request requires a useful comment and retains worker identity and history', () => {
  const task = original(), before = structuredClone(task);
  for (const comment of ['', '  \n ', 'a'.repeat(5001)]) assert.throws(() => requestTeamLeadReview(task, comment, actor, at));
  assert.throws(() => requestTeamLeadReview(task, 'Check supplier', { ...actor, email: '' }, at), /Sign in/);
  const sent = requestTeamLeadReview(task, '  Incorrect supplier code.\nPlease verify the original.  ', actor, at);
  assert.equal(sent.teamLeadReview.comment, 'Incorrect supplier code.\nPlease verify the original.');
  assert.equal(sent.teamLeadReview.requestedBy, actor.fullName);
  assert.equal(sent.teamLeadReview.requestedByEmail, actor.email);
  assert.equal(sent.teamLeadReview.requestedAt, at);
  assert.equal(sent.teamLeadReview.status, 'Pending');
  assert.equal(sent.comments.length, 2);
  assert.equal(sent.comments[1].text, sent.teamLeadReview.comment);
  assert.deepEqual(task, before);
  assert.throws(() => requestTeamLeadReview(sent, 'Again', actor, at), /already awaiting/);
});

test('saved requests are resolved by exact document and company, with comments after edit and approval', () => {
  const storage = new Map();
  const adapter = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
  adapter.setItem(TEAM_LEAD_QUEUE_KEY, JSON.stringify({ unrelated: { id: 'unrelated', comments: [] } }));
  const sent = requestTeamLeadReview(original(), 'Check the VAT classifier', actor, at);
  saveTeamLeadReviewTask(sent, adapter);
  const queue = JSON.parse(adapter.getItem(TEAM_LEAD_QUEUE_KEY));
  assert.ok(queue.unrelated);
  assert.equal(findSavedReviewDocumentTask({ id: 'doc-1', companyId: 'company-1' }, [queue]).teamLeadReview.comment, 'Check the VAT classifier');
  assert.equal(findSavedReviewDocumentTask({ id: 'doc-1', companyId: 'other-company' }, [queue]), undefined);
  const edited = { ...sent, fields: { invoiceNumber: 'CORRECTED' }, savedAt: '2026-11-13T10:00:00Z' };
  saveTeamLeadReviewTask(edited, adapter);
  assert.equal(findSavedReviewDocumentTask({ id: 'doc-1' }, [{ old: sent }, JSON.parse(adapter.getItem(TEAM_LEAD_QUEUE_KEY))]).fields.invoiceNumber, 'CORRECTED');
  const approved = updateTeamLeadReview({ ...edited, status: 'Completed' });
  assert.equal(approved.teamLeadReview.status, 'Approved');
  assert.equal(approved.teamLeadReview.comment, sent.teamLeadReview.comment);
  assert.deepEqual(approved.comments, sent.comments);
  adapter.setItem(TEAM_LEAD_QUEUE_KEY, '{broken');
  assert.throws(() => saveTeamLeadReviewTask(sent, adapter), /not overwritten/);
  assert.equal(adapter.getItem(TEAM_LEAD_QUEUE_KEY), '{broken');
});

test('Worker comment is the first TeamLead column without changing other table defaults', () => {
  const columns = [{ key: 'status', label: 'Status', width: 180, visible: true }, { key: 'number', label: 'Number', width: 120, visible: false }];
  const next = teamLeadColumns(columns);
  assert.equal(next[0].key, 'workerComment');
  assert.equal(next[0].visible, true);
  assert.equal(next[1].key, 'worker');
  assert.equal(next[1].visible, true);
  assert.deepEqual(next.slice(2), columns);
  const customized = [...columns, { key: 'workerComment', width: 420, visible: true }];
  assert.equal(teamLeadColumns(customized)[0].width, 420);
  assert.deepEqual(teamLeadColumns(next), next);
  const defaults = load('../src/lib/ocrDocumentColumns.ts');
  assert.equal(defaults.TEAM_LEAD_COLUMNS[0].key, 'workerComment');
  assert.ok(!defaults.REVIEW_COLUMNS.some(column => column.key === 'workerComment'));
});

test('send opens the system dialog; comments are visible above extraction and in the TeamLead list', () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  const dialog = source('../src/components/SendToTeamLeadDialog.tsx');
  const teamLead = source('../src/components/ml/MachineLearningView.tsx');
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(workspace, /onClick=\{\(\) => setShowTeamLeadDialog\(true\)\}/);
  assert.match(workspace, /await onUpdate\(next\)/);
  assert.match(workspace, /saveTeamLeadReviewTask\(nextTask, localStorage\)/);
  assert.ok(workspace.indexOf('aria-label="Worker comment"') < workspace.indexOf('Document validation & recommendations'));
  assert.match(dialog, /role="dialog" aria-modal="true"/);
  assert.match(dialog, /textarea[\s\S]*required[\s\S]*maxLength=\{5000\}/);
  assert.match(dialog, /pending.current/);
  assert.match(dialog, /CancelButton/);
  assert.match(teamLead, /reviewOnly\s+teamLead/);
  assert.match(teamLead, /savedTask=\{loadSavedReviewDocumentTask/);
  assert.match(teamLead, /companyId=\{currentDocument\?\.companyId\}/);
  assert.match(table, /workerComment: savedTasks.get\(document.id\)\?\.teamLeadReview\?\.comment/);
  assert.match(table, /v22:ocr:team-lead:columns/);
  assert.match(table, /key !== 'workerComment'/);
});

test('handoff saves once before opening the next document, returns to the list at the end, and stays on failure', async () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  const tree = ts.createSourceFile('workspace.tsx', workspace, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'sendToTeamLead') handler = node.initializer;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(handler);
  const build = (next, update, back) => new Function('draft', 'requestTeamLeadReview', 'getCurrentUserIdentity', 'onNextFile', 'onUpdate', 'onBack',
    ts.transpileModule('return ' + handler.getText(tree), { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText)
    (original(), requestTeamLeadReview, () => actor, next, update, back);
  const events = [];
  await build(async task => { events.push(['next', task.teamLeadReview.comment, task.status]); }, () => events.push('duplicate save'), () => events.push('back'))('Check supplier');
  assert.deepEqual(events, [['next', 'Check supplier', 'In Progress']]);
  events.length = 0;
  await build(undefined, async task => { events.push(['save', task.teamLeadReview.status]); }, () => events.push('back'))('Check supplier');
  assert.deepEqual(events, [['save', 'Pending'], 'back']);
  events.length = 0;
  await assert.rejects(build(undefined, async () => { throw Error('Storage unavailable'); }, () => events.push('back'))('Check supplier'), /Storage unavailable/);
  assert.deepEqual(events, []);
  assert.doesNotMatch(workspace, /'Awaiting team lead'/);
  assert.match(workspace, /trainingMode && draft.teamLeadReview\?\.status !== 'Pending' && <PageActionButton/);
});
