import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
function load(path, require = () => { throw Error('Unexpected import'); }) {
  const exports = {};
  new Function('exports', 'require', ts.transpileModule(source(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(exports, require);
  return exports;
}
const lifecycle = load('../src/lib/recordLifecycle.ts');
const { myOcrTasks, assignedOcrDocumentIds, requireAssignedOcrTask } = load('../src/lib/ocrMyTasks.ts', name => name === './recordLifecycle' ? lifecycle : {});
const issues = load('../src/lib/documentIssues.ts');
const access = load('../src/lib/accessControl.ts', () => lifecycle);
const companyNames = new Map([['c1', 'Company 1']]);
const me = 'worker@example.test';
const document = extra => ({ id: 'd1', company_id: 'c1', number: 'INV-1', file_case: 'INV-1.pdf', status: 'Draft', ...extra });
const work = { d1: { email: me, user: 'Worker', seconds: 30, updatedAt: '2026-11-04T10:00:00Z' } };
const allAccess = { documents: true, issues: true };
const list = (documents, tasks = new Map(), log = work, rights = allAccess, email = me) => myOcrTasks(documents, companyNames, email, tasks, log, rights);

test('My tasks includes actual OCR work and explicit assignments using email identity only', () => {
  assert.equal(list([document()]).length, 1);
  const task = { status: 'In Progress', assignedToEmail: ' WORKER@example.test ', assignedToName: 'Worker', assignedAt: '2026-11-04T09:00:00Z' };
  const assigned = list([document()], new Map([['d1', task]]), {});
  assert.equal(assigned.length, 1);
  assert.equal(assigned[0].cells.assignedAt, task.assignedAt);
  assert.equal(list([document()], new Map(), { d1: { ...work.d1, email: '', user: 'Worker' } }).length, 0);
  assert.equal(list([document({ created_by: 'Worker', accountable_responsible: 'Worker' })], new Map(), {}).length, 0);
  assert.equal(list([document()], new Map([['d1', { ...task, assignedToEmail: 'other@example.test' }]])).length, 0);
  assert.equal(list([document()], new Map(), work, allAccess, '').length, 0);
});

test('completed, confirmed, inactive, other-company and unauthorized work cannot leak into current tasks', () => {
  for (const status of ['Accepted', 'Approved', 'Completed', 'Transferred', 'Posted', 'Cancelled', 'Inactive']) assert.equal(list([document({ status })]).length, 0, status);
  assert.equal(list([document({ inactive: true })]).length, 0);
  assert.equal(list([document({ company_id: 'other-company' })]).length, 0);
  assert.equal(list([document()], new Map([['d1', { status: 'Completed' }]])).length, 0);
  assert.equal(list([document()], new Map([['d1', { status: 'In Progress', trainingStatus: 'Confirmed' }]])).length, 0);
  assert.equal(list([document()], new Map([['d1', { status: 'In Progress', assignedToEmail: me, teamLeadReview: { status: 'Pending' } }]])).length, 0);
  assert.equal(list([document()], new Map(), work, { documents: false, issues: false }).length, 0);
});

test('starting an issue assigns it to the current worker, preserves history and cannot steal another assignment', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Wrong supplier' }, 'Accountant');
  const id = reported.digitization_issues[0].id;
  const taken = issues.transitionDocumentIssue(reported, { type: 'start', issueId: id }, 'Worker', me);
  assert.equal(taken.digitization_issues[0].assignedToEmail, me);
  assert.equal(taken.digitization_issues[0].assignedToName, 'Worker');
  assert.ok(taken.digitization_issues[0].assignedAt);
  assert.equal(taken.digitization_issues[0].events.length, 2);
  assert.equal(issues.transitionDocumentIssue(taken, { type: 'start', issueId: id }, 'Worker', me), taken);
  assert.throws(() => issues.transitionDocumentIssue(taken, { type: 'start', issueId: id }, 'Other', 'other@example.test'), /another worker/);
  assert.equal(reported.digitization_issues[0].assignedToEmail, undefined);
  assert.equal(list([reported], new Map(), {}).length, 0);
  assert.equal(list([taken], new Map(), {})[0].kind, 'Document issue');
  assert.equal(list([taken], new Map(), {}, allAccess, 'other@example.test').length, 0);
  const fixed = issues.transitionDocumentIssue(taken, { type: 'resolve', issueId: id, note: 'Supplier corrected' }, 'Worker');
  assert.equal(list([fixed], new Map(), {}).length, 1);
  assert.equal(list([fixed], new Map(), {})[0].cells.status, 'Awaiting OCR');
  assert.equal(fixed.digitization_issues[0].assignedToEmail, me);
});

test('legacy in-progress issues acquire identity when explicitly taken, never through display-name inference', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Check details' }, 'Accountant');
  const id = reported.digitization_issues[0].id;
  const legacy = issues.transitionDocumentIssue(reported, { type: 'start', issueId: id }, 'Worker');
  assert.equal(list([legacy], new Map(), {}).length, 0);
  const claimed = issues.transitionDocumentIssue(legacy, { type: 'start', issueId: id }, 'Worker', me);
  assert.equal(list([claimed], new Map(), {}).length, 1);
});

test('My tasks is a Workspace submenu, inherits existing workspace rights and retains explicit restrictions', () => {
  const rights = { view: true, edit: false };
  assert.deepEqual(access.migrateDocumentIssueMenuKey({ 'ocr-workspace': rights })['ocr-workspace-my-tasks'], rights);
  const restricted = { 'ocr-workspace': rights, 'ocr-workspace-my-tasks': { view: false, edit: false } };
  assert.deepEqual(access.migrateDocumentIssueMenuKey(restricted), restricted);
  assert.match(source('../src/components/Sidebar.tsx'), /id: "ocr-workspace-my-tasks", label: "My tasks"/);
  assert.match(source('../src/components/Dashboard.tsx'), /activeMenu === "ocr-workspace-my-tasks"/);
  const page = source('../src/components/OcrMyTasksView.tsx');
  assert.match(page, /canAccessAssignedOrganization\(company, session\)/);
  assert.match(page, /requireAssignedOcrTask\(await load\(\), document\)/);
  assert.match(page, /reportedIssueId=\{editing.issue.id\}/);
  for (const component of ['ProcessedDocumentsTable', 'WorkspaceDocumentEditor', 'DocumentDetailPanel']) assert.match(page, new RegExp('<' + component + '\\b'));
  assert.doesNotMatch(page, /const COLUMNS|<div role="table"|onOpenCompanyDocuments/);
  assert.match(page, /onIssueFixed=\{close\}/);
});

test('My tasks uses the same Workspace table, controls and multi-file editor', () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  const page = source('../src/components/OcrMyTasksView.tsx');
  for (const code of [workspace, page]) {
    assert.match(code, /<ProcessedDocumentsTable/);
    assert.match(code, /embedded\s+showAllDocuments\s+selectable/);
    assert.match(code, /onEditDocument=/);
    assert.match(code, /filePosition=\{documentIndex \+ 1\}/);
    assert.match(code, /fileTotal=\{documentQueue.length\}/);
    assert.match(code, /onNextFile=\{hasNextFile \?/);
  }
  assert.doesNotMatch(page, /onRunDocument=|onImportDocuments=|selectionActionVariant=|const run =/);
  assert.match(page, /documentIds=\{documentIds\}/);
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(table, /\.filter\(\(document\) => !documentIds \|\| documentIds.has\(document.id\)\)/);
  assert.match(table, /<OcrDocumentsWorkspace/);
  for (const component of ['SystemAddFilters', 'ColumnSettingsPanel', 'HorizontalTableScrollbar', 'TablePagination']) assert.match(table, new RegExp('<' + component + '\\b'));
});

test('My tasks has twelve distinct, assigned examples without resetting saved work', () => {
  const { createOcrMyTaskExamples, mergeOcrExampleTasks } = load('../src/lib/ocrMyTaskExamples.ts');
  const examples = createOcrMyTaskExamples('c1', { email: me, fullName: 'Worker' }, '2026-11-13T10:00:00Z');
  assert.equal(examples.documents.length, 12);
  assert.equal(new Set(examples.documents.map(row => row.id)).size, 12);
  assert.equal(new Set(examples.documents.map(row => row.client_counterparty)).size, 12);
  assert.deepEqual(new Set(examples.documents.map(row => row.currency)), new Set(['EUR', 'USD', 'GBP']));
  assert.equal(list(examples.documents, new Map(Object.entries(examples.tasks)), {}).length, 12);
  assert.equal(list(examples.documents, new Map(Object.entries(examples.tasks)), {}, allAccess, 'other@example.test').length, 0);
  for (const document of examples.documents) {
    const task = examples.tasks[document.id];
    assert.equal(task.fields.invoiceNumber, document.number);
    assert.equal(task.fields.totalAmount, document.total_amount);
    assert.equal(task.products[0].name, document.line_items[0].product);
    assert.equal(Math.round(Number(document.total_amount) * 100), Math.round((Number(document.amount_without_vat) + Number(document.vat)) * 100));
  }
  const [first] = examples.documents;
  const edited = { ...examples.tasks[first.id], status: 'Completed', assignedToEmail: 'other@example.test', description: 'User correction' };
  const merged = mergeOcrExampleTasks({ [first.id]: edited }, examples.tasks);
  assert.equal(merged[first.id], edited);
  assert.deepEqual(mergeOcrExampleTasks(merged, examples.tasks), merged);
  assert.throws(() => createOcrMyTaskExamples('', { email: me, fullName: 'Worker' }, 'invalid'));
});

test('example installation is scoped, serialized and preserves deleted or completed records', () => {
  const store = source('../src/lib/supabase.ts');
  const installation = store.slice(store.indexOf('export async function ensureOcrMyTaskExamples'), store.indexOf('/** Remember the destination'));
  assert.match(installation, /serializeDocumentWrite/);
  assert.match(installation, /canAccessAssignedOrganization/);
  assert.match(installation, /batch.email !== email/);
  assert.match(installation, /if \(!batch.complete\)/);
  assert.match(installation, /!byId.has\(row.id\)/);
  assert.match(installation, /isAvailableDocument\(document\)/);
  assert.match(installation, /!findSavedReviewDocumentTask/);
  assert.match(installation, /mergeOcrExampleTasks\(storedTasks, additions\)/);
});

function exampleAdapter(storage = new Map(), identity = { email: me, fullName: 'Worker' }, allow = true) {
  const localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
  const modules = {
    './currentUser': { getCurrentUserName: () => identity.fullName, getCurrentUserIdentity: () => identity },
    './generalLedgerUsage': { rememberLedgerTableUsage() {} },
    './recordLifecycle': lifecycle,
    './documentIssues': issues,
    './documentStorno': load('../src/lib/documentStorno.ts'),
    './documentTestingExamples': { createDocumentTestingExamples: () => [] },
    './documentIssueAccess': { documentIssueSession: () => identity },
    './accessControl': { canViewMenu: () => allow, canEditMenu: () => allow },
    './linkedSettingsData': { canAccessAssignedOrganization: () => allow },
    './ocrMyTaskExamples': load('../src/lib/ocrMyTaskExamples.ts'),
    './ocrReviewDocuments': load('../src/lib/ocrReviewDocuments.ts', () => load('../src/lib/ocrDocumentWorkflow.ts')),
  };
  const api = {};
  const compiled = ts.transpileModule(source('../src/lib/supabase.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', 'window', 'localStorage', 'navigator', 'fetch', 'CustomEvent', compiled)(api,
    name => { if (!modules[name]) throw Error(name); return modules[name]; },
    { localStorage, setTimeout, clearTimeout, dispatchEvent() {} }, localStorage, {}, async () => { throw Error('Static frontend'); }, class {});
  const put = (key, value) => storage.set(`finansu-harmonija-v4:data:${key}`, JSON.stringify(value));
  const get = key => JSON.parse(storage.get(`finansu-harmonija-v4:data:${key}`) ?? 'null');
  if (!get('companies')) put('companies', [{ id: 'c1', name: 'Alice Stone' }]);
  if (!get('documents')) put('documents', [document({ id: 'existing', notes: 'Keep my work' })]);
  return { api, storage, put, get, taskKey: modules['./ocrMyTaskExamples'].WORKSPACE_DOCUMENT_TASKS_KEY };
}

test('actual example adapter is repeat-safe across concurrent loads, reloads, edits and deletions', async () => {
  const f = exampleAdapter();
  await Promise.all([f.api.ensureOcrMyTaskExamples(), f.api.ensureOcrMyTaskExamples()]);
  assert.equal(f.get('documents').length, 13);
  assert.equal(f.get('documents')[0].notes, 'Keep my work');
  const tasks = JSON.parse(f.storage.get(f.taskKey));
  const [id, removed] = Object.keys(tasks);
  tasks[id] = { ...tasks[id], status: 'Completed', description: 'Retain this correction' };
  f.storage.set(f.taskKey, JSON.stringify(tasks));
  f.put('documents', f.get('documents').filter(row => row.id !== removed).map(row => row.id === id ? { ...row, status: 'Accepted', number: 'CORRECTED' } : row));
  await exampleAdapter(f.storage).api.ensureOcrMyTaskExamples();
  assert.equal(f.get('documents').length, 12);
  assert.equal(f.get('documents').find(row => row.id === id).number, 'CORRECTED');
  assert.deepEqual(JSON.parse(f.storage.get(f.taskKey)), tasks);
  await exampleAdapter(f.storage, { email: 'other@example.test', fullName: 'Other worker' }).api.ensureOcrMyTaskExamples();
  assert.deepEqual(JSON.parse(f.storage.get(f.taskKey)), tasks);
  assert.equal(f.get('ocr_my_task_example_batches')[0].email, me);
});

test('example adapter cannot seed without access or replace corrupt saved work', async () => {
  const denied = exampleAdapter(new Map(), { email: me, fullName: 'Worker' }, false);
  await denied.api.ensureOcrMyTaskExamples();
  assert.equal(denied.get('documents').length, 1);
  const corrupt = exampleAdapter();
  corrupt.storage.set(corrupt.taskKey, '{invalid');
  await assert.rejects(corrupt.api.ensureOcrMyTaskExamples(), /not been overwritten/);
  assert.equal(corrupt.get('documents').length, 1);
  assert.equal(corrupt.storage.get(corrupt.taskKey), '{invalid');
});

test('Workspace task scoping deduplicates documents and rechecks exact identity and current ownership', () => {
  const reported = issues.transitionDocumentIssue(document(), { type: 'report', message: 'Wrong supplier' }, 'Accountant');
  const issueId = reported.digitization_issues[0].id;
  const taken = issues.transitionDocumentIssue(reported, { type: 'start', issueId }, 'Worker', me);
  const tasks = list([taken]);
  assert.equal(tasks.length, 2);
  assert.deepEqual([...assignedOcrDocumentIds(tasks)], ['d1']);
  assert.equal(requireAssignedOcrTask(tasks, { id: 'd1', companyId: 'c1' }).issue.id, issueId);
  assert.throws(() => requireAssignedOcrTask(tasks, { id: 'd1', companyId: 'other' }), /no longer accessible/);
  assert.throws(() => requireAssignedOcrTask(tasks, { id: 'other', companyId: 'c1' }), /no longer accessible/);
  assert.throws(() => requireAssignedOcrTask([], { id: 'd1', companyId: 'c1' }), /no longer accessible/);
  assert.equal(assignedOcrDocumentIds([]).size, 0);
});
