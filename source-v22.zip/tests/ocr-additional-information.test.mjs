import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const api = {};
new Function('exports', ts.transpileModule(read('../src/lib/ocrAdditionalInformation.ts'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText)(api);

test('Alt/Option + P opens ADDINFO only outside typing and never repeats or hijacks another shortcut', () => {
  const event = { code: 'KeyP', altKey: true, ctrlKey: false, metaKey: false, repeat: false, isComposing: false, defaultPrevented: false };
  assert.equal(api.isOcrAdditionalInformationShortcut(event, false), true);
  assert.equal(api.isOcrAdditionalInformationShortcut({ ...event, key: 'π' }, false), true, 'Mac Option uses physical KeyP');
  assert.equal(api.isOcrAdditionalInformationShortcut(event, true), false);
  for (const patch of [{ code: 'KeyO' }, { altKey: false }, { ctrlKey: true }, { metaKey: true }, { repeat: true }, { isComposing: true }, { defaultPrevented: true }]) {
    assert.equal(api.isOcrAdditionalInformationShortcut({ ...event, ...patch }, false), false);
  }
});

test('existing Dashboard values remain readable without modification and never leak between companies', () => {
  const values = { departmentCode: 'ADMIN', object: 'Building', project: 'P1', costCenter: 'C1', glAccount: '6300', accountablePerson: 'Accountant', productGroup: 'Services', vatClassifier: 'PVM1', source: 'Email', detailedSplitting: true, duplicatesAccepted: false };
  const key = 'finansu-harmonija:v12:dashboard:ocr-additional-information:company-1';
  assert.equal(api.ocrAdditionalInformationKey('company-1'), key);
  const storage = { getItem: name => name === key ? JSON.stringify(values) : null };
  assert.deepEqual(api.readOcrAdditionalInformation(storage, 'company-1'), values);
  assert.deepEqual(api.readOcrAdditionalInformation(storage, 'company-2'), api.EMPTY_OCR_ADDITIONAL_INFORMATION);
  assert.deepEqual(api.readOcrAdditionalInformation(storage, 'company-1'), values);
});

test('missing, malformed or inaccessible storage is safe and defaults cannot be mutated by a draft', () => {
  for (const value of [null, 'broken', 'null', '[]', '42']) {
    assert.deepEqual(api.readOcrAdditionalInformation({ getItem: () => value }, 'company'), api.EMPTY_OCR_ADDITIONAL_INFORMATION);
  }
  assert.deepEqual(api.readOcrAdditionalInformation({ getItem: () => { throw Error('Blocked'); } }, 'company'), api.EMPTY_OCR_ADDITIONAL_INFORMATION);
  const partial = api.readOcrAdditionalInformation({ getItem: () => JSON.stringify({ glAccount: '4430', project: 17, duplicatesAccepted: 'yes', detailedSplitting: true }) }, 'company');
  assert.equal(partial.glAccount, '4430'); assert.equal(partial.project, ''); assert.equal(partial.duplicatesAccepted, false); assert.equal(partial.detailedSplitting, true);
  partial.glAccount = 'changed'; assert.equal(api.EMPTY_OCR_ADDITIONAL_INFORMATION.glAccount, '');
});

test('one shared form is scoped to Dashboard and All documents, preserving all fields and safe dialog behavior', () => {
  const company = read('../src/components/CompanyDetail.tsx');
  const dashboard = read('../src/components/DashboardView.tsx');
  const form = read('../src/components/OcrAdditionalInformation.tsx');
  assert.match(company, /\(activeMenu === 'overview' \|\| activeMenu === 'documents'\) && <OcrAdditionalInformation key=\{currentCompany.id\} companyId=\{currentCompany.id\}/);
  assert.ok(!dashboard.includes('showAdditionalInformation'));
  assert.ok(!dashboard.includes("event.code === 'KeyP'"));
  for (const field of Object.keys(api.EMPTY_OCR_ADDITIONAL_INFORMATION)) assert.ok(form.includes(field), field);
  assert.match(form, /createPortal\(/);
  assert.match(form, /z-\[5001\]/);
  assert.match(form, /role="dialog" aria-modal="true"/);
  assert.match(form, /event.stopImmediatePropagation\(\)/);
  assert.match(form, /previous\?\.isConnected/);
  assert.match(form, /if \(otherDialog\) return/);
  assert.match(form, /onClick=\{\(\) => setDraft\(null\)\}/);
  assert.match(form, /localStorage.setItem\(storageKey, JSON.stringify\(draft\)\)/);
  assert.ok(!form.includes('usePersistentState'), 'opening or cancelling must not write stored settings');
});
