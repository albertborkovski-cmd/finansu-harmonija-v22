import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const storno = {}, core = {};
new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
new Function('exports', 'require', compile('../src/lib/documentRowActions.ts'))(core, () => storno);
const rights = { delete: true, create: true, storno: true };
const draft = { id: 'doc-1', company_id: 'company-1', number: 'INV-1', document_type: 'INVOICES', document_date: '2026-10-15', status: 'Draft', total_amount: '121.00', amount_without_vat: '100.00', vat: '21.00', currency: 'EUR', client_counterparty: 'Supplier' };
const invoice = { ...draft, status: 'Approved', line_items: [{ id: 'item-1', qty: '2', price: '50', subtotal: '100', vat: '21.00 EUR', total: '121.00 EUR', discount: '0', expense: '6000', department: 'D1' }], summary_line_items: [{ id: 'allocation-1', qty: '1', price: '100', subtotal: '100', vat: '21', total: '121', expense: '6000', center: 'C1' }] };
const posting = { id: 'posting-1', number: 'BZ-1', documentId: 'doc-1', companyId: 'company-1', date: '2026-10-15', status: 'Posted', postedAt: '2026-10-15T12:00:00Z', postedBy: 'Accountant', baseCurrency: 'EUR', integration: { destination: 'Local', status: 'Not sent' }, lines: [
  { id: 'gl-1', account: '6000', accountName: 'Expenses', currency: 'EUR', debitMinor: 12100, creditMinor: 0, baseDebitMinor: 12100, baseCreditMinor: 0 },
  { id: 'gl-2', account: '4430', accountName: 'Payables', currency: 'EUR', debitMinor: 0, creditMinor: 12100, baseDebitMinor: 0, baseCreditMinor: 12100 },
] };
const context = { id: 'correction-1', allowed: true, today: '2026-11-04', now: '2026-11-04T10:00:00Z', actor: 'Test accountant' };
const command = (source = invoice) => ({ expectedSnapshot: core.documentActionSnapshot(source), number: 'CN-1', date: '2026-11-04', reason: 'Incorrect invoice' });

test('one contextual action: unapproved → Delete, posted GL → Storno, confirmed invoice → credit note', () => {
  assert.deepEqual(core.documentRowAction(draft, rights), { kind: 'delete', label: 'Delete', disabledReason: '' });
  const gl = { ...draft, document_type: 'ACCOUNTING_NOTE', status: 'Approved', accounting_posting: posting };
  assert.deepEqual(core.documentRowAction(gl, rights), { kind: 'storno', label: 'Storno', disabledReason: '' });
  assert.equal(core.documentRowAction({ ...invoice, accounting_posting: posting }, rights).label, 'Create credit note');
  assert.equal(core.documentRowAction({ ...invoice, document_subtype: 'Credit invoice', total_amount: '-121' }, rights).label, 'Create debit note');
  assert.equal(core.documentRowAction({ ...gl, accounting_posting: undefined }, rights).disabledReason, '');
});

test('Delete opens confirmation for unapproved documents, but is never the action of confirmed documents', () => {
  for (const status of ['Draft', 'New', 'Pending', 'Manual', 'Correcting', 'Provide Additional', 'Exception', 'Rejected', 'Duplicate', 'Not documented']) {
    const action = core.documentRowAction({ ...draft, status }, rights);
    assert.equal(action.kind, 'delete');
    assert.equal(core.canOpenDocumentRowAction(action), true);
  }
  const linked = core.documentRowAction(draft, rights, true);
  assert.equal(core.canOpenDocumentRowAction(linked), true);
  assert.equal(linked.disabledReason, '');
  const denied = core.documentRowAction(draft, { ...rights, delete: false });
  assert.equal(core.canOpenDocumentRowAction(denied), true);
  assert.match(denied.disabledReason, /Delete access/);
  for (const status of ['Approved', 'Confirmed', 'Accepted', 'Completed', 'Processed', 'Transferred', 'Exported', 'Posted', 'Paid']) {
    for (const document_type of ['INVOICES', 'ACCOUNTING_NOTE']) {
      assert.notEqual(core.documentRowAction({ ...draft, status, document_type }, rights).kind, 'delete');
    }
  }
});

test('list and Actions menu open the shared confirmation; Cancel does not run deletion', () => {
  const table = read('../src/components/Documents.tsx');
  const menu = read('../src/components/DocumentActionsMenu.tsx');
  const dialog = read('../src/components/DocumentRowActionDialog.tsx');
  assert.match(table, /disabled=\{!canOpenDocumentRowAction\(contextAction\)\}/);
  assert.match(menu, /disabled=\{blocked \|\| !canOpenDocumentRowAction\(loaded.action\)\}/);
  assert.match(dialog, /onClick=\{onClose\}>Cancel<\/button>/);
  assert.match(dialog, /Are you sure you want to delete this unapproved document\?/);
  assert.match(dialog, /if \(!source \|\| blocker \|\| saving.current\) return/);
  assert.match(dialog, /disabled=\{!source \|\| busy \|\| Boolean\(blocker\)/);
  assert.match(dialog, /await deleteUnconfirmedDocument\(documentId, companyId, documentActionSnapshot\(source\)\)/);
});

test('all unconfirmed documents can be deleted without losing links/history; rights and confirmed operations stay protected', () => {
  assert.match(core.documentRowAction(draft, { ...rights, delete: false }).disabledReason, /Delete access/);
  assert.match(core.documentRowAction(invoice, { ...rights, create: false }).disabledReason, /Create access/);
  assert.equal(core.documentRowAction(draft, rights, true).disabledReason, '');
  for (const patch of [{ inline_edit_history: [{}] }, { digitization_issues: [{}] }, { accounting_test_deliveries: [{}] }, { correction_of_document_id: 'original' }]) assert.equal(core.documentRowAction({ ...draft, ...patch }, rights).disabledReason, '');
  for (const patch of [{ inactive: true }, { active: false }, { is_active: false }, { status: 'Inactive', accounting_note_status: 'Approved' }]) assert.match(core.documentRowAction({ ...invoice, ...patch }, rights).disabledReason, /Inactive/);
  for (const status of ['Processing', 'Custom unconfirmed status', 'Inactive']) assert.equal(core.documentRowAction({ ...draft, status }, rights).disabledReason, '');
  assert.match(core.documentRowAction({ ...draft, document_deletion: { at: '2026-11-09', actor: 'Test' } }, rights).disabledReason, /already been deleted/);
  assert.match(core.documentRowAction({ ...invoice, accounting_storno: { number: 'ST-1' } }, rights).disabledReason, /already/);
  assert.match(core.documentRowAction({ ...draft, document_type: 'ACCOUNTING_NOTE', accounting_posting: { ...posting, integration: { destination: 'External', status: 'Transferred' } } }, rights).disabledReason, /confirmed document/);
  assert.equal(core.documentRowAction({ ...invoice, document_type: 'ACCOUNTING_NOTE', accounting_posting: { ...posting, integration: { destination: 'External', status: 'Transferred' } } }, rights).disabledReason, '');
  assert.match(core.documentRowAction({ ...invoice, document_storno: { mode: 'test' } }, rights).disabledReason, /already/);
});

test('corrective draft reverses amounts with fresh IDs and preserves original, dimensions and links', () => {
  const original = { ...invoice, accounting_posting: posting, image_url: 'original.pdf', digitization_issues: [{ id: 'old' }] };
  const before = structuredClone(original);
  const result = core.prepareDocumentCorrection(original, command(original), context);
  assert.deepEqual(original, before);
  assert.equal(result.status, 'Draft'); assert.equal(result.document_subtype, 'Credit note');
  assert.equal(result.total_amount, '-121.00'); assert.equal(result.vat, '-21.00');
  assert.equal(result.line_items[0].qty, '-2'); assert.equal(result.line_items[0].price, '50');
  assert.equal(result.line_items[0].total, '-121.00'); assert.equal(result.line_items[0].department, 'D1');
  assert.equal(result.summary_line_items[0].center, 'C1');
  assert.notEqual(result.line_items[0].id, invoice.line_items[0].id);
  assert.notEqual(result.line_items[0].id, result.summary_line_items[0].id);
  assert.equal(result.correction_of_document_id, invoice.id);
  assert.equal(result.correction_history[0].actor, context.actor);
  assert.equal(result.accounting_posting, undefined); assert.equal(result.accounting_storno, undefined);
  assert.equal(result.digitization_issues, undefined); assert.equal(result.image_url, null);
  const negative = { ...invoice, total_amount: '-121', vat: '-21', amount_without_vat: '-100', document_subtype: 'Credit note' };
  const debit = core.prepareDocumentCorrection(negative, command(negative), context);
  assert.equal(debit.document_subtype, 'Debit note'); assert.equal(debit.total_amount, '121.00');
  const fractional = { ...invoice, line_items: [{ ...invoice.line_items[0], qty: '0.005' }] };
  assert.equal(core.prepareDocumentCorrection(fractional, command(fractional), context).line_items[0].qty, '-0.005');
  assert.equal(core.documentNumericValue('1,234.56 EUR'), 1234.56);
  assert.equal(core.documentNumericValue('1 234,56 EUR'), 1234.56);
  assert.ok(Number.isNaN(core.documentNumericValue('not an amount')));
});

test('correction validation refuses stale snapshots, missing data, invalid periods, unapproved sources and rights', () => {
  assert.throws(() => core.prepareDocumentCorrection(invoice, command(), { ...context, allowed: false }), /access/);
  assert.throws(() => core.prepareDocumentCorrection(draft, command(draft), context), /confirmed/);
  for (const patch of [{ expectedSnapshot: '{}' }, { number: '' }, { reason: '' }, { date: '' }, { date: '2026-02-30' }, { date: '2027-01-01' }, { date: '2026-10-01' }]) assert.throws(() => core.prepareDocumentCorrection(invoice, { ...command(), ...patch }, context));
  const invalid = { ...invoice, total_amount: 'invalid' };
  assert.throws(() => core.prepareDocumentCorrection(invalid, command(invalid), context), /amount/);
  assert.throws(() => storno.guardPostedDocumentMutation({}, { correction_of_document_id: 'forged' }), /correction workflow/);
  assert.throws(() => storno.guardPostedDocumentMutation({ correction_history: [{}] }, { correction_history: [] }), /correction workflow/);
});

function fixture(initial = draft) {
  const store = new Map(); let access = { ...rights }, linked = false, closed = '';
  const issues = {}, api = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  const require = name => {
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './documentRowActions') return core;
    if (name === './documentRowActionAccess') return { documentActionRights: () => access };
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => access.delete };
    if (name === './documentInlineEditing') return {};
    if (name === './documentDetailEditing') return {};
    if (name === './documentIssueAccess') return {};
    if (name === './documentStornoAccess') return { loadStornoPeriodPolicy: () => ({ enabled: false, cutoffDay: 25, closedThrough: closed }) };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { isRecordLinked: () => linked, removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [initial]); put('companies', [{ id: initial.company_id, name: 'Test company' }]); put('document_history', []);
  return { ...api, put, get, revoke: () => { access = { delete: false, create: false, storno: false }; }, link: () => { linked = true; }, close: () => { closed = '2099-01-01'; } };
}

test('single delete removes only the chosen unconfirmed document from registers and preserves its original data', async () => {
  const f = fixture();
  f.put('documents', [draft, { ...draft, id: 'keep' }]);
  await f.deleteUnconfirmedDocument(draft.id, draft.company_id, core.documentActionSnapshot(draft));
  const archived = f.get('documents')[0];
  const { document_deletion, ...original } = archived;
  assert.deepEqual(original, draft);
  assert.equal(document_deletion.actor, 'Test accountant');
  assert.ok(Number.isFinite(Date.parse(document_deletion.at)));
  const visible = await f.supabase.from('documents').select('*');
  assert.deepEqual(visible.data.map(doc => doc.id), ['keep']);
  assert.deepEqual((await f.supabase.from('documents').select('*').eq('id', draft.id)).data, []);
  assert.equal(f.get('document_history').length, 1);
  assert.equal(f.get('document_history')[0].document_id, draft.id);
  assert.equal(f.get('document_history')[0].created_at, document_deletion.at);
  assert.equal(f.get('document_history')[0].user_name, document_deletion.actor);
  for (const block of [
    f => f.revoke(),
    f => f.put('documents', [{ ...draft, number: 'changed' }]), f => f.put('documents', [invoice]),
    f => f.put('documents', [{ ...draft, accounting_posting: posting }]),
    f => f.put('documents', [{ ...draft, accounting_note_status: 'Confirmed' }]),
    f => f.put('documents', [{ ...draft, document_storno: { mode: 'test' } }]),
  ]) {
    const locked = fixture(); block(locked);
    await assert.rejects(locked.deleteUnconfirmedDocument(draft.id, draft.company_id, core.documentActionSnapshot(draft)));
    assert.ok(locked.get('documents').some(doc => doc.id === draft.id));
  }
  await assert.rejects(fixture().deleteUnconfirmedDocument(draft.id, 'other-company', core.documentActionSnapshot(draft)), /company/);
  await assert.rejects(f.deleteUnconfirmedDocument(draft.id, draft.company_id, core.documentActionSnapshot(archived)), /company/);
});

test('Draft deletion is allowed after creation, editing, reporting and linking, without removing that history', async () => {
  const source = { ...draft, inline_edit_history: [{ id: 'edit' }], detail_edit_history: [{ id: 'detail' }],
    digitization_issues: [{ id: 'issue', status: 'Open' }], accounting_test_deliveries: [{ id: 'test' }],
    correction_of_document_id: 'original', correction_history: [{ id: 'correction' }] };
  const related = { ...draft, id: 'related', correction_of_document_id: source.id };
  const history = { id: 'creation', document_id: draft.id, action: 'Created' };
  const f = fixture(source); f.link(); f.put('document_history', [history]); f.put('documents', [source, related]);
  await f.deleteUnconfirmedDocument(source.id, source.company_id, core.documentActionSnapshot(source));
  const { document_deletion, ...retained } = f.get('documents')[0];
  assert.ok(document_deletion); assert.deepEqual(retained, source);
  assert.deepEqual(f.get('documents')[1], related);
  assert.deepEqual(f.get('document_history')[0], history);
  assert.deepEqual((await f.supabase.from('documents').select('*')).data, [related]);
  // Reloading a fresh adapter retains the tombstone and never reseeds the row.
  const reloaded = fixture(); reloaded.put('documents', f.get('documents'));
  assert.deepEqual((await reloaded.supabase.from('documents').select('*')).data, [related]);
});

test('deleted documents cannot be edited, reinserted or resurrected by stale form writes', async () => {
  const f = fixture();
  await f.deleteUnconfirmedDocument(draft.id, draft.company_id, core.documentActionSnapshot(draft));
  const archived = structuredClone(f.get('documents'));
  for (const query of [
    f.supabase.from('documents').insert(draft),
    f.supabase.from('documents').upsert(draft),
    f.supabase.from('documents').upsert(draft, { onConflict: 'id' }),
    f.supabase.from('documents').update({ document_deletion: null }).eq('id', draft.id),
  ]) assert.ok((await query).error);
  assert.deepEqual((await f.supabase.from('documents').update({ number: 'RESURRECT' }).eq('id', draft.id)).data, []);
  assert.deepEqual((await f.supabase.from('documents').delete().eq('id', draft.id)).data, []);
  await assert.rejects(f.applyDocumentInlineEdit(draft.id, draft.company_id, 'status', 'Approved', '{}'), /no longer available/);
  await assert.rejects(f.applyDocumentDetailEdit(draft.id, draft.company_id, {}, '{}', 'Stale edit'), /no longer available/);
  await assert.rejects(f.applyDocumentStorno(draft.id, draft.company_id, {}), /no longer/);
  await assert.rejects(f.applyDocumentIssueAction(draft.id, draft.company_id, { type: 'start' }), /organization has changed/);
  assert.deepEqual(f.get('documents'), archived);
});

test('concurrent delete requests cannot record the same deletion twice', async () => {
  const f = fixture();
  const result = await Promise.allSettled([1, 2].map(() => f.deleteUnconfirmedDocument(draft.id, draft.company_id, core.documentActionSnapshot(draft))));
  assert.equal(result.filter(item => item.status === 'fulfilled').length, 1);
  assert.equal(f.get('document_history').length, 1);
});

test('correction command persists a linked draft and audit, never alters original, and rejects duplicate/stale/locked/revoked actions', async () => {
  const f = fixture(invoice), input = { ...command(), date: storno.accountingToday() };
  const saved = await f.createCorrectiveDocument(invoice.id, invoice.company_id, input);
  assert.deepEqual(f.get('documents')[0], invoice);
  assert.equal(f.get('documents')[1].id, saved.id);
  assert.equal(saved.status, 'Draft'); assert.equal(f.get('document_history')[0].original_document_id, invoice.id);
  await assert.rejects(f.createCorrectiveDocument(invoice.id, invoice.company_id, input), /already exists/);
  for (const block of [f => f.revoke(), f => f.close(), f => f.put('documents', [{ ...invoice, number: 'changed' }])]) {
    const locked = fixture(invoice); block(locked);
    await assert.rejects(locked.createCorrectiveDocument(invoice.id, invoice.company_id, input));
    assert.equal(locked.get('documents').length, 1);
  }
  await assert.rejects(f.createCorrectiveDocument(invoice.id, 'other-company', input), /company/);
});

test('row uses the detail Storno form, a single final contextual icon, and equal header/row action widths', () => {
  const table = read('../src/components/Documents.tsx');
  assert.match(table, /import \{ DocumentStornoDialog \} from '.\/DocumentStornoAction'/);
  assert.match(table, /rowActionDocument\?\.kind === 'storno' && <DocumentStornoDialog documentId=\{rowActionDocument.documentId\} companyId=\{rowActionDocument.companyId\}/);
  assert.equal((table.match(/data-document-context-action=/g) || []).length, 1);
  assert.equal((table.match(/style=\{\{ width: rowActionsWidth \}\}/g) || []).length, 2);
  assert.ok(table.indexOf('data-document-context-action=') > table.indexOf('aria-label={`Send ${doc.fileCase'));
  assert.match(table, /aria-label=\{`\$\{contextAction.label\} \$\{doc.number \|\| doc.fileCase\}`\}/);
  assert.match(table, /contextAction.kind === 'delete' \? <Trash2 size=\{14\} aria-hidden="true"/);
  assert.match(table, /contextAction.kind === 'storno' \? <Undo2 size=\{14\} aria-hidden="true"/);
  assert.match(table, /contextAction.label === 'Create debit note' \? <FilePlus2 size=\{14\} aria-hidden="true"/);
  assert.match(table, /<FileMinus2 size=\{14\} aria-hidden="true"/);
  assert.match(table, /title=\{contextAction.disabledReason \? `\$\{contextAction.label\}: \$\{contextAction.disabledReason\}` : contextAction.label\}/);
  assert.doesNotMatch(table, /w-\[142px\]|\n\s*\{contextAction.label\}\s*\n/);
  assert.match(table, /const rowActionsWidth = editOnlyActions \? 74 : companyId && !allCompanies \? 192 : 160/);
  assert.match(read('../src/components/DocumentRowActionDialog.tsx'), /createCorrectiveDocument/);
});

test('row action rights resolve active role configuration within the user audience, not another audience’s same-name role', () => {
  let permitted = true, audience = 'Internal users', session = { email: 'a@example.test', roleNames: ['Accountant'] };
  const store = new Map(), access = {};
  const require = name => {
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => permitted };
    if (name === './accessControl') return { parseSession: () => session, isSystemAdministratorRole: value => value === 'Administrator' };
    if (name === './currentUser') return { AUTH_SESSION_KEY: 'session' };
    if (name === './recordLifecycle') return { isInactiveRecord: role => role.inactive };
    if (name === './documentStornoAccess') return { canStornoDocument: () => permitted };
    if (name === './linkedSettingsData') return { loadLinkedDirectoryUsers: category => category === audience ? [{ id: 'u1', email: session.email }] : [] };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', compile('../src/lib/documentRowActionAccess.ts'))(access, require, { localStorage: { getItem: key => store.get(key) ?? null } });
  const internal = 'finansu-harmonija:v7:settings:internal:roles', external = 'finansu-harmonija:v7:settings:external:roles';
  const role = { name: 'Accountant', actionPermissions: JSON.stringify({ documents: ['VIEW', 'EDIT', 'CREATE', 'DELETE'] }) };
  store.set(internal, JSON.stringify([role]));
  assert.deepEqual(access.documentActionRights({ id: 'company-1' }), rights);
  permitted = false; assert.deepEqual(access.documentActionRights({ id: 'company-1' }), { delete: false, create: false, storno: false });
  permitted = true; store.set(internal, JSON.stringify([{ ...role, inactive: true }]));
  assert.equal(access.documentActionRights({ id: 'company-1' }).delete, false);
  store.set(internal, JSON.stringify([role])); audience = 'External users';
  store.set(external, JSON.stringify([{ ...role, actionPermissions: JSON.stringify({ documents: ['VIEW', 'EDIT'] }) }]));
  assert.deepEqual(access.documentActionRights({ id: 'company-1' }), { delete: false, create: false, storno: false });
  session = { ...session, roleNames: ['Administrator'] }; permitted = false;
  assert.equal(access.documentActionRights({ id: 'company-1' }).create, false);
});
