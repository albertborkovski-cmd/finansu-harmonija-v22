import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const api = {};
new Function('exports', ts.transpileModule(read('../src/lib/companyBankColumns.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(api);
const { BANK_DEFAULT_COLUMNS: defaults, resolveBankColumns } = api;
const expectedLabels = ['Date', 'Bank account', 'Counterparty name', 'Purpose of payment', 'Amount', 'Currency', 'Status', 'Reconciliation status'];
const legacyKeys = ['bankAccount', 'accountCode', 'transferNo', 'date', 'counterpartyName', 'counterpartyCode', 'postingType', 'amount', 'currency', 'exchangeRateDate', 'paymentPurpose', 'referenceNo', 'costCenter', 'notes', 'glAccounts', 'settledDocuments', 'confirmed', 'id', 'attachmentsCount'];

const legacyColumn = key => defaults.find(column => column.key === key) || { key, label: 'Confirmed?', width: 130, visible: false };
test('Bank has exactly eight visible defaults; Confirmed? is removed and other columns remain optional', () => {
  assert.deepEqual(defaults.filter(column => column.visible).map(column => column.label), expectedLabels);
  assert.equal(defaults.length, 22);
  for (const key of legacyKeys.filter(key => key !== 'confirmed')) assert.ok(defaults.some(column => column.key === key), key);
  assert.ok(!defaults.some(column => column.key === 'confirmed'));
  assert.equal(defaults.find(column => column.key === 'referenceNo').visible, false);
  assert.equal(new Set(defaults.map(column => column.key)).size, defaults.length);
});

test('the automatically saved legacy default upgrades immediately, retaining resized widths', () => {
  const previous = legacyKeys.map(key => ({ ...legacyColumn(key), visible: true, width: key === 'date' ? 175 : 140 }));
  const snapshot = structuredClone(previous);
  const result = resolveBankColumns(previous);
  assert.deepEqual(result.filter(column => column.visible).map(column => column.label), expectedLabels);
  assert.equal(result[0].width, 175);
  assert.deepEqual(previous, snapshot);
  assert.deepEqual(resolveBankColumns(result), result);
});

test('custom order and selections survive, including Reference No. enabled through Column settings', () => {
  const custom = defaults.map(column => ({ ...column, visible: column.key === 'referenceNo' || column.key === 'date' })).reverse();
  assert.deepEqual(resolveBankColumns(custom), custom);
  const oldCustom = legacyKeys.map(key => ({ ...legacyColumn(key), visible: key === 'referenceNo' || key === 'confirmed' }));
  const restored = resolveBankColumns(oldCustom);
  assert.deepEqual(restored.filter(column => column.visible).map(column => column.key), ['referenceNo']);
  assert.equal(restored.length, defaults.length);
  for (const invalid of [null, {}, [], [{ key: 'unknown' }]]) assert.deepEqual(resolveBankColumns(invalid), defaults);
});

test('Bank account gets room for the compact bank label without resetting custom widths', () => {
  const previous = defaults.map(column => ({ ...column, width: column.key === 'bankAccount' ? 190 : column.width }));
  assert.equal(resolveBankColumns(previous).find(column => column.key === 'bankAccount').width, 220);
  previous.find(column => column.key === 'bankAccount').width = 275;
  assert.equal(resolveBankColumns(previous).find(column => column.key === 'bankAccount').width, 275);
});

test('new optional bank details upgrade saved layouts hidden and can be enabled independently', () => {
  const keys = ['counterpartyIban', 'bookingDate'];
  for (const key of keys) assert.equal(defaults.find(column => column.key === key).visible, false);
  const previous = defaults.filter(column => !keys.includes(column.key)).map(column => ({ ...column }));
  previous.find(column => column.key === 'exchangeRateDate').visible = true;
  previous.find(column => column.key === 'date').width = 175;
  const upgraded = resolveBankColumns(previous);
  assert.deepEqual(upgraded.slice(0, previous.length), previous);
  assert.deepEqual(upgraded.slice(previous.length).map(column => [column.key, column.visible]), keys.map(key => [key, false]));
  const enabled = upgraded.map(column => ({ ...column, visible: keys.includes(column.key) || column.visible }));
  assert.deepEqual(resolveBankColumns(JSON.parse(JSON.stringify(enabled))), enabled);
  assert.deepEqual(defaults.find(column => column.key === 'date'), { key: 'date', label: 'Date', width: 130, visible: true });
  assert.deepEqual(defaults.find(column => column.key === 'exchangeRateDate'), { key: 'exchangeRateDate', label: 'Exchange rate date', width: 180, visible: false });
});

test('the Bank register maps document and reconciliation statuses independently and retains shared column settings', () => {
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /status: bankProcessingStatus\(document.inlineSource\)/);
  assert.match(view, /reconciliationStatus: reconciliation\.status/);
  assert.match(view, /resolveBankColumns\(savedColumns\)/);
  assert.match(view, /<ColumnSettingsPanel columns=\{columns\} defaultColumns=\{DEFAULT_COLUMNS\}/);
  assert.match(view, /column.key === 'reconciliationStatus' \? BANK_RECONCILIATION_STATUSES/);
  assert.match(view, /RECONCILIATION_BADGE_STYLES\[row.reconciliationStatus\]/);
  assert.match(view, /counterpartyIban: bank\?\.counterpartyIban\?\.trim\(\) \|\| '—'/);
  assert.match(view, /bookingDate: bank\?\.bookingDate\?\.trim\(\) \|\| '—'/);
});
