import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
function load(file, dependencies = {}, globals = {}) {
  const api = {};
  const js = ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', ...Object.keys(globals), js)(api, name => {
    if (!(name in dependencies)) throw new Error(`Unexpected dependency ${name}`);
    return dependencies[name];
  }, ...Object.values(globals));
  return api;
}
const issues = load('../src/lib/documentIssues.ts');
const storno = load('../src/lib/documentStorno.ts');
const examples = load('../src/lib/documentTestingExamples.ts');
const exportsCore = load('../src/lib/documentExport.ts');
const accountingExport = load('../src/lib/documentAccountingExport.ts', { './documentExport': exportsCore });
const deliveryCore = load('../src/lib/documentTestDelivery.ts', { './documentIssues': issues });

function fixture() {
  const storage = new Map(), downloads = [], requests = [];
  let view = true, edit = true, companyAccess = true;
  const fakeWindow = { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} };
  const access = {
    canViewCompanyDocuments: company => !!company && companyAccess,
    canEditCompanyDocuments: company => !!company && companyAccess,
  };
  const dependencies = {
    './documentTestDelivery': deliveryCore,
    './documentExport': { ...exportsCore, downloadDocumentExport: file => downloads.push(file) },
    './documentEditAccess': access,
    './documentIssues': issues,
    './documentStorno': storno,
    './documentTestingExamples': examples,
    './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserName: () => 'Test reviewer' },
    './generalLedgerUsage': { rememberLedgerTableUsage() {} },
    './recordLifecycle': { removeOrDeactivateRecords: rows => rows },
    './documentAccountingExport': accountingExport,
    './accessControl': { parseSession: () => ({}), canViewMenu: () => view, canEditMenu: () => edit },
  };
  const database = load('../src/lib/supabase.ts', dependencies, {
    window: fakeWindow, navigator: {}, CustomEvent: class {},
    fetch: async url => { requests.push(url); throw new Error('Static test deployment'); },
  });
  const api = load('../src/lib/ocrDocumentDelivery.ts', { ...dependencies, './supabase': database }, { window: fakeWindow });
  const put = (table, rows) => storage.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(storage.get(`finansu-harmonija-v4:data:${table}`));
  const documents = examples.createDocumentTestingExamples('alice');
  put('documents', [...documents, { ...documents[0], id: 'other-document', company_id: 'other' }]);
  put('companies', [{ id: 'alice', name: 'Alice Stone' }, { id: 'other', name: 'Other company' }]);
  put('document_history', []);
  const command = ids => ({
    requestId: 'ocr-delivery-0001', companyId: 'alice', ids, destinationId: 'rivile', scenario: 'accepted',
    snapshots: Object.fromEntries(get('documents').filter(document => ids.includes(document.id)).map(document => [document.id, deliveryCore.documentTestDeliverySnapshot(document)])),
  });
  return { ...api, put, get, documents, downloads, requests, command,
    rights: (canView, canEdit, canAccessCompany = true) => { view = canView; edit = canEdit; companyAccess = canAccessCompany; } };
}

test('OCR delivery resolves exact selected IDs, including hidden selected rows, and only their companies', async () => {
  const f = fixture();
  const ids = [f.documents[2].id, f.documents[0].id, f.documents[2].id];
  const result = await f.loadOcrDeliveryRecords({ mode: 'export', ids });
  assert.deepEqual(result.documents.map(document => document.id), ids.slice(0, 2));
  assert.deepEqual(result.companies.map(company => company.id), ['alice']);
  await assert.rejects(() => f.loadOcrDeliveryRecords({ mode: 'export', ids: ['missing'] }), /no longer available/);
  await assert.rejects(() => f.loadOcrDeliveryRecords({ mode: 'export', ids: [] }), /Select at least/);
});

test('OCR and company rights are rechecked before loading, exporting, sending or saving the destination', async () => {
  const f = fixture(), request = { mode: 'transfer', ids: [f.documents[0].id] };
  f.rights(true, false);
  assert.equal(f.canUseOcrDocumentDelivery('transfer'), false);
  assert.equal(f.canUseOcrDocumentDelivery('export'), true);
  await assert.rejects(() => f.sendOcrDocuments(request, f.command(request.ids)), /no longer have access/);
  await assert.rejects(() => f.saveOcrDeliveryDestination(request, 'alice', 'rivile'), /no longer have access/);
  f.rights(false, false);
  await assert.rejects(() => f.exportOcrDocuments({ ...request, mode: 'export' }, 'rivile'), /no longer have access/);
  f.rights(true, true, false);
  await assert.rejects(() => f.exportOcrDocuments({ ...request, mode: 'export' }, 'rivile'), /no longer have access/);
  assert.equal(f.downloads.length, 0);
  assert.equal(f.get('document_history').length, 0);
});

test('export uses the same system-specific XML/JSON files and does not change the sending default or documents', async () => {
  const f = fixture(), ids = [f.documents[0].id, f.documents[2].id];
  const before = structuredClone(f.get('documents'));
  await f.saveOcrDeliveryDestination({ mode: 'transfer', ids }, 'alice', 'rivile');
  for (const destination of ['rivile', 'agnum', 'rivile-api']) await f.exportOcrDocuments({ mode: 'export', ids }, destination);
  assert.deepEqual(f.downloads.map(file => file.filename.split('.').at(-1)), ['xml', 'xml', 'json']);
  assert.equal(f.get('companies')[0].accounting_destination_id, 'rivile');
  const json = JSON.parse(f.downloads[2].content);
  assert.deepEqual(json.documents.map(document => document.id), ids);
  assert.equal(json.documents[1].accountingAllocations.length, 3);
  assert.equal(json.importReady, false);
  assert.deepEqual(f.get('documents'), before);
  await assert.rejects(() => f.saveOcrDeliveryDestination({ mode: 'export', ids }, 'alice', 'agnum'), /do not change/);
});

test('sending uses existing validation, persists receipts/history and never approves, transfers or reruns OCR', async () => {
  const f = fixture(), ids = [f.documents[0].id, f.documents[10].id];
  const before = structuredClone(f.get('documents'));
  const saved = await f.sendOcrDocuments({ mode: 'transfer', ids }, f.command(ids));
  assert.deepEqual(saved.map(document => document.accounting_test_deliveries.at(-1).outcome), ['Accepted', 'Blocked']);
  for (const document of saved) {
    const original = before.find(item => item.id === document.id);
    assert.equal(document.status, original.status);
    assert.deepEqual(document.accounting_posting, original.accounting_posting);
    assert.deepEqual(document.digitization_issues, original.digitization_issues);
    assert.deepEqual(document.summary_line_items, original.summary_line_items);
  }
  assert.equal(f.get('document_history').length, 2);
  assert.ok(f.requests.every(url => String(url).startsWith('/__meso_shared_data/')));
});

test('mixed companies, stale selection, changed document and disabled destinations fail safely', async () => {
  const f = fixture(), ids = [f.documents[0].id], command = f.command(ids);
  const mixed = { mode: 'transfer', ids: [...ids, 'other-document'] };
  await assert.rejects(() => f.saveOcrDeliveryDestination(mixed, 'alice', 'rivile'), /Reopen/);
  await assert.rejects(() => f.exportOcrDocuments({ ...mixed, mode: 'export' }, 'rivile'), /one company/);
  await assert.rejects(() => f.sendOcrDocuments(mixed, { ...command, ids: mixed.ids }), /one company/);
  await assert.rejects(() => f.sendOcrDocuments({ mode: 'transfer', ids }, { ...command, ids: [f.documents[1].id] }), /selected documents changed/);
  f.put('documents', f.get('documents').map(document => document.id === ids[0] ? { ...document, order_no: 'changed' } : document));
  await assert.rejects(() => f.sendOcrDocuments({ mode: 'transfer', ids }, command), /document changed/);
  f.put('companies', [{ id: 'alice', name: 'Alice Stone', counterparties_settings: '{"exportIntegrations":[]}' }]);
  await assert.rejects(() => f.exportOcrDocuments({ mode: 'export', ids }, 'rivile'), /no longer available/);
  assert.equal(f.downloads.length, 0);
  assert.equal(f.get('document_history').length, 0);
});

test('only Approve documents opts into shared delivery with system buttons and the same dialog', () => {
  const review = source('../src/components/OcrReviewView.tsx');
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  const actions = source('../src/components/OcrDocumentDeliveryActions.tsx');
  const approve = review.slice(review.indexOf('function ApproveDocumentsView()'), review.indexOf('function ReviewAnalyticsView()'));
  assert.match(approve, /accountingDelivery\s+importActionContainer=\{deliveryActionContainer\}/);
  assert.doesNotMatch(approve, /onRunDocument=|onImportDocuments=|selectionActionVariant=/);
  assert.match(table, /accountingDelivery = false/);
  assert.match(table, /selectedIds=\{selectedRowIds\}/);
  assert.doesNotMatch(actions, /reviewDocumentQueue|filteredRows|setSelectedRowIds/);
  assert.match(actions, /<DocumentDeliveryDialog/);
  assert.match(actions, /<PageActionButton/);
  assert.match(actions, /createPortal\(sendAction, actionContainer\)/);
  assert.match(actions, /savedDocumentDeliveryDestination\(company\)/);
  assert.match(actions, /aria-label="Export selected documents"/);
  assert.match(actions, /<Download size=\{16\} strokeWidth=\{1.8\}/);
});
