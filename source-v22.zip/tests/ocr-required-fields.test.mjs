import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const load = file => {
  const result = {};
  new Function('exports', ts.transpileModule(source(file), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText)(result);
  return result;
};
const { hasOcrValue, missingOcrRequiredFields, ocrCompletionPatch } = load('../src/lib/ocrRequiredFields.ts');
const { ocrReviewExampleCompletion } = load('../src/lib/ocrReviewExampleCompletion.ts');
const required = (key, extra = {}) => ({ key, label: key, level: 'red', ...extra });

test('zero amounts and Invoice No are values, not missing required data', () => {
  for (const value of [0, '0.00', false, 'No']) assert.equal(hasOcrValue(value), true);
  for (const value of [undefined, null, '', '  ', '—', '-']) assert.equal(hasOcrValue(value), false);
  assert.deepEqual(missingOcrRequiredFields({ document_type: 'Receipt', vat: 0, vat_percent: '0%' },
    [required('invoice'), required('vat'), required('vatPercent')]), []);
});

test('only enabled mandatory fields block approval; empty yellow and green remain optional', () => {
  const rules = [required('number'), required('costCenter', { level: 'green' }), required('orderNo', { level: 'yellow' }),
    required('series', { enabled: false }), required('glAccount', { inactive: true }), required('currency', { level: 'green', required: true })];
  assert.deepEqual(missingOcrRequiredFields({}, rules), ['number', 'currency']);
  assert.deepEqual(missingOcrRequiredFields({ number: 'INV-1', currency: 'EUR' }, rules), []);
  const view = source('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(view, /row\[key\] === "—" && Boolean\(validationLevel\)/);
  assert.match(view, /bg-\[#FFF8E5\]/);
  assert.match(view, /bg-\[#EAF8F2\]/);
  assert.doesNotMatch(view, /failedInvoiceValidation/);
  const workspace = source('../src/components/WorkspaceView.tsx');
  assert.match(workspace, /completionDocument \? missingOcrRequiredFields\(completionDocument, completionRules\) : basicMissingFields/);
  assert.match(workspace, /label="Due Date" required=\{fieldRequired\('dueEndDate'\)\}/);
});

test('approval preview and save use the same corrected values and classification', () => {
  const patch = ocrCompletionPatch({ documentType: 'VAT invoice', fields: { invoiceNumber: 'INV-1', invoiceDate: '2026-11-13', dueDate: '', companyName: ' Supplier ', taxRate: '0', totalAmount: '100' },
    accounting: { supplierCode: '123', expenseAccount: '6300', vatClassifier: 'PVM5' } }, [{ code: 'VAT_INVOICE', fullName: 'VAT invoice', parentCode: 'INVOICES' }]);
  assert.equal(patch.counterparty_code, '123');
  assert.equal(patch.client_counterparty, 'Supplier');
  assert.equal(patch.document_type, 'INVOICES');
  assert.equal(patch.document_subtype, 'VAT_INVOICE');
  assert.deepEqual(missingOcrRequiredFields(patch, [required('number'), required('counterpartyCode')]), []);
});

test('only known demonstration documents receive missing supplier codes', () => {
  const example = { id: '10000000-0000-4000-8000-000000000027', client_counterparty: 'UAB Sprendimų grupė' };
  const patch = ocrReviewExampleCompletion(example);
  assert.equal(patch.counterparty_code, 'DEMO-CP-003');
  assert.equal(ocrReviewExampleCompletion({ ...example, ...patch }), null);
  assert.equal(ocrReviewExampleCompletion({ ...example, counterparty_code: 'Existing' }).counterparty_code, undefined);
  assert.equal(ocrReviewExampleCompletion({ ...example, id: 'real-upload' }), null);
  assert.equal(ocrReviewExampleCompletion({ ...example, client_counterparty: 'Actual supplier' }), null);
  assert.equal(ocrReviewExampleCompletion({ ...example, id: '10000000-0000-4000-8000-000000001027' }), null);
  assert.equal(ocrReviewExampleCompletion({ id: 'alice:v22-ocr-my-tasks-v1:001', client_counterparty: 'Baltic Office UAB' }).counterparty_code, 'DEMO-OCR-001');
});
