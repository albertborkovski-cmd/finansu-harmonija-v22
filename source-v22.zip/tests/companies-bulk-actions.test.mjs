import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = readFileSync(new URL('../src/lib/linkedSettingsData.ts', import.meta.url), 'utf8')
  .replace("import { recordAdministrativeAction } from './supabase';", 'const recordAdministrativeAction = (...args) => globalThis.bulkActionAudit.push(args);');
const { outputText } = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } });
const api = await import(`data:text/javascript;base64,${Buffer.from(outputText).toString('base64')}`);
const organizations = [
  { id: 'company-a', name: 'Company A' },
  { id: 'company-b', name: 'Company B' },
  { id: 'company-c', name: 'Company C' },
];
const users = [
  { id: 'first', fullName: 'Shared name', email: 'first@example.test', roles: 'Meso accountant', status: 'Active', organizations: 'Company A' },
  { id: 'second', fullName: 'Shared name', email: 'second@example.test', roles: 'Meso accountant', status: 'Active', organizations: 'Unassigned' },
  { id: 'other', fullName: 'Other accountant', roles: 'Meso accountant', status: 'Active', organizations: 'Company A, Company C' },
  { id: 'blocked', fullName: 'Blocked accountant', roles: 'Meso accountant', status: 'Blocked' },
];

function setup(t) {
  const previousWindow = globalThis.window;
  const storage = new Map();
  const events = [];
  globalThis.bulkActionAudit = [];
  globalThis.window = {
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => storage.set(key, value),
      removeItem: key => storage.delete(key),
    },
    dispatchEvent: event => events.push(event),
  };
  api.saveLinkedDirectoryUsers('Internal users', users, false);
  t.after(() => { globalThis.window = previousWindow; delete globalThis.bulkActionAudit; });
  return { storage, events };
}

function assigned(organization, id) {
  return api.isAccountantAssigned(organization, api.loadLinkedDirectoryUsers('Internal users').find(user => user.id === id));
}

test('assigning selected companies preserves other assignments and separates users with the same name', t => {
  const { events } = setup(t);
  api.addAccountantToOrganizations(['second'], organizations.slice(0, 2));
  assert.equal(assigned(organizations[0], 'first'), true);
  assert.equal(assigned(organizations[0], 'other'), true);
  assert.equal(assigned(organizations[0], 'second'), true);
  assert.equal(assigned(organizations[1], 'second'), true);
  assert.equal(assigned(organizations[2], 'second'), false);
  assert.equal(assigned(organizations[2], 'other'), true);
  assert.equal(globalThis.bulkActionAudit.length, 2);
  assert.equal(events.at(-1).detail.scope, 'relationships');
});

test('unchecked assignments are removed only from selected companies', t => {
  setup(t);
  api.addAccountantToOrganizations([], [organizations[0]], ['other']);
  assert.equal(assigned(organizations[0], 'other'), false);
  assert.equal(assigned(organizations[0], 'first'), true);
  assert.equal(assigned(organizations[2], 'other'), true);
});

test('replace updates only selected companies containing the source accountant', t => {
  setup(t);
  assert.equal(api.replaceAccountantInOrganizations('first', 'second', organizations.slice(0, 2)), 1);
  assert.equal(assigned(organizations[0], 'first'), false);
  assert.equal(assigned(organizations[0], 'second'), true);
  assert.equal(assigned(organizations[0], 'other'), true);
  assert.equal(assigned(organizations[1], 'second'), false);
  assert.equal(assigned(organizations[2], 'other'), true);
});

test('substitution persists its dates without changing permanent assignments and updates rather than duplicates', t => {
  const { storage } = setup(t);
  const directoryBefore = storage.get(api.directoryStorageKey('Internal users'));
  api.setOrganizationSubstitution('second', '2026-11-13', '2026-11-20', organizations.slice(0, 2));
  const first = api.loadOrganizationSubstitutions();
  assert.equal(first.length, 2);
  assert.equal(storage.get(api.directoryStorageKey('Internal users')), directoryBefore);
  assert.equal(assigned(organizations[0], 'second'), false);
  api.setOrganizationSubstitution('second', '2026-11-14', '2026-11-22', organizations.slice(0, 2), first.map(row => row.id));
  const updated = api.loadOrganizationSubstitutions();
  assert.equal(updated.length, 2);
  assert.ok(updated.every(row => row.from === '2026-11-14' && row.to === '2026-11-22'));
});

test('invalid targets, blocked users and invalid substitution dates do not mutate data', t => {
  const { storage } = setup(t);
  const before = [...storage];
  assert.throws(() => api.addAccountantToOrganizations(['blocked'], organizations), /active internal users/);
  assert.throws(() => api.addAccountantToOrganizations(['second'], []), /at least one organization/);
  assert.throws(() => api.replaceAccountantInOrganizations('first', 'blocked', organizations), /active replacement accountant/);
  assert.throws(() => api.setOrganizationSubstitution('second', '2026-11-20', '2026-11-13', organizations), /valid From and To dates/);
  assert.throws(() => api.setOrganizationSubstitution('second', '2026-02-30', '2026-03-01', organizations), /valid From and To dates/);
  assert.deepEqual([...storage], before);
  assert.equal(globalThis.bulkActionAudit.length, 0);
});
