import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const load = (file, imports = {}) => {
  const result = {};
  new Function('exports', 'require', ts.transpileModule(source(file), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText)(result,
    name => { if (imports[name]) return imports[name]; throw new Error(`Unexpected import ${name}`); });
  return result;
};
const routing = load('../src/lib/ocrApprovalRouting.ts');
const { resolveOcrApprovalRoute, ocrRoutingTypeCodes, putOcrApprovalRule, ocrCompletionDestination } = routing;
const { ocrDocumentStage } = load('../src/lib/ocrDocumentWorkflow.ts');
const types = [{ code: 'INVOICES', fullName: 'Invoices', parentCode: '', status: 'Active' },
  { code: 'VAT_INVOICE', fullName: 'VAT invoice', parentCode: 'INVOICES', status: 'Active' }];
const rule = (id, organizationId = '', documentType = '', destination = 'TeamLead') => ({ id, organizationId, documentType, destination, active: true, updatedAt: '2026-11-13T12:00:00Z', updatedBy: 'Admin' });

test('organization rule wins over shared type; exact subtype wins over parent; default is safe', () => {
  const codes = ocrRoutingTypeCodes({ document_type: 'INVOICES', document_subtype: 'VAT invoice' }, types);
  assert.deepEqual(codes, ['VAT_INVOICE', 'INVOICES']);
  assert.deepEqual(ocrRoutingTypeCodes({ document_type: 'Credit note' }, [...types,
    { code: 'CREDIT_INVOICE', fullName: 'Credit invoice', parentCode: 'INVOICES', status: 'Active' }]), ['CREDIT_INVOICE', 'INVOICES']);
  const rules = [rule('global', '', '', 'FH'), rule('parent', '', 'INVOICES'), rule('subtype', '', 'VAT_INVOICE', 'FH'), rule('company', 'alice')];
  assert.equal(resolveOcrApprovalRoute(rules, 'alice', codes).ruleId, 'company');
  assert.equal(resolveOcrApprovalRoute(rules, 'bob', codes).ruleId, 'subtype');
  assert.equal(resolveOcrApprovalRoute([...rules, rule('exact', 'alice', 'VAT_INVOICE', 'FH')], 'alice', codes).ruleId, 'exact');
  assert.equal(resolveOcrApprovalRoute([], 'alice', codes).destination, 'TeamLead');
  assert.equal(resolveOcrApprovalRoute([rule('other', 'bob', '', 'FH')], 'alice', codes).destination, 'TeamLead');
  assert.equal(resolveOcrApprovalRoute([{ ...rule('inactive', '', '', 'FH'), active: false }], 'alice', codes).destination, 'TeamLead');
});

test('rules keep history and reject duplicate active scopes', () => {
  const initial = { version: 1, rules: [], history: [] };
  const saved = putOcrApprovalRule(initial, rule('alice', 'alice', 'INVOICES', 'FH'));
  assert.equal(initial.rules.length, 0);
  assert.throws(() => putOcrApprovalRule(saved, rule('duplicate', 'alice', 'INVOICES')), /already exists/);
  const updated = putOcrApprovalRule(saved, { ...saved.rules[0], active: false });
  assert.equal(updated.history.at(-1).before.active, true);
  assert.equal(updated.history.at(-1).after.active, false);
  assert.equal(resolveOcrApprovalRoute(updated.rules, 'alice', ['INVOICES']).destination, 'TeamLead');
});

test('document type edit switches all / selected organizations / disabled and retains other settings', () => {
  const { configureOcrDocumentTypeRouting: configure, getOcrDocumentTypeRouting: read } = routing;
  const original = { version: 1, rules: [rule('contract', '', 'CONTRACTS', 'FH')], history: [] };
  assert.equal(read(original.rules, 'INVOICES').mode, 'inherit');
  const save = (store, mode, organizationIds = []) => configure(store, 'INVOICES', 'INVOICES', { mode, organizationIds }, 'Admin', '2026-11-13');
  const all = save(original, 'all');
  assert.equal(read(all.rules, 'INVOICES').mode, 'all');
  assert.equal(resolveOcrApprovalRoute(all.rules, 'alice', ['INVOICES']).destination, 'TeamLead');
  const selected = save(all, 'organizations', ['alice', 'bob', 'alice']);
  assert.deepEqual(read(selected.rules, 'INVOICES'), { mode: 'organizations', organizationIds: ['alice', 'bob'] });
  assert.equal(resolveOcrApprovalRoute(selected.rules, 'alice', ['INVOICE', 'INVOICES']).destination, 'TeamLead');
  assert.equal(resolveOcrApprovalRoute(selected.rules, 'charlie', ['INVOICE', 'INVOICES']).destination, 'FH');
  const updated = save(selected, 'organizations', ['bob']);
  assert.equal(resolveOcrApprovalRoute(updated.rules, 'alice', ['INVOICES']).destination, 'FH');
  assert.equal(updated.rules.find(rule => rule.organizationId === 'alice').active, false);
  assert.equal(updated.history.at(-1).before.active, true);
  const disabled = save(updated, 'disabled');
  assert.equal(read(disabled.rules, 'INVOICES').mode, 'disabled');
  assert.equal(resolveOcrApprovalRoute(disabled.rules, 'bob', ['INVOICES']).destination, 'FH');
  assert.deepEqual(disabled.rules.find(rule => rule.id === 'contract'), original.rules[0]);
  assert.equal(original.rules.length, 1);
  assert.throws(() => save(disabled, 'organizations'), /at least one/);
  assert.equal(read(save(disabled, 'inherit').rules, 'INVOICES').mode, 'inherit');
});

test('renaming a type preserves routing; unchanged and custom configurations are not overwritten', () => {
  const { configureOcrDocumentTypeRouting: configure, getOcrDocumentTypeRouting: read } = routing;
  const original = { version: 1, rules: [rule('alice', 'alice', 'INVOICES', 'FH')], history: [] };
  assert.equal(read(original.rules, 'INVOICES').mode, 'custom');
  assert.equal(configure(original, 'INVOICES', 'INVOICES', null, 'Admin', 'now'), original);
  const renamed = configure(original, 'INVOICES', 'BILLS', null, 'Admin', 'now');
  assert.equal(renamed.rules[0].documentType, 'BILLS');
  assert.equal(renamed.history[0].before.documentType, 'INVOICES');
  assert.equal(resolveOcrApprovalRoute(renamed.rules, 'alice', ['BILLS']).destination, 'FH');
});

test('document type and routing save together, recheck permission, and roll back on a storage failure', () => {
  const entries = new Map([['catalog', '[{"code":"INVOICES"}]']]);
  let editable = true, fail = false;
  globalThis.localStorage = { getItem: key => entries.get(key) ?? null, removeItem: key => entries.delete(key),
    setItem: (key, value) => { if (fail && key.endsWith('approval-routing')) { fail = false; throw new Error('Storage full'); } entries.set(key, value); } };
  globalThis.window = { dispatchEvent() {} }; globalThis.CustomEvent ??= class {};
  const store = load('../src/lib/ocrApprovalRoutingStore.ts', {
    './ocrApprovalRouting': routing,
    './accessControl': { canEditMenu: () => editable, parseSession: () => ({}) },
    './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserIdentity: () => ({ fullName: 'Admin' }) },
  });
  const save = () => store.saveOcrDocumentTypeConfiguration('catalog', [{ code: 'INVOICES', fullName: 'Invoices' }], 'INVOICES', 'INVOICES', { mode: 'organizations', organizationIds: ['alice'] });
  editable = false; assert.throws(save, /permission/);
  assert.equal(entries.get('catalog'), '[{"code":"INVOICES"}]');
  editable = true; fail = true; assert.throws(save, /Storage full/);
  assert.equal(entries.get('catalog'), '[{"code":"INVOICES"}]');
  assert.equal(entries.has(store.OCR_APPROVAL_ROUTING_KEY), false);
  save();
  assert.equal(JSON.parse(entries.get('catalog'))[0].fullName, 'Invoices');
  assert.equal(routing.getOcrDocumentTypeRouting(store.loadOcrApprovalRouting().rules, 'INVOICES').mode, 'organizations');
  const previousCatalog = entries.get('catalog');
  entries.set(store.OCR_APPROVAL_ROUTING_KEY, '{broken');
  assert.throws(save, /not overwritten/);
  assert.equal(entries.get('catalog'), previousCatalog);
});

test('TeamLead confirmation finishes the route instead of requesting another review', () => {
  assert.equal(ocrCompletionDestination({ destination: 'TeamLead' }, 'Pending').destination, 'FH');
  assert.equal(ocrCompletionDestination({ destination: 'TeamLead' }, 'Approved').destination, 'FH');
  assert.equal(ocrCompletionDestination({ destination: 'TeamLead' }).destination, 'TeamLead');
  assert.equal(ocrDocumentStage({ status: 'Accepted', ocr_approval_route: { destination: 'FH' } }, { status: 'Completed' }), null);
  assert.equal(ocrDocumentStage({ status: 'Accepted', ocr_approval_route: { destination: 'TeamLead' } }).queue, 'approval');
  assert.equal(ocrDocumentStage({ status: 'Accepted', ocr_approval_route: { destination: 'FH' }, ocr_rerun_request: { status: 'Pending' } }).queue, 'processing');
  assert.equal(ocrDocumentStage({ status: 'Accepted', ocr_approval_route: { destination: 'FH' } }, { teamLeadReview: { status: 'Pending' } }).queue, 'approval');
});

test('settings persist, recheck edit permission, and never overwrite corrupt settings', () => {
  const entries = new Map(); let editable = true;
  globalThis.localStorage = { getItem: key => entries.get(key) || null, setItem: (key, value) => entries.set(key, value) };
  globalThis.window = { dispatchEvent() {} }; globalThis.CustomEvent ??= class {};
  const store = load('../src/lib/ocrApprovalRoutingStore.ts', {
    './ocrApprovalRouting': routing,
    './accessControl': { canEditMenu: () => editable, parseSession: () => ({}) },
    './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserIdentity: () => ({ fullName: 'Admin', email: 'admin@example.test' }) },
  });
  store.saveOcrApprovalRule(rule('one', 'alice', 'INVOICES', 'FH'));
  assert.equal(store.loadOcrApprovalRouting().rules[0].destination, 'FH');
  editable = false;
  assert.throws(() => store.saveOcrApprovalRule(rule('two')), /permission/);
  assert.equal(store.loadOcrApprovalRouting().rules.length, 1);
  editable = true; entries.set(store.OCR_APPROVAL_ROUTING_KEY, '{broken');
  assert.throws(() => store.saveOcrApprovalRule(rule('three')), /not overwritten/);
  assert.equal(entries.get(store.OCR_APPROVAL_ROUTING_KEY), '{broken');
});

test('document type settings expose routing and completion validates before either destination', () => {
  const view = source('../src/components/OrganizationReferenceValuesView.tsx');
  assert.match(view, /OcrDocumentTypeEditor/);
  assert.doesNotMatch(view, /showApprovalRouting|OcrApprovalRoutingView/);
  const form = source('../src/components/OcrDocumentTypeEditor.tsx');
  assert.match(form, /TeamLead approval/);
  assert.match(form, /Enabled — all organizations/);
  assert.match(form, /Enabled — selected organizations/);
  assert.match(form, /Disabled — send to FH/);
  assert.match(form, /MultiSelectField label="Organizations"/);
  assert.match(form, /onSave\(draft, routingChanged \? routing : null\)/);
  const editor = source('../src/components/WorkspaceView.tsx');
  const handler = editor.slice(editor.indexOf('const saveDocumentTask ='));
  assert.ok(handler.indexOf('if (missing.length) throw') < handler.indexOf('resolveOcrApprovalRoute('));
  assert.ok(handler.indexOf('if (missing.length) throw') < handler.indexOf("supabase.from('documents').update"));
  assert.match(handler, /ocr_approval_history: \[\.\.\.\(latest.ocr_approval_history/);
  assert.match(handler, /route.destination === 'TeamLead'/);
});

test('the actual completion handler validates, persists the route, and hands off without a review loop', async () => {
  const file = source('../src/components/WorkspaceView.tsx');
  const tree = ts.createSourceFile('Workspace.tsx', file, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let handler;
  const visit = node => { if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'saveDocumentTask') handler = node.initializer; ts.forEachChild(node, visit); };
  visit(tree); assert.ok(handler);
  const required = load('../src/lib/ocrRequiredFields.ts');
  const review = load('../src/lib/ocrTeamLeadReview.ts');
  const fixture = ({ destination = 'FH', number = 'INV-1', pending = false, edit = true } = {}) => {
    const events = [], document = { id: 'doc', company_id: 'alice', document_type: 'INVOICES', document_subtype: 'VAT_INVOICE', client_counterparty: 'Supplier' };
    const task = { id: 'doc', name: 'doc.pdf', status: 'Completed', assignedToEmail: 'worker@example.test', documentType: 'VAT invoice', comments: [],
      fields: { invoiceNumber: number, companyName: 'Supplier', invoiceDate: '2026-11-13', dueDate: '', taxRate: '21', totalAmount: '121' },
      accounting: { documentId: 'doc', companyId: 'alice', supplierName: 'Supplier', supplierKey: '123', supplierCode: '123', expenseAccount: '6300', vatClassifier: 'PVM1' } };
    const pendingReview = { status: 'Pending', comment: 'Check code', requestedAt: '2026-11-13T10:00:00Z' };
    const deps = {
      readOnly: false, documentId: 'doc', getCurrentUserIdentity: () => ({ fullName: 'Worker', email: 'worker@example.test' }),
      supabase: { from() { let update; const query = { select() { return query; }, update(value) { update = value; return query; }, eq() { return query; }, then(resolve) {
        if (update) { events.push(['write', update]); Object.assign(document, update); }
        return Promise.resolve({ data: [document] }).then(resolve);
      } }; return query; } },
      loadOrganizationReferenceRecords: () => types, ...required, ...routing,
      loadOcrFieldValidationRules: () => [{ key: 'number', label: 'Number', level: 'red' }],
      localStorage: { getItem() { return null; } }, AUTH_SESSION_KEY: 'auth', parseSession: () => ({}), canEditMenu: () => edit,
      loadSavedReviewDocumentTask: () => pending ? { teamLeadReview: pendingReview } : undefined,
      documentTask: {}, loadOcrApprovalRouting: () => ({ rules: [rule('route', 'alice', '', destination)] }),
      requestTeamLeadReview: review.requestTeamLeadReview, updateTeamLeadReview: review.updateTeamLeadReview,
      confirmDocumentAccounting: () => events.push(['teach']),
      window: { dispatchEvent() {} }, CustomEvent: class {},
      onSave: task => events.push(['saved', task]), saveTeamLeadReviewTask: task => events.push(['queue', task]), TEAM_LEAD_QUEUE_KEY: 'queue',
      setDocumentTask: task => events.push(['state', task]), commitWorkTime() {},
    };
    const action = new Function(...Object.keys(deps), ts.transpileModule('return ' + handler.getText(tree), { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText)(...Object.values(deps));
    return { action: () => action(task), events };
  };
  for (const destination of ['FH', 'TeamLead']) {
    const invalid = fixture({ destination, number: '' });
    await assert.rejects(invalid.action, /Complete required fields/);
    assert.equal(invalid.events.length, 0);
  }
  const direct = fixture(); await direct.action();
  assert.equal(direct.events.find(([name]) => name === 'write')[1].ocr_approval_route.destination, 'FH');
  assert.equal(direct.events.filter(([name]) => name === 'teach').length, 1);
  assert.equal(direct.events.some(([name]) => name === 'queue'), false);
  const referral = fixture({ destination: 'TeamLead' }); await referral.action();
  assert.equal(referral.events.find(([name]) => name === 'queue')[1].teamLeadReview.status, 'Pending');
  assert.equal(referral.events.find(([name]) => name === 'queue')[1].status, 'In Progress');
  assert.equal(referral.events.some(([name]) => name === 'teach'), false);
  const approved = fixture({ destination: 'TeamLead', pending: true }); await approved.action();
  assert.equal(approved.events.find(([name]) => name === 'write')[1].ocr_approval_route.destination, 'FH');
  assert.equal(approved.events.find(([name]) => name === 'queue')[1].teamLeadReview.status, 'Approved');
  assert.equal(approved.events.find(([name]) => name === 'queue')[1].teamLeadReview.comment, 'Check code');
  const denied = fixture({ pending: true, edit: false }); await assert.rejects(denied.action, /permission/);
  assert.equal(denied.events.length, 0);
});
