import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const aliases = ['albertborkvski@gmail.com', 'albertborkovski@gmail.com', 'albert.borkovski@gmail.com'];
const company = { id: 'company-1', name: 'Alice Stone' };
const directoryKey = 'finansu-harmonija:v7:settings:internal:users';
const sessionKey = 'finansu-harmonija-v7:authenticated';
function fixture(email) {
  const storage = new Map([[sessionKey, JSON.stringify({ email })]]);
  const cache = new Map();
  const window = { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) } };
  function load(name) {
    if (name === './supabase') return { recordAdministrativeAction() {} };
    if (name === './currentUser') return { AUTH_SESSION_KEY: sessionKey };
    if (cache.has(name)) return cache.get(name);
    const exports = {};
    cache.set(name, exports);
    const source = readFileSync(new URL(`../src/lib/${name.slice(2)}.ts`, import.meta.url), 'utf8');
    const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
    new Function('exports', 'require', 'window', 'localStorage', compiled)(exports, load, window, window.localStorage);
    return exports;
  }
  const access = load('./documentEditAccess');
  const directory = load('./linkedSettingsData');
  const admin = { ...directory.INTERNAL_USER_DEFAULTS[0] };
  return { ...access, storage, admin, accessControl: load('./accessControl'), setUsers: users => storage.set(directoryKey, JSON.stringify(users)) };
}

test('all already-supported administrator login aliases resolve the same active directory account', () => {
  for (const email of [...aliases, ' ALBERTBORKOVSKI@GMAIL.COM ']) {
    const f = fixture(email);
    assert.equal(f.canViewCompanyDocuments(company), true, email);
    assert.equal(f.canEditCompanyDocuments(company), true, email);
    assert.equal(f.canEditCompanyDocuments(undefined), false);
  }
});

test('alias matching never bypasses inactive, blocked, unactivated or deleted directory users', () => {
  for (const email of aliases) {
    for (const override of [{ status: 'Blocked' }, { status: 'Unactivated' }, { status: 'Disabled' }, { status: 'Inactive' }, { inactive: 'true' }]) {
      const f = fixture(email);
      f.setUsers([{ ...f.admin, ...override }]);
      assert.equal(f.canViewCompanyDocuments(company), false, `${email}: ${JSON.stringify(override)}`);
      assert.equal(f.canEditCompanyDocuments(company), false);
    }
    const f = fixture(email);
    f.storage.set(`${directoryKey}:deleted`, JSON.stringify([f.admin.id]));
    assert.equal(f.canEditCompanyDocuments(company), false);
  }
});

test('a conflicting blocked alias also denies access; unknown emails cannot inherit Administrator from a stale session', () => {
  const f = fixture(aliases[1]);
  f.setUsers([f.admin, { ...f.admin, id: 'old-alias-row', email: aliases[1], status: 'Blocked' }]);
  assert.equal(f.canEditCompanyDocuments(company), false);
  const unknown = fixture('unassigned@example.invalid');
  unknown.storage.set(sessionKey, JSON.stringify({ email: 'unassigned@example.invalid', roleNames: ['Administrator'] }));
  assert.equal(unknown.canEditCompanyDocuments(company), false);
  assert.equal(unknown.canViewCompanyDocuments(company), false);
});

test('configured users retain fresh object permissions and company scope without administrator alias fallback', () => {
  const f = fixture('accountant@example.invalid');
  const modules = f.accessControl.createFullAccess();
  const rights = f.accessControl.createMenuAccessFromModules(modules);
  const role = { name: 'Document accountant', moduleAccess: JSON.stringify(modules), menuAccess: JSON.stringify(rights) };
  const user = { id: 'accountant', email: 'accountant@example.invalid', status: 'Active', roles: role.name, organizations: company.name };
  f.setUsers([user]);
  f.storage.set('finansu-harmonija:v7:settings:internal:roles', JSON.stringify([role]));
  assert.equal(f.canEditCompanyDocuments(company), true);
  assert.equal(f.canEditCompanyDocuments({ id: 'other-company', name: 'Other company' }), false);
  rights.documents.edit = false;
  role.menuAccess = JSON.stringify(rights);
  f.storage.set('finansu-harmonija:v7:settings:internal:roles', JSON.stringify([role]));
  assert.equal(f.canViewCompanyDocuments(company), true);
  assert.equal(f.canEditCompanyDocuments(company), false);
});
