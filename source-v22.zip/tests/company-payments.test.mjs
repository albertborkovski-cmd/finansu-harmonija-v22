import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const company = { id: 'company-a', name: 'Alice Stone', organization_bank_accounts: JSON.stringify([{ bank: 'SEB', iban: 'LT121000011101001000' }]) };
const document = { id: 'invoice-a', company_id: company.id, number: 'INV-001', document_type: 'Invoice', type: 'Purchase' };
const draft = { debtorAccount: 'LT121000011101001000', executionDate: '2026-11-12', counterparty: 'Test supplier', creditorAccount: 'LT12 1000 0111 0100 1000', amount: '120,50', currency: 'eur', purpose: 'Payment for invoice INV-001', relatedDocumentId: '' };
function fixture() {
  const api = {}, storage = new Map(); let allowed = true;
  const data = { companies: [company], documents: [document, { ...document, id: 'invoice-b', company_id: 'company-b' }] };
  const facade = { from: table => ({ select: () => ({ eq: async (key, value) => ({ data: data[table].filter(row => row[key] === value), error: null }) }) }) };
  const require = name => {
    if (name === './supabase') return { supabase: facade };
    if (name === './bankTransaction') return { companyBankAccounts: row => JSON.parse(row.organization_bank_accounts).filter(account => !account.inactive) };
    if (name === './bankTransactionCreation') return { canCreateCompanyBankTransaction: () => allowed };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './recordLifecycle') return { isInactiveRecord: row => Boolean(row.inactive || row.active === false) };
    throw Error(name);
  };
  const code = ts.transpileModule(read('../src/lib/companyPayments.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', 'window', 'CustomEvent', code)(api, require,
    { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }, dispatchEvent() {} }, class {});
  return { ...api, storage, data, revoke: () => { allowed = false; } };
}

test('new payment is a blank draft and its optional document is not required', () => {
  const f = fixture();
  assert.deepEqual(f.newPaymentDraft(), Object.fromEntries(Object.keys(draft).map(key => [key, ''])));
  const row = f.preparePaymentDraft(company, 'payment-1', draft, [], '2026-11-12T12:00:00Z', 'Tester');
  assert.equal(row.status, 'Draft'); assert.equal(row.amount, '120.50'); assert.equal(row.currency, 'EUR');
  assert.equal(row.creditorAccount, 'LT121000011101001000'); assert.equal(row.companyId, company.id);
  assert.equal(row.relatedDocumentId, ''); assert.equal(row.relatedDocumentNumber, '');
});
test('payment validation rejects missing, invalid and foreign-company values', () => {
  const f = fixture();
  for (const patch of [{ debtorAccount: '' }, { debtorAccount: 'FOREIGN' }, { executionDate: '' }, { executionDate: '2026-02-30' },
    { counterparty: ' ' }, { creditorAccount: '123' }, { amount: '0' }, { amount: '-10' }, { amount: '1e3' },
    { amount: '1.001' }, { amount: '99999999999999999999' }, { currency: '' }, { currency: 'EURO' }, { purpose: '' }, { relatedDocumentId: 'invoice-b' }])
    assert.throws(() => f.preparePaymentDraft(company, 'payment-1', { ...draft, ...patch }, f.data.documents, 'now', 'Tester'));
  assert.throws(() => f.preparePaymentDraft({ ...company, inactive: true }, 'payment-1', draft, [], 'now', 'Tester'));
});
test('related documents belong to this company and exclude deleted, inactive and bank entries', () => {
  const f = fixture();
  const rows = [...f.data.documents, { ...document, id: 'deleted', document_deletion: {} }, { ...document, id: 'inactive', inactive: true }, { ...document, id: 'bank', bank_transaction: {} }];
  assert.deepEqual(f.paymentRelatedDocuments(rows, company.id).map(row => row.id), ['invoice-a']);
  const result = f.preparePaymentDraft(company, 'payment-1', { ...draft, relatedDocumentId: document.id }, rows, 'now', 'Tester');
  assert.equal(result.relatedDocumentNumber, 'INV-001');
});
test('saving persists company-scoped drafts, does not mutate documents or send a payment, and rejects duplicate/revoked saves', async () => {
  const f = fixture(), before = structuredClone(f.data);
  const saved = await f.saveCompanyPaymentDraft(company.id, 'payment-1', draft);
  assert.equal(saved.createdBy, 'Test accountant'); assert.equal(saved.status, 'Draft');
  assert.deepEqual(f.loadCompanyPayments(company.id), [saved]); assert.deepEqual(f.loadCompanyPayments('company-b'), []);
  assert.deepEqual(f.data, before); assert.deepEqual([...f.storage.keys()], [f.companyPaymentsKey(company.id)]);
  await assert.rejects(f.saveCompanyPaymentDraft(company.id, 'payment-1', draft), /already/);
  f.revoke(); await assert.rejects(f.saveCompanyPaymentDraft(company.id, 'payment-2', draft), /permission/);
  assert.equal(f.loadCompanyPayments(company.id).length, 1);
});
test('corrupt payment storage is not overwritten and unavailable related documents are rechecked on save', async () => {
  const f = fixture(), key = f.companyPaymentsKey(company.id);
  f.storage.set(key, '{broken');
  await assert.rejects(f.saveCompanyPaymentDraft(company.id, 'payment-1', draft));
  assert.equal(f.storage.get(key), '{broken');
  f.storage.delete(key); f.data.documents = [];
  await assert.rejects(f.saveCompanyPaymentDraft(company.id, 'payment-1', { ...draft, relatedDocumentId: document.id }), /available document/);
  assert.equal(f.storage.size, 0);
});
test('Payments navigation and New payment use a separate system screen with required controls', () => {
  const menu = read('../src/components/CompanyDetail.tsx'), view = read('../src/components/CompanySepaPaymentsView.tsx'), form = read('../src/components/NewPaymentForm.tsx');
  assert.match(menu, /id: 'sepa', label: 'Payments'/); assert.doesNotMatch(menu + view, /SEPA payments/);
  assert.match(view, /<PageHeader title="Payments" actions=/); assert.match(view, />New payment<\/PageActionButton>/);
  assert.match(view, /if \(creating\) return <NewPaymentForm/);
  for (const label of ['Debtor bank account', 'Execution date', 'Beneficiary', 'Beneficiary IBAN', 'Amount', 'Currency', 'Purpose of payment', 'Related document']) assert.ok(form.includes(`label="${label}"`));
  assert.match(form, /label="Related document" optional/); assert.match(form, /<CancelButton onClick=\{close\}>Cancel/);
  assert.match(form, /<SaveButton type="submit"/); assert.match(form, /'Save draft'/);
  assert.match(form, /SearchableSelect/); assert.match(form, /portalMenu/);
  assert.match(view, /loadCompanyPayments\(company.id\)/);
});
