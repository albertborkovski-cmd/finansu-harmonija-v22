import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const api = {};
new Function('exports', ts.transpileModule(read('../src/lib/companyBankAmounts.ts'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText)(api);
const { companyBankAmount, formatBankAmount, parseBankAmount } = api;
const display = source => formatBankAmount(companyBankAmount(source));

test('original Bank examples display requested cash-flow signs without currency or source mutations', () => {
  const incoming = { id: '10000000-0000-4000-8000-000000000004', total_amount: '894.19 EUR', type: 'Expense' };
  const outgoing = { id: '10000000-0000-4000-8000-000000000003', total_amount: '684.86 €', type: 'Income' };
  const original = structuredClone([incoming, outgoing]);
  assert.equal(display(incoming), '+894.19');
  assert.equal(display(outgoing), '−684.86');
  assert.deepEqual([incoming, outgoing], original);
});

test('saved signed bank amounts override document types and legacy example directions', () => {
  const source = { id: '10000000-0000-4000-8000-000000000004', total_amount: '999.00', type: 'Purchase' };
  for (const [amount, expected] of [['894.19', '+894.19'], ['-684.86', '−684.86'], ['−12,50 €', '−12.50'], ['0', '0.00'], ['', '—']]) {
    assert.equal(display({ ...source, bank_transaction: { amount } }), expected);
  }
});

test('legacy invoice projections distinguish payments and refunds without changing invoice totals', () => {
  for (const [type, amount, expected] of [['Sale', '20', '+20.00'], ['Purchase', '20', '−20.00'], ['Sale', '-20', '−20.00'], ['Purchase', '-20', '+20.00'], ['Income', '20', '+20.00'], ['Expense', '20', '−20.00']]) {
    assert.equal(display({ id: 'other', type, total_amount: amount }), expected);
  }
  assert.equal(display({ id: 'other', type: 'Service', document_purpose: 'Purchase', total_amount: '10' }), '−10.00');
});

test('amount parsing supports existing currency-formatted values and rejects missing or invalid data', () => {
  for (const value of ['1,234.56 EUR', '1.234,56 €', '1\u00a0234,56', '+1234.56']) assert.equal(parseBankAmount(value), 1234.56);
  assert.equal(parseBankAmount('(684.86) €'), -684.86);
  for (const value of ['', undefined, '—', 'bad value', 'NaN', '12.3.4']) assert.equal(parseBankAmount(value), null);
  assert.equal(formatBankAmount(-0.001), '0.00');
});

test('Bank uses the shared formatter and sorts the actual signed numeric value', () => {
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /amount: formatBankAmount\(amountValue\)/);
  assert.match(view, /key === 'amount' \? row.amountValue : row\[key\]/);
  assert.doesNotMatch(view, /amount: bank.amount/);
});
