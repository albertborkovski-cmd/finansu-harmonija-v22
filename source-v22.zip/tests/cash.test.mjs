import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = (path, require = () => ({})) => { const exports = {}; new Function('exports', 'require', ts.transpileModule(source(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(exports, require); return exports; };
const core = compile('../src/lib/cash.ts');
const examples = compile('../src/lib/cashExamples.ts', () => core);
const validation = { activeGlAccounts: ['2720', '2411', '6300'], activeUserIds: ['user-a', 'user-b'], currencies: ['EUR', 'USD'] };
const users = [{ id: 'user-a', name: 'Sample cashier' }, { id: 'user-b', name: 'Sample accountant' }];
const seed = company => examples.createCashExamples(company || 'company-a', validation, users, '2026-11-13');
const doc = (store, kind = 'Cash income order', amount = 12345) => ({ ...core.blankCashDocument(store, kind, 'Tester', '2026-11-13'), counterparty: 'Test client', purpose: 'Invoice payment', lines: [{ id: crypto.randomUUID(), account: '2411', amountMinor: amount, description: '', relatedDocumentId: '', relatedDocumentNumber: '' }] });
test('cash amounts use exact minor units and reject invalid or ambiguous inputs', () => {
  assert.equal(core.cashMinor('894.19'), 89419); assert.equal(core.cashMinor('684,86'), 68486);
  for (const amount of ['', '0', '-1', 'NaN', 'Infinity', '1.005', '1,000.20', '999999999999999999999']) assert.throws(() => core.cashMinor(amount));
  assert.equal(core.validCashDate('2026-02-30'), false); assert.equal(core.validCashDate('2028-02-29'), true);
});
test('sample fixtures are explicit, fictional and isolated by company', () => {
  const a = seed(), b = seed('company-b');
  assert.equal(a.documents.length, 12);
  assert.equal(a.documents.filter(row => row.kind !== 'Money receipt').length, 10);
  assert.ok(a.documents.every(row => row.companyId === 'company-a' && row.exampleKey));
  assert.ok(a.documents.every(row => !/test|sample|demo|fictional/i.test([row.counterparty, row.purpose, row.notes, row.createdBy].join(' '))));
  assert.ok(new Set(a.documents.map(row => row.date)).size > 5);
  assert.ok(b.documents.every(row => !a.documents.some(other => other.id === row.id)));
  assert.equal(core.emptyCash('new').documents.length, 0);
  const fullChart = examples.createCashExamples('company-a', { ...validation, activeGlAccounts: ['6', ...validation.activeGlAccounts] }, users, '2026-11-13');
  assert.equal(fullChart.documents.find(row => row.kind === 'Cash expense order').lines[0].account, '6300');
});
test('document and cash book print previews retain exact stored values and period totals', () => {
  const reports = compile('../src/lib/cashPrint.ts', () => core), store = seed();
  const book = reports.cashBookReport(store, store.accounts[0].id, '2026-11-01', '2026-11-30', 'Sample company');
  assert.equal(book.rows.length, 6);
  assert.deepEqual(book.details.find(row => row[0] === 'Period'), ['Period', '2026-11-01 — 2026-11-30']);
  assert.match(book.footer, /Closing balance: 3178\.23 EUR/);
  const document = store.documents[1], report = reports.cashDocumentReport(document, store, 'Sample company');
  assert.match(report.title, new RegExp(document.number));
  assert.equal(report.rows[0][3], '894.19');
  assert.match(report.footer, /Cashier: Sample cashier/);
  assert.ok(!source('../src/lib/cashPrint.ts').includes('window.open'));
  assert.match(source('../src/components/cash/CashPrintPreview.tsx'), /wide printable/);
});
test('cash book includes opening balance and approved cash orders, not drafts or PPK', () => {
  const store = seed(), book = core.cashBook(store, store.accounts[0].id, '2026-11-01', '2026-11-30');
  assert.equal(book.opening, 150000); assert.equal(book.income, 250419); assert.equal(book.expense, 82596);
  assert.equal(book.closing, 317823); assert.equal(book.rows.length, 6);
  assert.throws(() => core.cashBook(store, store.accounts[0].id, '2026-12-01', '2026-11-30'), /date range/);
});
test('saving a draft reserves a unique number without changing balances; approval is immutable and audited', () => {
  const initial = seed(), draft = doc(initial), before = core.cashBook(initial, initial.accounts[0].id, '2026-11-01', '2026-11-30');
  let saved = core.saveCashDocument(initial, draft, false, 'Tester', validation);
  const row = saved.documents.find(item => item.id === draft.id);
  assert.match(row.number, /^KPO-\d{6}$/); assert.equal(initial.documents.length, 12);
  assert.equal(core.cashBook(saved, initial.accounts[0].id, '2026-11-01', '2026-11-30').closing, before.closing);
  saved = core.saveCashDocument(saved, row, true, 'Approver', validation);
  const approved = saved.documents.find(item => item.id === row.id);
  assert.equal(approved.number, row.number); assert.equal(approved.approvedBy, 'Approver');
  assert.equal(core.cashBook(saved, initial.accounts[0].id, '2026-11-01', '2026-11-30').closing, before.closing + 12345);
  assert.throws(() => core.saveCashDocument(saved, approved, false, 'Tester', validation), /read-only/);
  assert.ok(saved.audit.some(item => item.recordId === row.id && item.action === 'Document approved'));
});
test('cash income and expense correspondences are balanced and opposite', () => {
  const store = seed();
  for (const document of store.documents.filter(row => row.kind !== 'Money receipt')) {
    const lines = core.cashCorrespondences(document);
    assert.equal(lines.reduce((sum, row) => sum + row.debit, 0), lines.reduce((sum, row) => sum + row.credit, 0));
    assert.equal(lines[0][document.kind === 'Cash income order' ? 'debit' : 'credit'], core.cashTotal(document));
  }
  assert.deepEqual(core.cashCorrespondences(store.documents.find(row => row.kind === 'Money receipt')), []);
});
test('PPK converts once to an income order without duplicating balances or automatic matching', () => {
  const initial = seed(), receipt = initial.documents.find(row => row.kind === 'Money receipt' && row.status === 'Approved');
  const draft = core.copyCashDocument(initial, receipt, 'Tester', true);
  assert.equal(draft.kind, 'Cash income order'); assert.equal(draft.receiptId, receipt.id); assert.equal(draft.number, '');
  const saved = core.saveCashDocument(initial, draft, true, 'Tester', validation);
  assert.throws(() => core.copyCashDocument(saved, receipt, 'Tester', true), /another income order/);
  assert.equal(core.cashBook(saved, initial.accounts[0].id, '2026-11-01', '2026-11-30').closing, 367823);
  assert.ok(!JSON.stringify(saved).includes('reconciled'));
});
test('deactivation preserves approved accounting history; only unused drafts can be removed', () => {
  let store = seed(); const approved = store.documents[0], draft = store.documents.find(row => row.status === 'Draft');
  store = core.removeCashRecord(store, 'documents', approved.id, 'Tester');
  assert.equal(store.documents.find(row => row.id === approved.id).inactive, true);
  assert.equal(core.cashBook(store, store.accounts[0].id, '2026-11-01', '2026-11-30').opening, 150000);
  store = core.removeCashRecord(store, 'documents', draft.id, 'Tester');
  assert.ok(!store.documents.some(row => row.id === draft.id));
  assert.ok(store.audit.some(row => row.recordId === draft.id && row.action === 'Record deleted'));
  assert.throws(() => core.removeCashRecord(seed(), 'accounts', store.accounts[0].id, 'Tester'), /unavailable/);
});
test('referenced master data is deactivated and cannot change accounting identity', () => {
  const store = seed(), account = store.accounts[0];
  assert.throws(() => core.saveCashMaster(store, 'accounts', { ...account, currency: 'USD' }, 'Tester', validation), /cannot be changed/);
  const next = core.removeCashRecord(store, 'accounts', account.id, 'Tester');
  assert.equal(next.accounts[0].inactive, true); assert.equal(next.documents.length, store.documents.length);
  assert.throws(() => core.saveCashDocument(next, doc(next), false, 'Tester', validation), /active cash account/);
});
test('posting requires dated responsibility assignments, valid GL accounts and open period', () => {
  const store = seed();
  assert.throws(() => core.saveCashDocument({ ...store, people: [] }, doc(store), true, 'Tester', validation), /cashier and accountant/);
  assert.throws(() => core.saveCashDocument(store, doc(store), true, 'Tester', { ...validation, periodError: () => 'Period is locked' }), /locked/);
  assert.throws(() => core.saveCashDocument(store, doc(store), true, 'Tester', { ...validation, activeGlAccounts: ['2720'] }), /correspondence/);
  assert.throws(() => core.saveCashDocument(store, { ...doc(store), companyId: 'other' }, true, 'Tester', validation), /different company/);
});
test('stale document editors cannot overwrite a newer revision', () => {
  const store = seed(), draft = doc(store), saved = core.saveCashDocument(store, draft, false, 'Tester', validation);
  assert.throws(() => core.saveCashDocument(saved, draft, false, 'Tester', validation), /another window/);
});
test('deleted document numbers are reserved even if the series counter is reset', () => {
  let store = seed(); const original = doc(store);
  store = core.saveCashDocument(store, original, false, 'Tester', validation);
  const number = store.documents.find(row => row.id === original.id).number;
  store = core.removeCashRecord(store, 'documents', original.id, 'Tester');
  store.series.find(row => row.id === original.seriesId).nextNumber = 1;
  const fresh = doc(store); store = core.saveCashDocument(store, fresh, false, 'Tester', validation);
  assert.notEqual(store.documents.find(row => row.id === fresh.id).number, number);
});
test('cash account balances stay separate by currency and cash register', () => {
  let store = seed(); const account = { ...store.accounts[0], id: crypto.randomUUID(), revision: 0, code: 'USD-CASH', name: 'USD cash', currency: 'USD' };
  store = core.saveCashMaster(store, 'accounts', account, 'Tester', validation);
  for (const person of [...store.people]) store = core.saveCashMaster(store, 'people', { ...person, id: crypto.randomUUID(), revision: 0, accountId: account.id }, 'Tester', validation);
  store = core.saveCashDocument(store, { ...doc(store), accountId: account.id }, true, 'Tester', validation);
  assert.equal(core.cashBook(store, account.id, '2026-11-01', '2026-11-30').closing, 12345);
  assert.equal(core.cashBook(store, store.accounts[0].id, '2026-11-01', '2026-11-30').closing, 317823);
});
test('related document identity and currency are checked without reconciliation writes', () => {
  const store = seed(), draft = doc(store); draft.lines[0].relatedDocumentId = 'outside-company'; draft.lines[0].relatedDocumentNumber = 'INV-1';
  assert.throws(() => core.saveCashDocument(store, draft, false, 'Tester', { ...validation, relatedDocuments: [] }), /related document/);
});
test('cash persistence fails closed for corrupt, cross-company and stale data', () => {
  let allowed = true;
  const storage = new Map();
  globalThis.localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
  globalThis.window = { dispatchEvent() {} }; globalThis.CustomEvent ??= class { constructor(type) { this.type = type; } };
  const persistence = compile('../src/lib/cashStore.ts', name => name === './cash' ? core : name === './cashExamples' ? examples : name === './accessControl' ? { parseSession: () => ({ roleNames: [] }), canViewMenu: () => allowed, canEditMenu: () => allowed } : name === './linkedSettingsData' ? { canAccessAssignedOrganization: () => true } : name === './documentRowActionAccess' ? { canCreateCompanyDocument: () => true, documentActionRights: () => ({ delete: true }) } : name === './recordLifecycle' ? { isInactiveRecord: () => false } : name === './generalLedgerUsage' ? { rememberReconciliationLedgerUsage() {} } : { AUTH_SESSION_KEY: 'auth' });
  assert.throws(() => persistence.parseCashStore('{broken', 'company-a'));
  assert.throws(() => persistence.parseCashStore(JSON.stringify(seed('company-b')), 'company-a'), /could not be read/);
  const company = { id: 'company-a' };
  persistence.updateCash(company, 0, 'create', () => seed());
  const before = storage.get(persistence.cashStorageKey(company.id));
  assert.throws(() => persistence.updateCash(company, 0, 'edit', () => seed()), /another window/);
  allowed = false;
  assert.throws(() => persistence.updateCash(company, 1, 'edit', () => seed()), /permission/);
  assert.equal(storage.get(persistence.cashStorageKey(company.id)), before);
});
test('Cash uses the shared system menu, table tools, dropdowns and lifecycle controls', () => {
  const navigation = source('../src/components/CompanyDetail.tsx'), view = source('../src/components/CompanyCashView.tsx');
  assert.match(navigation, /CompanySubmenu id="company-cash-submenu"/);
  assert.match(view, /<WarehouseTable/); assert.match(view, /<RowDeleteButton/); assert.match(view, /<CompanyBreadcrumb/);
  assert.doesNotMatch(view, /<PageHeader[^>]*leading=/);
  assert.doesNotMatch(view, /How Cash works|setHelp|<Info\b/);
  assert.doesNotMatch(view, /Load test records|V22 local workspace|nine fictional|Fictional cash test/);
  assert.match(source('../src/components/cash/CashDocumentEditor.tsx'), /SearchableSelect portalMenu/);
  assert.ok(!source('../src/lib/cash.ts').includes('fetch('));
});

test('cash document footer uses equally sized system actions with responsive spacing', () => {
  const editor = source('../src/components/cash/CashDocumentEditor.tsx');
  const footer = editor.slice(editor.indexOf('footer={'), editor.indexOf('<div className="space-y-4">'));
  assert.match(footer, /role="group" aria-label=\{uiText\("Cash document actions"\)\}/);
  assert.match(footer, /flex w-full flex-wrap items-center justify-between gap-3/);
  assert.match(footer, /ml-auto flex flex-wrap items-center justify-end gap-2/);
  assert.equal((footer.match(/<PageActionButton\b/g) || []).length, 4);
  assert.doesNotMatch(footer, /<(?:CancelButton|SaveButton)\b/);
  assert.match(footer, /onClick=\{\(\) => setPrintPreview\(true\)\}>\{uiText\("Print \/ PDF"\)\}/);
  assert.match(footer, /onClick=\{onClose\}>\{locked \? uiText\('Close'\) : uiText\('Cancel'\)\}/);
  assert.match(footer, /onClick=\{\(\) => save\(false\)\}>\{uiText\("Save draft"\)\}/);
  assert.match(footer, /onClick=\{\(\) => save\(true\)\}>\{uiText\("Save & approve"\)\}/);
});

test('cash transaction edit stays visible but disabled for approved, inactive or unauthorized records', () => {
  const view = source('../src/components/CompanyCashView.tsx');
  const start = view.indexOf('const renderActions =');
  const render = view.slice(start, view.indexOf('if (!permissions.view) return', start));
  const compiled = ts.transpileModule(`export function actions(context) {
    const { store, permissions, section, setEditor } = context;
    const uiText = value => value, CashRowAction = 'CashRowAction', Eye = 'Eye', Pencil = 'Pencil', Copy = 'Copy', FilePlus2 = 'FilePlus2', RowDeleteButton = 'RowDeleteButton';
    const collection = null;
    ${render}
    return renderActions(store.documents[0]);
  }`, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX }, fileName: 'cash-actions.tsx' }).outputText;
  const exports = {};
  new Function('exports', 'require', compiled)(exports, () => ({ Fragment: 'Fragment', jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }) }));
  const flatten = node => !node || typeof node !== 'object' ? [] : Array.isArray(node) ? node.flatMap(flatten) : [node, ...flatten(node.props?.children)];
  for (const [status, inactive, canEdit, disabled] of [
    ['Draft', false, true, false],
    ['Approved', false, true, true],
    ['Draft', true, true, true],
    ['Draft', false, false, true],
  ]) {
    const document = { id: 'cash-1', number: 'KPO-000001', status, inactive };
    let editor;
    const context = { store: { revision: 3, documents: [document] }, permissions: { edit: canEdit, create: false, delete: false }, section: 'transactions', setEditor: value => { editor = value; } };
    const edit = flatten(exports.actions(context)).find(node => node.type === 'CashRowAction' && node.props.label === 'Edit KPO-000001');
    assert.ok(edit, `${status}: Edit must remain visible`);
    assert.equal(edit.props.disabled, disabled);
    edit.props.onClick();
    assert.equal(!!editor, !disabled, 'disabled editing cannot open the editor');
    if (editor) assert.deepEqual(editor, { record: document, readOnly: false, revision: 3 });
    const bookActions = flatten(exports.actions({ ...context, section: 'book' }));
    assert.ok(!bookActions.some(node => node.props?.label === 'Edit KPO-000001'), 'cash book remains view-only');
  }
  const controls = source('../src/components/cash/CashControls.tsx');
  assert.match(controls, /disabled=\{disabled\}/);
  assert.match(controls, /disabled:cursor-not-allowed disabled:opacity-40/);
});

test('own cash audit does not block unused-draft deletion, but accounting links still do', () => {
  const lifecycle = compile('../src/lib/recordLifecycle.ts');
  const persistence = compile('../src/lib/cashStore.ts', name => name === './cash' ? core : name === './cashExamples' ? examples : name === './recordLifecycle' ? lifecycle : {});
  const store = seed(), draft = store.documents.find(row => row.status === 'Draft');
  const values = new Map([[persistence.cashStorageKey(store.companyId), JSON.stringify(store)]]);
  const storage = { get length() { return values.size; }, key: i => [...values.keys()][i] ?? null, getItem: key => values.get(key) ?? null };
  assert.equal(persistence.cashHasExternalLinks(draft, storage), false);
  assert.equal(persistence.cashHasExternalLinks(store.accounts[0], storage), true);
  values.set('finansu-harmonija-v4:data:journal_entries', JSON.stringify([{ company_id: store.companyId, document_id: draft.id }]));
  assert.equal(persistence.cashHasExternalLinks(draft, storage), true);
});

test('legacy labels are normalized without changing user records or accounting values', () => {
  const store = seed();
  const legacy = { ...store.documents[1], exampleKey: undefined, createdBy: 'V22 sample data', counterparty: 'Amber Studio (sample)', purpose: 'Payment for invoice DEMO-101', notes: 'Fictional V22 test record.' };
  const own = { ...store.documents[1], id: 'own-document', exampleKey: undefined, createdBy: 'Accountant', counterparty: 'Own company (sample)', notes: 'Keep my note' };
  const result = examples.normalizeCashExampleLabels({ ...store, documents: [legacy, own] });
  assert.equal(result.documents[0].counterparty, 'Amber Studio');
  assert.equal(result.documents[0].purpose, 'Payment for invoice INV-101');
  assert.equal(result.documents[0].notes, '');
  assert.equal(result.documents[0].number, legacy.number);
  assert.equal(result.documents[0].status, legacy.status);
  assert.deepEqual(result.documents[0].lines, legacy.lines);
  assert.deepEqual(result.documents[1], own);
  assert.deepEqual(examples.normalizeCashExampleLabels(result), result);
});

test('older cash workspaces are extended to ten transactions once, retaining existing documents', () => {
  const store = seed();
  const old = { ...store, examplesVersion: undefined, documents: store.documents.filter(row => !row.exampleKey.startsWith('cash-extra-')) };
  const result = examples.extendCashExamples(old, validation, 'Accountant', '2026-11-13');
  assert.equal(result.documents.filter(row => row.kind !== 'Money receipt').length, 10);
  assert.ok(old.documents.every(row => result.documents.some(next => JSON.stringify(next) === JSON.stringify(row))));
  assert.equal(examples.canExtendCashExamples(result), false);
  assert.throws(() => examples.extendCashExamples(result, validation, 'Accountant', '2026-11-13'), /already available/);
});

test('Alice Stone cash transactions are prepared automatically once, not for other companies', () => {
  const alice = { id: '00000000-0000-4000-8000-000000000002', name: 'Alice Stone' };
  const initial = core.emptyCash(alice.id);
  assert.equal(examples.shouldPrepareAliceCashExamples(alice, initial), true);
  assert.equal(examples.shouldPrepareAliceCashExamples({ ...alice, id: 'company-b' }, initial), false);
  assert.equal(examples.shouldPrepareAliceCashExamples({ ...alice, name: 'Own company' }, initial), false);
  const prepared = examples.prepareAliceCashExamples(initial, validation, users, '2026-11-13');
  const transactions = prepared.documents.filter(row => row.kind !== 'Money receipt');
  assert.equal(transactions.length, 10);
  assert.equal(new Set(transactions.map(row => row.purpose)).size, 10);
  assert.equal(new Set(transactions.map(row => core.cashTotal(row))).size, 10);
  assert.deepEqual(new Set(transactions.map(row => row.status)), new Set(['Draft', 'Approved']));
  assert.deepEqual(new Set(transactions.map(row => row.kind)), new Set(['Cash income order', 'Cash expense order']));
  assert.equal(examples.shouldPrepareAliceCashExamples(alice, prepared), false);
  assert.equal(examples.canExtendCashExamples(prepared), false);
  assert.equal(examples.prepareAliceCashExamples(prepared, validation, users, '2026-11-13'), prepared);
  const removed = core.removeCashRecord(prepared, 'documents', transactions.find(row => row.status === 'Draft').id, 'Accountant');
  assert.equal(examples.shouldPrepareAliceCashExamples(alice, removed), false, 'Do not recreate records that the user later deletes');
  const view = source('../src/components/CompanyCashView.tsx');
  assert.match(view, /if \(permissions\.create\) loadExamples\(true\)/);
  assert.match(view, /automatic && !shouldPrepareAliceCashExamples\(company, latest\)/);
  assert.match(view, /updateCash\(company, latest\.revision, 'create'/);
});

test('partial or already configured cash data is extended without replacing any existing record', () => {
  const base = seed();
  const existing = { ...base, documents: base.documents.slice(0, 3) };
  const before = JSON.stringify(existing);
  const prepared = examples.prepareAliceCashExamples(existing, validation, users, '2026-11-13');
  assert.equal(prepared.documents.filter(row => row.kind !== 'Money receipt' && !row.inactive).length, 10);
  assert.equal(JSON.stringify(existing), before);
  for (const collection of ['accounts', 'people', 'series', 'documents']) {
    for (const record of existing[collection]) assert.deepEqual(prepared[collection].find(row => row.id === record.id), record);
  }
  assert.equal(new Set(prepared.series.map(row => row.prefix)).size, prepared.series.length);
  assert.equal(new Set(prepared.accounts.map(row => row.code)).size, prepared.accounts.length);
  assert.equal(new Set(prepared.documents.map(row => row.number)).size, prepared.documents.length);
  assert.deepEqual(prepared.audit.slice(0, existing.audit.length), existing.audit);
  const complete = examples.prepareAliceCashExamples(base, validation, users, '2026-11-13');
  assert.deepEqual(complete.documents, base.documents);
  assert.deepEqual(complete.accounts, base.accounts);
  assert.equal(complete.examplesVersion, 3);
});
