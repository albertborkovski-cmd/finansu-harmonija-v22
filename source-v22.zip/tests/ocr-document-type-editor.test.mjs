import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import ts from 'typescript';
const require = createRequire(import.meta.url);
const compile = path => ts.transpileModule(readFileSync(new URL(path, import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
}).outputText;
const routing = {};
new Function('exports', compile('../src/lib/ocrApprovalRouting.ts'))(routing);
const editorCode = compile('../src/components/OcrDocumentTypeEditor.tsx');
const find = (node, predicate) => {
  if (!node || typeof node !== 'object') return undefined;
  if (predicate(node)) return node;
  for (const child of [node.props?.children].flat(Infinity)) { const result = find(child, predicate); if (result) return result; }
};

async function fixture({ rules = [], canEdit = true, corrupt = false } = {}) {
  const slots = [], effects = [], saved = []; let cursor = 0, closed = 0;
  const react = {
    useState(initial) { const index = cursor++; if (!(index in slots)) slots[index] = typeof initial === 'function' ? initial() : initial;
      return [slots[index], next => { slots[index] = typeof next === 'function' ? next(slots[index]) : next; }]; },
    useRef(initial) { const index = cursor++; slots[index] ??= { current: initial }; return slots[index]; },
    useEffect(effect) { const index = cursor++; if (!(index in slots)) { slots[index] = true; effects.push(effect); } },
  };
  const imports = { react, 'react/jsx-runtime': require('react/jsx-runtime'), 'lucide-react': { X: 'close-icon' },
    '../i18n/language': { translateUi: value => value, translateStatus: value => value },
    '../lib/supabase': { supabase: { from: () => ({ select: () => Promise.resolve({ data: [{ id: 'alice', name: 'Alice Stone' }, { id: 'bob', name: 'Bob Smith' }] }) }) } },
    '../lib/ocrApprovalRouting': routing,
    '../lib/ocrApprovalRoutingStore': { canEditOcrApprovalRouting: () => canEdit, loadOcrApprovalRouting: () => { if (corrupt) throw new Error('Settings could not be read'); return { rules }; } },
    './SearchableSelect': { default: 'select-field' }, './MultiSelectField': { default: 'multi-field' },
    './ScopedActionButtons': { SaveButton: 'save-button', CancelButton: 'cancel-button' },
  };
  const module = {};
  new Function('exports', 'require', 'document', editorCode)(module, id => { assert.ok(imports[id], id); return imports[id]; }, { activeElement: null });
  const props = { record: { code: 'INVOICES', fullName: 'Invoices', description: '', status: 'Active', parentCode: '', country: '' },
    isNew: false, onClose: () => closed++, onSave: (...values) => saved.push(values) };
  const render = () => { cursor = 0; const tree = module.default(props); effects.splice(0).forEach(effect => effect()); return tree; };
  render(); await Promise.resolve(); await Promise.resolve();
  return { render, saved, closed: () => closed };
}

test('Edit shows TeamLead choices in the existing document form and Cancel makes no changes', async () => {
  const f = await fixture(); let tree = f.render();
  const selector = find(tree, node => node.props?.ariaLabel === 'Send to TeamLead');
  assert.deepEqual(selector.props.options.map(option => option.value), ['inherit', 'disabled', 'all', 'organizations']);
  selector.props.onChange('all'); tree = f.render();
  assert.equal(f.saved.length, 0);
  find(tree, node => node.type === 'cancel-button').props.onClick();
  assert.equal(f.closed(), 1); assert.equal(f.saved.length, 0);
});

test('selected organizations use company IDs, remain editable, and save with the document type', async () => {
  const f = await fixture(); let tree = f.render();
  find(tree, node => node.props?.ariaLabel === 'Send to TeamLead').props.onChange('organizations');
  tree = f.render();
  assert.equal(find(tree, node => node.type === 'save-button').props.disabled, true);
  const organizations = find(tree, node => node.type === 'multi-field');
  assert.deepEqual(organizations.props.options, ['Alice Stone', 'Bob Smith']);
  assert.equal(organizations.props.portalMenu, true);
  organizations.props.onChange(['Alice Stone']); tree = f.render();
  find(tree, node => node.props?.['aria-label'] === 'Name').props.onChange({ target: { value: 'Invoice documents' } });
  tree = f.render(); find(tree, node => node.type === 'save-button').props.onClick();
  assert.equal(f.saved.length, 1);
  assert.equal(f.saved[0][0].fullName, 'Invoice documents');
  assert.deepEqual(f.saved[0][1], { mode: 'organizations', organizationIds: ['alice'] });
});

test('unchanged routing is preserved and permission or corrupt-storage errors disable saving', async () => {
  const f = await fixture(); find(f.render(), node => node.type === 'save-button').props.onClick();
  assert.equal(f.saved[0][1], null);
  for (const options of [{ canEdit: false }, { corrupt: true }]) {
    const blocked = await fixture(options), tree = blocked.render();
    assert.equal(find(tree, node => node.type === 'save-button').props.disabled, true);
    assert.equal(find(tree, node => node.type === 'fieldset').props.disabled, true);
    assert.equal(blocked.saved.length, 0);
  }
});

test('document field validation has no redundant header Edit while field editing stays available', () => {
  const catalog = readFileSync(new URL('../src/components/OrganizationReferenceValuesView.tsx', import.meta.url), 'utf8');
  const validationView = catalog.slice(catalog.indexOf('if (section === "Document type" && validationDocument)'), catalog.indexOf('if (section === "Document type" && selectedDocumentTypeCode)'));
  assert.match(validationView, /<HeaderBackButton/);
  assert.match(validationView, /<OcrFieldValidationSettings/);
  assert.doesNotMatch(validationView, /<PageActionButton|startEditSubtype/);
  const groupView = catalog.slice(catalog.indexOf('title={selectedDocumentType.fullName}'), catalog.indexOf('Search ${selectedDocumentType.fullName}'));
  assert.doesNotMatch(groupView, /selectedDocumentType\)\}>Edit/);
  assert.match(groupView, /<PageActionButton onClick=\{startCreateSubtype\}>/);
  assert.match(catalog, /onClick=\{\(\) => startEditSubtype\(index, record\)\}/);
  const fields = readFileSync(new URL('../src/components/OcrFieldValidationSettings.tsx', import.meta.url), 'utf8');
  assert.match(fields, /onClick=\{\(\) => openEditor\(rule\)\}/);
});
