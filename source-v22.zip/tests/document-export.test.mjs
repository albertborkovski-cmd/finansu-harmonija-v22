import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import ts from 'typescript';
const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const require = createRequire(import.meta.url), api = {};
new Function('exports', 'require', ts.transpileModule(source('../src/lib/documentExport.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(api, require);
const columns = [{ key: 'number', label: 'Document No.' }, { key: 'note', label: 'Note' }];
const rows = [{ id: 'a', companyId: 'one', number: 'INV-1', note: 'Lithuanian: ą, "quote"\nsecond line', privateData: 'do not export' }, { id: 'b', companyId: 'one', number: '=1+1', note: ' \t@SUM(A1)', privateData: 'secret' }];

test('company document header omits Upload document without removing the existing import action', () => {
  const list = source('../src/components/Documents.tsx');
  assert.match(list, /\{allCompanies && <PageActionButton[^>]*onClick=\{\(\) => setShowUploadPanel\(true\)\}[^>]*>\s*Upload document\s*<\/PageActionButton>\}/);
  assert.match(list, /aria-label="Import documents"/);
  assert.match(source('../src/components/CompanyDetail.tsx'), /label: 'Uploaded document'/);
});

test('document information panel contains the upload guidance and the existing Dashboard ADDINFO shortcut', () => {
  const list = source('../src/components/Documents.tsx');
  for (const text of [
    'Upload one or multiple documents by drag &amp; drop or by selecting files.',
    'Documents for different organizations can be uploaded together - the system will identify and assign them during processing.',
    'You can also send documents to the email address shown above.',
    'After upload, documents are sent for processing and their status can be followed in Uploaded documents.',
  ]) assert.ok(list.includes(text), text);
  assert.match(list, /<strong className="font-semibold">On the company Dashboard or All documents, press Alt \+ P \(Option ⌥ \+ P on Mac\) while no text field is focused to open the ADDINFO form and manually enter additional information\.<\/strong>/);
  assert.ok(!list.includes('Hold down Shift'));
  assert.ok(!list.includes('Important: the system processes purchase invoices by'));
  assert.ok(!list.includes('kw: "NOSPLIT"'));
});

test('selection exports explicit IDs only, preserving hidden selections without adding filtered-out records', () => {
  const documents = [{ id: 'a', company_id: 'one' }, { id: 'b', company_id: 'one' }, { id: 'c', company_id: 'two' }];
  assert.deepEqual(api.selectedDocumentRecords(documents, ['b', 'a', 'a'], 'one').map(row => row.id), ['b', 'a']);
  assert.throws(() => api.selectedDocumentRecords(documents, [], 'one'), /Select/);
  assert.throws(() => api.selectedDocumentRecords(documents, ['missing'], 'one'), /no longer/);
  assert.throws(() => api.selectedDocumentRecords(documents, ['c'], 'one'), /no longer/);
});
test('destination options follow company configuration, omit inactive systems and never expose secrets', () => {
  assert.deepEqual(api.documentDeliveryDestinations().map(option => option.label), ['Rivilė', 'Rivilė API', 'Agnum']);
  assert.deepEqual(api.documentDeliveryDestinations(JSON.stringify({ apiKey: 'secret', exportIntegrations: [{ id: 'one', name: 'ERP', apiUrl: 'private', apiKey: 'secret' }, { id: 'two', name: 'Old', active: false }, { id: 'one', name: 'Duplicate' }] })), [{ value: 'one', label: 'ERP' }]);
  assert.deepEqual(api.documentDeliveryDestinations('{broken'), []);
  assert.deepEqual(api.documentDeliveryDestinations('{"exportIntegrations":[]}'), []);
});
test('saved destination resolves only for the current company and an available integration', () => {
  assert.deepEqual(api.savedDocumentDeliveryDestination({ accounting_destination_id: 'rivile' }), { value: 'rivile', label: 'Rivilė' });
  assert.equal(api.savedDocumentDeliveryDestination(), undefined);
  assert.equal(api.savedDocumentDeliveryDestination({}), undefined);
  assert.equal(api.savedDocumentDeliveryDestination({ accounting_destination_id: 'removed' }), undefined);
  assert.equal(api.savedDocumentDeliveryDestination({ accounting_destination_id: 'rivile', counterparties_settings: JSON.stringify({ exportIntegrations: [{ id: 'rivile', name: 'Rivilė', active: false }] }) }), undefined);
  assert.equal(api.savedDocumentDeliveryDestination({ accounting_destination_id: 'rivile', counterparties_settings: '{broken' }), undefined);
});
test('Primary export format uses the company setup value and supports every setup option', () => {
  const names = ['Rivilė', 'Rivilė API', 'Agnum', 'XML', 'B1', 'Excel', 'Finvalda', 'Finvalda Excel', 'JSON'];
  const ids = ['rivile', 'rivile-api', 'agnum', 'xml', 'b1', 'excel', 'finvalda', 'finvalda-excel', 'json'];
  names.forEach((name, index) => assert.deepEqual(api.primaryDocumentDeliveryDestination({ primary_export_format: name, accounting_destination_id: 'stale' }), { value: ids[index], label: name }));
  assert.deepEqual(api.primaryDocumentDeliveryDestination({ primary_export_format: ' rivile_API ' }), { value: 'rivile-api', label: 'Rivilė API' });
  assert.deepEqual(api.primaryDocumentDeliveryDestination({ accounting_destination_id: 'agnum' }), { value: 'rivile', label: 'Rivilė' });
  assert.equal(api.primaryDocumentDeliveryDestination(), undefined);
  for (const value of ['', 'unknown']) assert.equal(api.primaryDocumentDeliveryDestination({ primary_export_format: value, accounting_destination_id: 'rivile' }), undefined);
  const setup = source('../src/components/CompanyClientInformation.tsx');
  for (const name of names) assert.ok(setup.includes(`"${name}"`), name);
});
test('Primary export format resolves configured IDs or names without falling back to another system', () => {
  const integration = { id: 'company-erp', name: 'Rivilė', apiKey: 'never expose' };
  const company = { primary_export_format: 'Rivilė', counterparties_settings: JSON.stringify({ exportIntegrations: [integration] }) };
  assert.deepEqual(api.primaryDocumentDeliveryDestination(company), { value: 'company-erp', label: 'Rivilė' });
  assert.deepEqual(api.primaryDocumentDeliveryDestination({ ...company, primary_export_format: 'company-erp' }), { value: 'company-erp', label: 'Rivilė' });
  assert.equal(api.primaryDocumentDeliveryDestination({ ...company, primary_export_format: 'Agnum' }), undefined);
  for (const unavailable of [{ ...integration, active: false }, { ...integration, inactive: true }]) assert.equal(api.primaryDocumentDeliveryDestination({ ...company, counterparties_settings: JSON.stringify({ exportIntegrations: [unavailable] }) }), undefined);
  assert.equal(api.primaryDocumentDeliveryDestination({ ...company, counterparties_settings: '{broken' }), undefined);
});
test('CSV is real UTF-8 CSV with quoting and formula-injection protection', async () => {
  const file = await api.buildDocumentExport(rows, columns, 'csv', 'Alice/Stone');
  assert.match(file.filename, /^AliceStone-documents-\d{4}-\d{2}-\d{2}\.csv$/);
  assert.equal(file.mime, 'text/csv;charset=utf-8');
  assert.ok(file.content.startsWith('\uFEFF"Document No.","Note"\r\n'));
  assert.ok(file.content.includes('"Lithuanian: ą, ""quote""\nsecond line"'));
  assert.ok(file.content.includes('"\'=1+1"'));
  assert.ok(file.content.includes('"\' \t@SUM(A1)"'));
  assert.ok(!file.content.includes('secret'));
});
test('JSON includes selected display columns and stable record identity only', async () => {
  const before = structuredClone(rows);
  const file = await api.buildDocumentExport(rows.slice(0, 1), columns, 'json');
  const parsed = JSON.parse(file.content);
  assert.equal(parsed.documents.length, 1);
  assert.deepEqual(parsed.documents[0], { id: 'a', companyId: 'one', values: { number: rows[0].number, note: rows[0].note } });
  assert.deepEqual(rows, before);
});
test('Excel format contains a readable workbook, not renamed text, and cell strings are not formulas', async () => {
  const XLSX = require('xlsx');
  const file = await api.buildDocumentExport(rows, columns, 'xlsx');
  const workbook = XLSX.read(file.content, { type: 'array' });
  assert.deepEqual(XLSX.utils.sheet_to_json(workbook.Sheets.Documents, { header: 1 }), [columns.map(column => column.label), ...rows.map(row => [row.number, row.note])]);
  assert.equal(workbook.Sheets.Documents.A3.f, undefined);
  assert.equal(workbook.Sheets.Documents.A3.t, 's');
});
test('empty selections, empty columns and unsupported formats cannot download misleading files', async () => {
  await assert.rejects(api.buildDocumentExport([], columns, 'csv'), /Select/);
  await assert.rejects(api.buildDocumentExport(rows, [], 'csv'), /Column settings/);
  await assert.rejects(api.buildDocumentExport(rows, columns, 'pdf'), /supported/);
});
test('list separates selected-document transfer from file export and refreshes scope and rights at action time', () => {
  const list = source('../src/components/Documents.tsx'), dialog = source('../src/components/DocumentDeliveryDialog.tsx');
  assert.match(list, /Send to accounting/);
  assert.ok(list.indexOf("Send to ${primaryDestination?.label || 'accounting'}") >= 0);
  assert.ok(list.indexOf("Send to ${primaryDestination?.label || 'accounting'}") < list.indexOf('{/* Filter bar */}'));
  assert.match(list, /aria-label="Export selected documents"/);
  assert.match(list, /sendDocuments\(\[\.\.\.selectedIds\], primaryDestination\?\.value\)/);
  assert.match(list, /mode: 'export', ids: \[\.\.\.selectedIds\]/);
  assert.match(list, /selectedDocumentRecords\(/);
  assert.match(list, /canViewCompanyDocuments\(organization\)/);
  assert.match(list, /const \{ documents, companies \} = await loadDeliveryRecords\(delivery\)/);
  assert.doesNotMatch(list, /importDocuments\(|update\(\{ status: 'Transferred' \}\)|IMPORTDATA/);
  assert.match(dialog, /onClick=\{\(\) => void sendTest\(\)\}/);
  assert.match(dialog, /Test · API not connected/);
  assert.doesNotMatch(dialog, /fetch\(|\.update\(/);
  assert.match(dialog, /No documents are sent to an external accounting system/);
  assert.equal((dialog.match(/<SearchableSelect portalMenu menuClassName="!z-\[5100\]"/g) ?? []).length, 1);
  assert.match(dialog, /ariaLabel="Destination system"/);
});

test('export retains the centered system-choice dialog and existing down-arrow design; import still opens uploads', () => {
  const list = source('../src/components/Documents.tsx'), dialog = source('../src/components/DocumentDeliveryDialog.tsx');
  assert.match(dialog, /flex items-center justify-center bg-\[#10233A\]\/35 p-4/);
  assert.match(dialog, /max-h-\[90vh\] w-full max-w-\[760px\]/);
  assert.doesNotMatch(dialog, /side-panel|w-\[340px\]|Records to export|Columns to export/);
  assert.match(dialog, /onClick=\{\(\) => void exportFile\(\)\}/);
  assert.match(dialog, /await onExport\(destination\)/);
  assert.match(dialog, /regardless of visible columns/);
  assert.doesNotMatch(dialog, /Export file format|setFormat|columnsCount/);
  assert.match(dialog, /if \(mode === 'export'\) \{ setDestination\(value\); setComplete\(false\); setError\(''\); return; \}/);
  assert.match(dialog, /pending\.current = true; setBusy\(true\)/);
  assert.match(list, /buildDocumentAccountingExport\(documents.map\(record => record.inlineSource\), delivery.ids, company, destinationId\)/);
  const exportIndex = list.indexOf('aria-label="Export selected documents"');
  const importIndex = list.indexOf('aria-label="Import documents"');
  const refreshIndex = list.indexOf('<RefreshAllButton', importIndex);
  assert.ok(exportIndex < importIndex && importIndex < refreshIndex);
  assert.match(list.slice(exportIndex, importIndex), /<Download size=\{16\} strokeWidth=\{1\.8\} \/>/);
  assert.doesNotMatch(list.slice(exportIndex, importIndex), /<PageActionButton|>\s*Export\s*</);
  const exportButton = list.slice(list.lastIndexOf('<button', exportIndex), list.indexOf('</button>', exportIndex));
  const importButton = list.slice(list.lastIndexOf('<button', importIndex), list.indexOf('</button>', importIndex));
  assert.equal(exportButton.match(/className="([^"]*)"/)[1], importButton.match(/className="([^"]*)"/)[1]);
  assert.match(exportButton, /data-export-icon="download"/);
  const styles = source('../src/index.css');
  assert.match(styles, /\[aria-label\^="Export "\]:not\(\[data-export-icon="download"\]\) > svg/);
  assert.match(styles, /\[aria-label\^="Export "\]:not\(\[data-export-icon="download"\]\)::before/);
  assert.match(list.slice(exportIndex, importIndex), /strokeWidth=\{1\.8\}/);
  assert.match(list.slice(exportIndex, importIndex), /mode: 'export', ids: \[\.\.\.selectedIds\]/);
  assert.match(list.slice(importIndex, refreshIndex), /onClick=\{\(\) => setShowUploadPanel\(true\)\}/);
  assert.match(list, /showUploadPanel && createPortal\(/);
  assert.match(list, /aria-label="Upload new file"/);
  assert.match(list, /z-\[5001\]/);
  assert.match(list, /uploadPanelRef.current\?\.focus\(\)/);
});
